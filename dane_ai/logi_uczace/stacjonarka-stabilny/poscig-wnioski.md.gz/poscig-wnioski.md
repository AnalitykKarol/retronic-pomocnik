## 2026-10-15 19:08 | ok | pościgów 5 min: 22, 30 min: 143
- Pościgi niemal zawsze kończą się dobiciem, a zgubień praktycznie nie ma. (pewność 0.8)
  dowód: Okno długie: 142/143 dobicie (99%), zgubienie 0, przerwane_inne 1. Okno krótkie: 22/22 dobicie (100%). Odległość mediana 2 -> 1 (delta -1), wzrosła w 0 pościgach.
  skutek: Brak istotnej utraty dobić; jedyny przerwany pościg to pojedynczy przypadek.
  propozycja: Brak zmiany wymaganej.
- Wykrywacz utknięć oznacza 4 przypadki, wszystkie w stanie WALKA, a nie w ruchu, więc może łapać walkę zamiast realnego zablokowania pościgu. (pewność 0.35)
  dowód: Okno długie: utknięcia 4/143 (2.8%), wszystkie stan WALKA, pole v 14-20, krok_s 0.66-0.94, stwory Jointoramix i Troll. Okno krótkie: 0 utknięć.
  skutek: Możliwe fałszywe alarmy i pomyłkowa diagnoza przyczyny; realny koszt niewidoczny w danych (wszystkie 4 pościgi skończyły się dobiciem wg licznika).
  propozycja: Funkcja wykrywania utknięć: ograniczyć sprawdzanie prędkości pola do stanu IDZ (wykluczyć WALKA) — kierunek: zawężenie warunku, do oceny przez człowieka.
- Naciski klawisza z postoju pojawiają się w większości pościgów mimo, że klawisz jest trzymany przez 100% czasu. (pewność 0.3)
  dowód: Okno długie: naciski_z_postoju 116 na 143 pościgi (0.81), trzymane_proc_czasu 100, zmiany_kierunku_na_krok 0.21, lat_med 0.185 s. Okno krótkie: 17 na 22 (0.77).
  skutek: Możliwe, że część początku pościgu to ponowne wciśnięcia, które nic nie dają albo opóźniają ruch; w danych nie widać jeszcze, czy to kosztuje czas (dec_med ~0).
  propozycja: Funkcja wysyłania klawiszy trzymaj: sprawdzić, czy ponowne naciśnięcie klawisza już trzymanego jest konieczne — kierunek: pominąć ponowne naciśnięcie, gdy klawisz jest już w stanie trzymania.
- Poprzedni wniosek o gorszym ogonie prędkości w oknie długim jest sprzeczny z danymi: to okno krótkie ma niższy p10. (pewność 0.3)
  dowód: kroki_na_s p10: krótkie 1.06, długie 1.3; mediana krótkie 1.51, długie 1.69; p90 1.85 vs 1.96. Krótkie to 22 pościgi (n<30, niska pewność).
  skutek: Brak dowodu na pogorszenie w dłuższym oknie; ryzyko podjęcia złej decyzji na podstawie błędnego wniosku.
  propozycja: Brak zmiany w kodzie; zmierzyć ogon prędkości na większej próbie w tym samym oknie.
- Liczba zgubionych celów jest niespójna między poziomem pościgów a epizodami celu. (pewność 0.7)
  dowód: Okno długie: koniec.zgubienie 0 (zgubienie_proc 0), ale epizody_celu.zgubione 1 i porzucone 1; wskaznik epizodów 97%. Pole niespojnosci jest puste mimo tej rozbieżności.
  skutek: Metryki skuteczności mogą być zawyżane lub zaniżane o 1 przypadek; utrudnia to ocenę trafności wniosków.
  propozycja: Klasyfikacja zakończenia: ujednolicić źródło etykiety (koniec pościgu vs epizod celu) — jedna funkcja zwracająca powód, z której liczą się obie metryki.

## 2026-10-15 19:10 | ok | pościgów 5 min: 14, 30 min: 127
- Klawisz jest trzymany przez 100% czasu pościgu, a mimo to zapisywane są naciski z postoju, czyli wysłanie klawisza przy stojącej postaci. (pewność 0.5)
  dowód: okno_dlugie: naciski_z_postoju=104 przy 127 pościgach (0,82 na pościg), trzymane_proc_czasu=100; okno_krotkie: 9 naciśnięć przy 14 pościgach (0,64 na pościg)
  skutek: Nie wiadomo, czy to zmarnowane ticki (opóźnienie ruchu) czy tylko błąd licznika. Dobicia są na poziomie 99%, więc koszt jest prawdopodobnie mały.
  propozycja: Sprawdzić w kodzie funkcję, która wysyła kierunek w pętli pościgu i zlicza naciśnięcia (np. wysyłanie kierunku przy każdym ticku zamiast tylko przy zmianie). Kierunek: licznik ma liczyć tylko faktyczny postój, a powtórne wysłanie trzymanego klawisza nie powinno być liczone jako naciśnięcie.
- W oknie krótkim latencja mediana jest prawie trzykrotnie wyższa niż w długim, a prędkość kroków niższa. (pewność 0.3)
  dowód: okno_krotkie: lat_med_s=0,538, kroki_na_s med=1,42; okno_dlugie: lat_med_s=0,19, kroki_na_s med=1,69; n=14 w oknie krótkim
  skutek: Pościgi w krótkim oknie biegną wolniej. Przy n=14 i jednym oknie to może być szum (np. jedna cięższa sesja), dlatego pewność jest niska.
  propozycja: Sprawdzić w kodzie stałą interwału między wysłaniem klawisza a odczytem pozycji w pętli pościgu oraz czy nie zmieniła się przed tym oknem. Kierunek zmiany do rozważenia dopiero po większej próbie.
- Wszystkie 4 utknięcia wystąpiły w stanie WALKA, a w 3 z 4 obok celu był drugi stwór (Troll lub Jointoramix). (pewność 0.35)
  dowód: utkniecia.liczba=4 w oknie długim; stwory: [Jointoramix,0]+[Troll,2], [Jointoramix,0]+[Troll,1], [Jointoramix,0]; pole krok_s 0,66–0,94, v 14–20
  skutek: Gdy na drodze są inne stwory, postać zwalnia lub stoi. Zgubień nie było, więc koszt to czas, nie dobicie.
  propozycja: Sprawdzić funkcję wyznaczania drogi do celu: czy uwzględnia zajęte pola (stwory na ścieżce). Kierunek: omijanie zajętych pól lub wybór alternatywnej ścieżki przy obecności innego stwora w pobliżu. Przy n=4 traktować jako sygnał do obserwacji.
- Ogon prędkości w oknie krótkim jest gorszy niż w długim, co koryguje poprzedni wniosek. (pewność 0.4)
  dowód: kroki_na_s p10: krótkie=1,06, długie=1,3; p90: krótkie=1,85, długie=1,96
  skutek: Najwolniejsze 10% pościgów w krótkim oknie jest wolniejsze, ale to 14 pościgów, więc wynik jest niepewny.
  propozycja: Brak zmiany w kodzie. Zmierzyć ogon prędkości na większej próbie, zanim cokolwiek zmieniać.
- do zmierzenia: Czy naciski z postoju występują przy blokadzie ruchu (ściana, stwór na drodze), czy przy wolnym polu? Porównać je z wartością pola krok_s w tych samych chwilach.
- do zmierzenia: Czy niższa latencja w długim oknie wynika z innego obciążenia gry w tym czasie, czy ze zmiany interwału pętli? Zmierzyć lat_med_s w kilku okresach po 300 s.
- do zmierzenia: Czy rozbieżność 'zgubione' z poprzednich wniosków wynika z różnych okien czasowych? W tych danych oba poziomy pokazują zgubienie=0, więc sprawdzić, skąd wzięła się wcześniejsza wartość.
- do zmierzenia: Czy zmiany kierunku na krok (0,22–0,29) są zawyżone przez krótkie drogi (mediana odległości startowej 2)? Policzyć wskaźnik tylko dla pościgów z drogą ≥5 kroków.

## 2026-10-15 19:12 | uwaga | pościgów 5 min: 14, 30 min: 126
- Utknięcia pościgu pojawiają się głównie, gdy w stanie WALKA obok celu stoi drugi stwór. (pewność 0.4)
  dowód: Okno długie: 4 utknięcia na 126 pościgów (3,2%), z czego 3 z drugim stworem (Troll lub Jointoramix). Pole v 14-20, krok_s 0.66-0.94. Zgubienie = 0, bez_dojscia = 0.
  skutek: Pościg traci czas na obejście innego stwora, ale w tych danych nie kończy się zgubieniem celu.
  propozycja: Funkcja wyboru kroku/ścieżki pościgu: uwzględnić pola zajęte przez inne stwory jako blokujące (np. stała promienia lub listy zajętych pól), do oceny przez człowieka.
- Skuteczność dobicia jest bardzo wysoka w obu oknach; pościgi są zwykle bardzo krótkie. (pewność 0.6)
  dowód: Dobicie 100% (krótkie, n=14) i 99% (długie, 125/126). Mediana odległości start 2 -> koniec 1. Długie: 199 kroków na 126 pościgów (~1,6 kroku), czas ~0,77 s na pościg.
  skutek: Brak wskazań na nieskuteczność; większość dobić to dojście o 1-2 kroki, więc ewentualne problemy ujawnią się głównie przy dłuższych pościgach, których w danych jest mało.
  propozycja: Brak zmiany. Zebrać więcej pościgów o długości >3 kroki, aby ocenić skuteczność w trudniejszych przypadkach.
- Wniosek z ostatnie_wnioskow o trzykrotnie wyższej latencji w oknie krótkim nie znajduje potwierdzenia w danych. (pewność 0.8)
  dowód: lat_med_s: krótkie 0.179 s, długie 0.2 s (różnica ok. 10%, nie 3x). Prędkość kroków w krótkim niższa (med 1.18 vs 1.7), co jest zgodne z danymi.
  skutek: Brak; ryzyko błędnego wniosku o latencji, jeśli zostanie powtórzony.
  propozycja: Nie wprowadzać zmiany na podstawie tego wniosku; zweryfikować obliczenie latencji w statystykach okna krótkiego.
- Percentyle tempa kroków w oknie krótkim są nieinformatywne, bo tylko jeden pościg wniósł wartość tempa. (pewność 0.3)
  dowód: n_do_tempa=1; kroki_na_s med=p10=p90=1.18. W długim n_do_tempa=28.
  skutek: Nie da się ocenić zmienności tempa w oknie krótkim; porównanie 1.18 vs 1.7 jest niepewne.
  propozycja: Traktować tempo z okna krótkiego jako niewiarygodne, dopóki n_do_tempa nie będzie co najmniej 5.
- Najgorszy pościg (Troll, 4 kroki) zakończył się przerwaniem 'gryzacy' przy pełnym HP celu, a nie zgubieniem. (pewność 0.25)
  dowód: powod=gryzacy, kroki=4, czas 3.07 s, hp_celu 100, odl [5,2], ocena_zlego 0.3, stan IDZ, hp_gracza 100. W długim: powody gryzacy=1, przerwane_inne=1.
  skutek: Pojedynczy przypadek przerwania przez atak z zewnątrz; koszt to jeden utracony pościg na 126.
  propozycja: Warunek wyjścia z pościgu przy 'gryzacy': rozważyć, czy zaatakowanie przez inny stwór powinno przerywać pościg, czy go kontynuować (opis logiki wyjścia, do decyzji człowieka).

## 2026-10-15 19:14 | ok | pościgów 5 min: 25, 30 min: 135
- Pościgi kończą się niemal zawsze dobiciem; utrata celu i bez dojścia nie wystąpiły. (pewność 0.85)
  dowód: Okno długie: 133/135 dobicie (99%), 0 zgubienie, 0 bez_dojscie. Okno krótkie: 24/25 dobicie (96%), 0 zgubienie. Oscylacje 0, bez_postepu 0 kroków, epizody celu zabite 61/61 i 13/13.
  skutek: Brak wyraźnej utraty dobić; koszt pościgu jest niewielki (mediana 2 kroki startu, 1 kroku końca).
  propozycja: Brak zmiany wymaganej przez te dane.
- Przerwania pościgu zdarzają się rzadko i mają różne przyczyny: 'zawracanie' i 'gryzacy' przy pełnym HP celu. (pewność 0.35)
  dowód: Okno długie: przerwane_inne 2 z 135; powody: zawracanie 1, gryzacy 1. Najgorszy pościg (Troll, 'gryzacy', 4 kroki, HP celu 100) to jedyny taki w danych gryzacy w długim oknie.
  skutek: Około 1,5% pościgów przerwanych bez dobicia; w tych przypadkach cel mógł zostać, a postać nie zdążyła go dogonić.
  propozycja: Obserwować, czy przerwania 'gryzacy' rosną; przy większej próbie rozważyć w funkcji decyzji wyjścia z pościgu (warunek 'gryzacy') sprawdzanie, czy cel rzeczywiście zadał obrażenia, zanim pościg zostanie przerwany.
- Trzymany klawisz wysyła naciśnięcia, gdy postać stoi, mimo że pozycja się nie zmienia. (pewność 0.4)
  dowód: naciski_z_postoju: 120 w oknie długim (0,89 na pościg), 26 w krótkim (1,04 na pościg), przy bez_postepu 0 i trzymane_proc_czasu 100%. Zmiany_kierunku_na_krok 0,23 (długie) i 0,34 (krótkie).
  skutek: Prawdopodobnie zbędne lub nieskuteczne naciśnięcia w czasie oczekiwania; wpływ na czas dobicia nieznany z tych danych, bo pościgi kończą się dobrze.
  propozycja: Funkcja wysyłania klawisza w pętli pościgu: sprawdzić, czy warunek ponownego naciśnięcia uwzględnia zmianę pozycji od ostatniego kroku; zmierzyć, czy naciśnięcia z postoju odpowiadają zwrotom kierunku.
- Trzy utknięcia wystąpiły podczas walki (stan WALKA) przy niskim tempie pola, a nie w czystym pościgu. (pewność 0.25)
  dowód: utkniecia.liczba 3 (okno długie), wszystkie stan WALKA, stwory Jointoramix i Troll, pole v 14–16, krok_s 0,66–0,75 (poniżej mediany kroków 1,62/s).
  skutek: Krótkie opóźnienia dobicia; przy n=3 nie da się oddzielić wpływu pola od walki.
  propozycja: Brak zmiany na tym etapie; przy większej próbie sprawdzić, czy utknięcia korelują z polem o niskim v, a nie z walką.
- Latencja w dwóch najgorszych pościgach jest wyższa niż mediana, ale próba jest za mała. (pewność 0.2)
  dowód: lat_med 0,582 i 0,554 s w najgorszych pościgach vs lat_med 0,187 s (okno długie) i 0,2 s (krótkie); n=2.
  skutek: Nie da się stwierdzić, czy wyższa latencja przyczyniła się do przerwań.
  propozycja: Brak zmiany; zebrać więcej przypadków z latencją powyżej mediany i porównać z wynikiem pościgu.
- do zmierzenia: Czy naciśnięcia z postoju (120 w oknie długim) wynikają z ponownego wysłania klawisza bez zmiany pozycji, czy z przerw między krokami?
- do zmierzenia: Czy tryb stuk daje lepszy wynik niż trzymaj? Brak danych stuk w obu oknach, więc porównanie nie jest możliwe.
- do zmierzenia: Czy przerwania 'gryzacy' rosną przy celach zadających obrażenia, czy są przypadkowe (n=1)?
- do zmierzenia: Czy utknięcia w WALCE korelują z polem o niskim v, czy z obecnością drugiego potwora (Troll)?
- do zmierzenia: Jakie znaczenie ma pole 'ponow_brak' (11 w oknie długim, 4 w krótkim) i czy wpływa na czas pościgu?

## 2026-10-15 19:16 | uwaga | pościgów 5 min: 23, 30 min: 129
- Utknięcia pościgu skupiają się w jednej okolicy i zawsze w stanie WALKA, przy obecnym Jointoramixie. (pewność 0.5)
  dowód: Okno długie: 4 utknięcia, wszystkie stan WALKA, poz x 33079-33086, y 31739-31763, z=8; Jointoramix obecny we wszystkich 4, Troll w 3. Tempo pola 0.66-0.94 krok/s przy medianie kroków na s 1.6. Okno krótkie: 1 utknięcie, ta sama pozycja.
  skutek: Wydłużony czas dojścia do celu w tej strefie. W danych nie ma zgubień (0), więc koszt dobić jest niewielki, ale zmierzony.
  propozycja: Funkcja wyznaczania drogi w stanie WALKA: traktować pole zajęte przez inny stwór (Jointoramix/Troll) jako przeszkodę i przeliczać ścieżkę, zamiast czekać na zwolnienie pola. Do rozważenia przez człowieka, kierunek: wykrywanie blokady stworem w pętli pościgu.
- Dwa z trzech najgorszych pościgów kończą się wyjściem 'gryzacy' na Trollu o pełnym HP, zanim cel zostanie dogoniony. (pewność 0.3)
  dowód: Najgorsze pościgi: 2 wyjścia 'gryzacy' na Trollu (hp_celu 100), kroki 4, czas ok. 3.1-3.2 s, start odl [5,2], ocena_zlego 0.3, hp_gracza 100. Trzeci: 'zawracanie', kroki 2, hp_celu 14.
  skutek: Pościg przerwany przed dobiciem; przy takim wyjściu cel może odzyskać dystans. Skala mała: 2 przypadki na 129.
  propozycja: Warunek wyjścia 'gryzacy' w funkcji oceny zagrożenia: sprawdzić próg ocena_zlego i czy wyjście powinno zależeć od zagrożenia celu, a nie od samego gryzienia przy pełnym HP gracza. Kierunek: przegląd progu, bez skracania pościgu.
- Latencja w najgorszych pościgach jest wyraźnie wyższa niż mediana, co może wiązać się z utknięciami w WALKA. (pewność 0.25)
  dowód: lat_med w najgorszych: 0.66, 0.58, 0.55 s; mediana okna krótkiego 0.18 s, długiego 0.189 s. Najgorsze pościgi są w tej samej okolicy co utknięcia (poz 33074-33079).
  skutek: Opóźnione reakcje na zmianę pozycji celu. Próba n=3, wniosek wstępny.
  propozycja: Funkcja pomiaru latencji: rozdzielić czas oczekiwania na odpowiedź klienta od czasu obliczeń decyzji i zmierzyć to osobno w strefie utknięć. Kierunek: dodać metrykę, bez zmiany logiki.
- do zmierzenia: Czy naciski z postoju (klawisz trzymany przy niezmienionej pozycji) poprzedzają utknięcia w WALKA; porównać czas naciśnięć z czasem zmiany pozycji w tych samych pościgach.
- do zmierzenia: Czy utknięcia są spowodowane blokadą przez Jointoramix/Troll (sprawdzić odległość do stworów w każdej próbce utknięcia).
- do zmierzenia: Co oznacza licznik ponow_brak (2 w krótkim, 11 w długim oknie) i czy te ponowienia skracają dojście; wymaga definicji z kodu.
- do zmierzenia: Porównanie trzymaj vs stuk: w tych danych tryb stuk nie wystąpił, więc wniosek o różnicy trybów jest niemożliwy; zebrać pościgi w obu trybach w tej samej strefie.
- do zmierzenia: Czy wyjście 'gryzacy' na Trollu z pełnym HP powtarza się w innych lokalizacjach; zebrać więcej przykładów (obecnie n=2).

## 2026-10-15 19:18 | uwaga | pościgów 5 min: 28, 30 min: 135
- Tryb trzymaj wysyła naciśnięcia, gdy postać stoi w miejscu, bo klawisz jest trzymany przez 100% czasu pościgu. (pewność 0.55)
  dowód: naciski_z_postoju 27 na 28 pościgów w oknie krótkim (0.96 na pościg) i 118 na 135 w długim (0.87 na pościg); trzymane_proc_czasu 100 w obu oknach; zmiany_kierunku_na_krok 0.33 i 0.27.
  skutek: Nadmiarowe wejścia w miejscach zablokowanych, prawdopodobnie przy utknięciach (5 w długim oknie). Dobicia nie spadają (93% i 98%), więc koszt to głównie zmarnowane wejścia, nie utrata celów.
  propozycja: Funkcja decydująca o trzymaniu klawisza w trybie trzymaj: sprawdzić, czy zwalnia klawisz, gdy pozycja nie zmienia się przez zadany czas (zmniejszyć ten czas), zamiast trzymać go do końca pościgu.
- Najgorsze pościgi kończą się wyjściem 'gryzacy' na Trollu z pełnym HP, zanim cel zostanie dogoniony, a HP gracza nie spada. (pewność 0.4)
  dowód: Dwa z trzech najgorszych pościgów to powód 'gryzacy' na Trollu z hp_celu 100 (kroki 4, czas ok. 3.1 s, odl [5,2], hp_gracza 100); gryzacy łącznie: 2 w długim oknie i 1 w krótkim.
  skutek: Pościg na celu, który nie był słaby, zostaje przerwany wcześnie. Liczba takich przypadków jest mała, więc wpływ na wynik jest ograniczony.
  propozycja: Warunek wyjścia 'gryzacy' (wykrywanie, że potwór atakuje lub stoi obok): sprawdzić, czy nie wyzwala się przy odległości 2 lub gdy cel ma pełne HP. Kierunek: wymagać spadku HP gracza lub dłuższego kontaktu przed wyjściem.
- Utknięcia pojawiają się głównie w stanie WALKA, gdy na drodze jest Troll obok celu Jointoramix. (pewność 0.35)
  dowód: Utknięcia: 5 w długim oknie i 2 w krótkim; 4 z 5 w stanie WALKA, 1 w WPADNIECIE; stwory zawsze zawierają Jointoramixa, a w 3 z 5 także Trolla; pole v 14–20, krok_s 0.66–0.94.
  skutek: Pościg stoi przez 16–23 s, zanim wraca do ruchu. Dobicia mimo to nie giną (98% w długim oknie).
  propozycja: Logika przejścia między stanami WALKA i IDZ w cavebocie: sprawdzić, czy przy obecności drugiego potwora wraca do ruchu w stronę celu. Konkretnej zmiany stałej nie da się wskazać z tej próby.
- do zmierzenia: Czy naciski_z_postoju występują właśnie w oknach utknięć i czy znikają po zwolnieniu klawisza przy braku postępu?
- do zmierzenia: Ile pościgów z 'gryzacy' ma cel w odległości 2 i ile z nich ma HP gracza bez zmian, żeby odróżnić zbyt wczesne wyjście od prawdziwego zagrożenia?
- do zmierzenia: Czy w utknięciach WALKA cel (Jointoramix) ma HP 0, a przerwa wynika z tego, że bot wybiera Trolla jako cel zamiast uciekającego potwora?
- do zmierzenia: Czy latencja jest wyższa w pościgach z utknięciami, czy po prostu w dłuższych pościgach? Potrzeba więcej próbek (n<5 dla najgorszych).
- do zmierzenia: Czy tryb stuk daje mniej naciśnięć z postoju i porównywalne dobicia? Obecne dane mają tylko trzymaj, więc porównania nie da się zrobić.

## 2026-10-15 19:20 | uwaga | pościgów 5 min: 19, 30 min: 132
- Utknięcia pojawiają się tylko w stanach WALKA/WPADNIECIE i zawsze przy obecnym Jointoramix; w 2 z 4 przypadków obecny jest też Troll. (pewność 0.3)
  dowód: okno_dlugie.utkniecia: 4 przypadki (3% z 132 pościgów), wszystkie stany WALKA/WPADNIECIE, stwory Jointoramix przy każdym, Troll w 2 (stwory: Troll,1 i Troll,2). Okno krótkie: 1 utknięcie na 19 pościgów.
  skutek: Około 3% pościgów zatrzymuje się na kilka sekund (s 16–23), co wydłuża czas dobicia; nie powoduje zgubienia (zgubienie 0).
  propozycja: Funkcja wejścia w stan WALKA: sprawdzić, czy wybór celu uwzględnia inne stwory na drodze (np. stała promienia kontroli sąsiednich stworów); rozważyć zwiększenie tego promienia. Do potwierdzenia przed zmianą.
- Klawisz 'trzymaj' jest wciskany prawie zawsze także wtedy, gdy postać stoi w miejscu, co może utrudniać wyjście z blokady. (pewność 0.2)
  dowód: okno_dlugie.trzymaj: naciski_z_postoju 114 na 132 pościgi (0.86 na pościg), trzymane_proc_czasu 100; zmiany_kierunku_na_krok 0.27.
  skutek: Nie udowodniono wpływu na utknięcia; możliwe ponowne wysyłanie kroku w blokadzie. Brak danych, czy naciski z postoju kończą się zmianą pozycji.
  propozycja: Funkcja obsługi klawisza trzymaj: rozważyć zwolnienie klawisza po N krokach bez zmiany pozycji (nowa stała progu), do oceny przez człowieka po zebraniu danych.
- Latencja w pościgach z utknięciami i w najgorszych wynosi około 0.55–0.66 s, a mediana w długim oknie to 0.2 s. (pewność 0.2)
  dowód: lat_med: okno_krotkie 0.6 s, okno_dlugie 0.2 s; najgorsze_poscigi lat_med 0.554–0.664; utkniecia nie mają zapisanej latencji.
  skutek: Możliwe opóźnienie reakcji w trudnych pościgach; brak powiązania z utknięciami udowodnionego w danych.
  propozycja: Dodać do wpisu utknięcia pole lat_med z tego samego pościgu, by sprawdzić korelację.
- do zmierzenia: Czy utknięcia korelują z latencją: zapisać lat_med dla każdego pościgu zakończonego utknięciem i porównać z pościgami bez utknięcia (wymagane n>=20 utknięć).
- do zmierzenia: Czy 'gryzacy' jest wywoływany przez atak celu, czy przez inny stwór: zapisać id atakującego przy wyjściu z pościgu.
- do zmierzenia: Czy naciski z postoju kończą się zmianą pozycji: zapisać pozycję przed i po każdym naciśnięciu w stanie postoju.
- do zmierzenia: Czy pole v=14 (krok_s 0.66) ogranicza pościg względem v=20 (krok_s 0.94): porównać liczbę utknięć i czas dobicia na obu polach.
- do zmierzenia: Dlaczego kroki_na_s (1.6) jest wyraźnie wyższe niż krok_s pola (0.66): zmierzyć, czy pole_krok_s odnosi się do innego mechanizmu.

## 2026-10-15 19:22 | uwaga | pościgów 5 min: 19, 30 min: 138
- Utrata dobić wynika prawie wyłącznie z wyjścia 'gryzacy' na Trolla z pełnym HP, a nie z zgubienia celu. (pewność 0.4)
  dowód: Okno długie: przerwane_inne=3 (gryzacy=2, zawracanie=1) z 138 pościgów, zgubienie=0. Trzy najgorsze pościgi to Troll z hp_celu=100 i ocena_zlego=0.3, wszystkie zakończone 'gryzacy' lub 'zawracanie' po 2-4 krokach.
  skutek: Około 2% pościgów kończy się bez dobicia, a cel z pełnym HP zostaje niedobity. Skuteczność dobicia spada z 100% (okno krótkie) do 98% (okno długie).
  propozycja: Funkcja oceny wyjścia z pościgu z powodem 'gryzacy': rozważyć, czy warunek nie powinien zależeć również od hp_celu i progu ocena_zlego (do przemyślenia przez człowieka, bez zmiany wartości w tej analizie).
- W najgorszych pościgach i utknięciach latencja rośnie kilkukrotnie względem mediany, a opóźnienie nie leży w decyzji. (pewność 0.35)
  dowód: lat_med w najgorszych pościgach: 0.664, 0.582, 0.554 s. Mediana lat_med w oknie długim: 0.2 s. dec_med=0.001 s, czyli czas samej decyzji jest pomijalny.
  skutek: Przy latencji ~0.6 s postać reaguje z opóźnieniem, co w pościgach kończących się po 2-4 krokach może decydować o wyjściu z pościgu.
  propozycja: Funkcja pomiaru latencji (źródło lat_s): sprawdzić, czy opóźnienie pochodzi z odczytu pozycji lub z wysyłki klawisza, i rozważyć stałą interwału odczytu pozycji lub timeoutu wysyłki.
- Wszystkie 3 utknięcia (WALKA/WPADNIECIE) mają w otoczeniu Jointoramix, a pole ma prędkość v=14 lub v=20. (pewność 0.3)
  dowód: Okno długie: utkniecia=3, każde ze stworem Jointoramix (stan 0); pole v=14 (krok_s 0.66), v=20 (krok_s 0.94). Okno krótkie: 1 utknięcie, to samo zdarzenie co trzecie w długim oknie.
  skutek: Utknięcia dotyczą 3 z 138 pościgów (~2%), ale każde wydłuża pościg o 16-23 s.
  propozycja: Funkcja wykrywania utknięcia (próg krok_s i okno czasu): rozważyć, czy stwór blokujący w stanie WALKA nie powinien być traktowany jako przeszkoda w obliczaniu drogi do celu.
- W całym oknie użyto wyłącznie trybu 'trzymaj', więc nie da się ocenić, czy wciskanie klawisza przy postoju szkodzi. (pewność 0.5)
  dowód: tryby: trzymaj n=138 (trzymane_proc_czasu=100), brak trybu stuk w obu oknach. naciski_z_postoju=121 w długim oknie (0.88 na pościg). Dobicie 98%.
  skutek: Nie wiadomo, czy naciski z postoju wydłużają utknięcia; dane pokazują tylko, że nie blokują masowo dobić.
  propozycja: Funkcja wyboru trybu klawisza (trzymaj/stuk): w danych brakuje gałęzi stuk, warto ją uruchomić na części pościgów, by mieć porównanie.
- do zmierzenia: Rozdzielić lat_s na czas odczytu pozycji i czas wysyłki klawisza, żeby zobaczyć, który etap odpowiada za 0.55-0.66 s.
- do zmierzenia: Porównać częstość wyjść 'gryzacy' przy obecności dodatkowych potworów w zasięgu i przy różnym hp_gracza.
- do zmierzenia: Zebrać co najmniej 5 utknięć z Jointoramix, żeby sprawdzić, czy powtarzają się przy v=14/20 i przy innych wartościach pola.
- do zmierzenia: Uruchomić tryb stuk na tym samym celu w kilkudziesięciu pościgach i porównać naciski_z_postoju oraz liczbę utknięć z trybem trzymaj.
- do zmierzenia: Sprawdzić, czy wyjścia 'gryzacy' na Trolla z pełnym HP są powtarzalne w tym samym miejscu mapy (poz), czy losowe.

## 2026-10-15 19:24 | uwaga | pościgów 5 min: 20, 30 min: 140
- Utknięcia pościgu koncentrują się w jednym miejscu przy Jointoramix i Trollach, głównie na polu v=14. (pewność 0.5)
  dowód: Okno długie: 5 utknięć na 140 pościgów (3,6%); wszystkie 5 ma Jointoramix w otoczeniu, 4 na polu v=14 (krok_s 0.66), 1 na v=20. Okno krótkie: 2 na 20 pościgów (10%), oba w pozycji [33086-33087,31770,8] w stanie WALKA.
  skutek: Część pościgów zatrzymuje się przy stworach blokujących trasę. W danych nie widać, że ta strata zamienia się w zgubienie, bo dobicie w oknie długim wynosi 99%.
  propozycja: Funkcja wyznaczania kroku pościgu: uwzględnić pola zajęte przez inne stwory jako nieprzejezdne albo dodać ich omijanie (kierunek: mniej utknięć przy Jointoramix). Do rozważenia przez człowieka po sprawdzeniu trasy w tym miejscu.
- Klawisz trzymany jest wysyłany także wtedy, gdy postać stoi, i dotyczy to większości pościgów. (pewność 0.35)
  dowód: Okno długie: naciski_z_postoju 119 na 140 pościgów (0,85); trzymane_proc_czasu 100%. Okno krótkie: 19 na 20 (0,95). Wysłane 174 przy 213 krokach.
  skutek: Nie wiadomo, czy wysyłki z postoju nic nie zmieniają, czy przyspieszają ruch. Dane nie rozstrzygają tego, bo nie ma trybu stuk do porównania.
  propozycja: Funkcja obsługi trzymania klawisza: sprawdzać, czy pozycja zmieniła się od ostatniej wysyłki, zanim klawisz zostanie wysłany ponownie. Kierunek: ograniczyć wysyłki bez przesunięcia.
- W danych nie ma żadnego pościgu w trybie stuk, więc nie da się ocenić, który tryb jest lepszy. (pewność 0.9)
  dowód: Tryby: wyłącznie 'trzymaj' w obu oknach (n=20 i n=140). Tryb 'stuk' ma n=0, a 'trzymane_proc_czasu' wynosi 100%.
  skutek: Wybór trybu 'trzymaj' nie jest poparty porównaniem z 'stuk'. Może być optymalny albo nie.
  propozycja: Stała wyboru trybu ruchu w konfiguracji pościgu: dodać możliwość wymuszenia trybu 'stuk' na próbce testowej, aby uzyskać porównanie.
- Statystyka zgubień nie zgadza się z liczbą epizodów zgubionych przez cel. (pewność 0.5)
  dowód: Okno krótkie: epizody_celu.zgubione = 1, koniec.zgubienie = 0, powod_top 'zniknął z widoku żywy'. Okno długie: epizody zgubione = 1, koniec.zgubienie = 0, przerwane_inne = 2. Pole 'niespojnosci' jest puste mimo tej rozbieżności.
  skutek: Zgubienia mogą być niedoliczane w statystyce końca pościgu, więc wskaźnik 100% lub 99% dobić może być zawyżony.
  propozycja: Funkcja klasyfikacji zakończenia pościgu: mapować przypadek 'cel zniknął z widoku żywy' na powód 'zgubienie' albo logować powód zakończenia z identyfikatorem epizodu, aby można było to zestawić.
- Opóźnienie odczytu stanu gry, a nie decyzja, jest najprawdopodobniej źródłem długich pościgów. (pewność 0.3)
  dowód: Mediana latencji 0,185 s (krótkie) i 0,189 s (długie), dec_med 0,0-0,001 s. Najgorsze pościgi: lat_med 0,664 s i 0,554 s, ale n=2.
  skutek: W najgorszych pościgach ruch jest opóźniony o kilkaset ms, co wydłuża dojście do celu. Próba zbyt mała, by to potwierdzić.
  propozycja: Funkcja odczytu pozycji i stanu z gry: zmierzyć czas od odczytu do wysłania klawisza na każdej próbce, aby zobaczyć, czy wysokie wartości są stałe, czy losowe.
- do zmierzenia: Czy utknięcia przy Jointoramix wynikają z trasy przez pole zajęte przez stwór? Zapisać pozycje wszystkich stworów i wybraną ścieżkę w chwili każdego utknięcia.
- do zmierzenia: Czy wysyłki klawisza z postoju powodują ruch? Porównać liczbę wysłanych klawiszy z faktycznym przesunięciem pozycji w tych samych oknach czasowych.
- do zmierzenia: Jaka jest wydajność trybu 'stuk' względem 'trzymaj' na tych samych celach? Potrzebna krótka próba z wymuszonym trybem 'stuk'.
- do zmierzenia: Co oznacza 'pole v' w utknięciu: prędkość pola na trasie czy w punkcie zatrzymania? Logować v dla każdego kroku trasy.
- do zmierzenia: Dlaczego pościg zakończył się 'gryzacy' (Troll, hp 100) i 'zawracanie' (Troll, hp 14)? Oba przypadki mają n=1; zebrać kolejne przykłady tych powodów.

## 2026-10-15 19:26 | uwaga | pościgów 5 min: 23, 30 min: 147
- Liczba zgubień w podsumowaniu pościgów nie zgadza się z liczbą epizodów celu, w których cel zniknął. (pewność 0.6)
  dowód: okno_dlugie: koniec.zgubienie=0 (zgubienie_proc=0), ale epizody_celu.zgubione=1; przerwane_inne=2, a w danych nie ma pola opisującego te dwa przypadki.
  skutek: Jedna utrata celu może być niewidoczna w statystyce pościgów, więc ocena skuteczności (99% dobicia) może być zawyżona.
  propozycja: Sprawdzić funkcję klasyfikującą koniec pościgu (wyjście z pętli) i funkcję zliczającą epizody celu: czy przypadek zgubienia trafia do przerwane_inne lub nie jest zapisywany jako pościg. Ujednolicić jedną regułę klasyfikacji.
- Utknięcia w pościgu występują głównie w walce z kilkoma Trollami, na polu o niskiej prędkości kroku. (pewność 0.4)
  dowód: okno_dlugie: utkniecia=5 na 147 pościgów (3,4%); 4 z 5 w stanie WALKA z 2 Trollami (w jednym 3 stwory), pole krok_s=0.66 w 3 z 5 przypadków, krok_s=0.94 w 1. okno_krotkie: 2 utkniecia, oba WALKA, oba z 2 Trollami, krok_s=0.66.
  skutek: Każde utknięcie wydłuża pościg bez postępu w odległości, choć do tej pory nie spowodowało zgubienia celu (zgubienie=0 w obu oknach).
  propozycja: Funkcję wyznaczania ścieżki pościgu (kandydaci kroków) rozszerzyć o omijanie pól zajętych przez inne potwory, szczególnie gdy w pobliżu jest więcej niż jeden stwór. Zmiana w kodzie, do oceny przez człowieka.
- Najgorsze pościgi mają wyraźnie wyższe opóźnienie odczytu stanu niż typowe, co może tłumaczyć ich słabszy przebieg. (pewność 0.3)
  dowód: najgorsze_poscigi: lat_med 0.664 i 0.554 s, przy medianie 0.2 s w obu oknach; w obu przypadkach kroki 2-4, czas 0.7-3.2 s. Próba n=2.
  skutek: Przy dużym opóźnieniu decyzja opiera się na nieaktualnej pozycji celu, co może powodować zawracanie lub zbędne kroki.
  propozycja: Funkcję odczytu pozycji i HP celu oraz jej częstotliwość (interwał pętli pościgu) oznaczyć do pomiaru rozkładu latencji. Nie zmieniać jeszcze stałych, dopóki nie będzie większej próby.
- Tryb trzymaj wymusza częste zmiany kierunku w trakcie pościgu i naciski z postoju, co może psuć płynność biegu. (pewność 0.3)
  dowód: okno_dlugie: zmiany_kierunku=52 na 210 kroków (0.25/krok), naciski_z_postoju=125 na 147 pościgów (0.85/pościg), trzymane_proc_czasu=100%; okno_krotkie: zmiany_kierunku_na_krok=0.15.
  skutek: Część naciśnięć klawisza przypada na postój lub korektę kierunku, co może wydłużać czas dojścia do celu, choć nie widać tego w brakach dojścia (bez_dojscia=0).
  propozycja: Funkcję decyzji kierunku w trybie trzymaj (kiedy zmienić kierunek i kiedy puścić klawisz) rozważyć do przeglądu pod kątem zbędnych zmian. Porównać z trybem stuk.
- Nie da się porównać trybów trzymaj i stuk, bo w danych nie ma żadnego pościgu w trybie stuk. (pewność 0.9)
  dowód: okno_krotkie i okno_dlugie: tryby zawierają tylko trzymaj (n=23 i n=147), brak wpisów stuk; odrzucone=0 w obu oknach.
  skutek: Nie wiadomo, czy trzymaj jest lepszy od stuk pod względem kroków na sekundę i liczby zmian kierunku.
  propozycja: Nie wnioskować o wyższości trybu. Zebrać dane z pościgów w trybie stuk przy tej samej konfiguracji, żeby porównać kroki_na_s i zmiany_kierunku.
- do zmierzenia: Czy przypadek zgubienia (zgubione=1) i przerwane_inne=2 to ten sam pościg, czy osobne zdarzenia? Zapisać identyfikator pościgu przy każdym wyjściu.
- do zmierzenia: Czy utknięcia w walce z Trollami wynikają z zajętych pól na ścieżce? Zapisać pola zajęte przez inne stwory w chwili utknięcia.
- do zmierzenia: Czy wysokie lat_med dotyczy wszystkich pościgów z wieloma potworami w zasięgu? Rozkład lat_med w podziale na liczbę stworów w pobliżu.
- do zmierzenia: Ile zmian kierunku w trybie trzymaj to korekty po pozycji celu, a ile wynika z ruchu po ścieżce? Zapisać powód każdej zmiany kierunku.
- do zmierzenia: Jak wygląda kroki_na_s i liczba zmian kierunku w trybie stuk przy tych samych warunkach (pole, liczba stworów)?

## 2026-10-15 19:28 | uwaga | pościgów 5 min: 26, 30 min: 138
- Pościgi kończą się dobiciem w 98,6% przypadków (136/138 w oknie długim, 26/26 w krótkim); utratę dobić dają wyłącznie wyjścia 'zawracanie' i 'gryzacy'. (pewność 0.35)
  dowód: okno_dlugie: koniec.dobicie=136, przerwane_inne=2, powody_wyjsc zawracanie=1, gryzacy=1; okno_krotkie: dobicie=26, przerwane_inne=0
  skutek: 2 pościgi na 138 zakończyły się bez dobicia; z tej próby nie widać przyczyny, n=2
  propozycja: Sprawdzić funkcję warunku wyjścia z pościgu dla powodów 'zawracanie' i 'gryzacy' i to, czy chwilowe odsunięcie celu nie wywołuje wyjścia (opis zmiany warunku, bez skracania pościgu)
- Liczba zgubionych epizodów nie zgadza się z liczbą pościgów zakończonych zgubieniem: epizody zgubione są, a zgubienie pościgu wynosi zero. (pewność 0.5)
  dowód: okno_dlugie: epizody_celu.zgubione=2 przy koniec.zgubienie=0; okno_krotkie: epizody.zgubione=1 przy koniec.zgubienie=0; epizody_celu.wskaznik 95 (60/63)
  skutek: Wskaźnik skuteczności epizodów (95%) może być błędnie policzony albo epizod nie jest mapowany na pościgi, więc nie wiadomo, ile celów naprawdę zginęło z widoku
  propozycja: Sprawdzić funkcję zamykającą epizod, która nadaje status 'zgubione', i to, czy uwzględnia pościgi zakończone innym powodem
- Utkniecia pojawiają się w walce z trollami przy prędkości pola 14, a w każdym przypadku obecny jest Jointoramix. (pewność 0.3)
  dowód: utkniecia: długie 5 (7 łącznie z krótkim oknem), wszystkie 7 zawiera Jointoramix, 6/7 zawiera Trolla w odl. 1-3, pole v=14 w 6/7; stany WALKA lub WPADNIECIE
  skutek: Pościg w tych chwilach stoi lub się wydłuża; w danych nie widać, czy to kosztuje dobicia (wszystkie pościgi z utknięciem zakończyły się dobiciem lub nie wynikają z danych)
  propozycja: Rozważyć, czy funkcja wyboru kroku uwzględnia pola zajęte przez inne potwory jako przeszkody; sprawdzić, czy wybór ścieżki ignoruje stwory stojące na drodze
- Trzymany klawisz jest wciśnięty także w postoju: naciski z postoju występują w większości pościgów i trzymanie trwa przez cały czas pościgu. (pewność 0.25)
  dowód: okno_dlugie: naciski_z_postoju=129 przy 138 pościgach (0,93 na pościg), trzymane_proc_czasu=100; okno_krotkie: naciski_z_postoju=26 (1,0 na pościg)
  skutek: Jeśli postać stoi, a klawisz jest wciśnięty, może dochodzić do dociskania w zablokowane pole, co łączy się z utknięciami; związku nie udowodniono
  propozycja: Rozważyć funkcję trzymania klawisza: dodać warunek puszczenia, gdy pozycja nie zmienia się przez stałą czasu braku ruchu (nazwa stałej np. CZAS_BRAKU_RUCHU_S, kierunek: krótszy czas puszczenia)
- do zmierzenia: Czy utkniecia poprzedzają naciski z postoju o kilka sekund (sekwencja czasowa w 7 zdarzeniach i w kolejnych oknach)?
- do zmierzenia: Jakie były odległość, opóźnienie odczytu (lat_med) i pozycja w ostatnich 10 s przed wyjściami 'zawracanie' i 'gryzacy' oraz przy pościgach zakończonych dobiciem (większa próba niż n=2)?
- do zmierzenia: Które pościgi należą do dwóch zgubionych epizodów, i czy ich zakończenie było innym powodem niż cel_znikl?
- do zmierzenia: Porównanie trzymaj vs stuk w tym samym oknie czasowym: w danych nie ma żadnego pościgu w trybie stuk, więc wpływu trybu na wynik nie da się oszacować.
- do zmierzenia: Czy pola v=14 (krok 0,66 s) powodują więcej utknięć na kilometr trasy niż v=20 (krok 0,94 s)? Obecnie próba to 6 zdarzeń przy v=14 i 1 przy v=20.

## 2026-10-15 19:30 | uwaga | pościgów 5 min: 29, 30 min: 135
- Liczba zgubionych epizodów celu nie zgadza się z liczbą pościgów zakończonych zgubieniem, a pole niespojnosci jest puste, więc ta rozbieżność nie została wykryta. (pewność 0.6)
  dowód: Okno krótkie: epizody_celu.zgubione=1, koniec.zgubienie=0. Okno długie: epizody_celu.zgubione=2, koniec.zgubienie=0, przerwane_inne=2. Sumy epizodów się zgadzają (12=11+0+1, 67=64+1+2), więc rozbieżność dotyczy klasyfikacji końca pościgu, a nie arytmetyki.
  skutek: Zgubienia mogą być niedoliczane jako pościgi. Wskaźnik dobić (99–100%) może wyglądać lepiej niż jest, a przyczyny utraty celu są nieczytelne.
  propozycja: Funkcja mapująca koniec epizodu na koniec pościgu (klasyfikacja zgubienie/dobicie/przerwane_inne): sprawdzić, czy epizod zgubiony bez wpisu w powodach trafia do 'dobicie' lub zostaje pominięty. Kierunek: każdy zgubiony epizod powinien mieć odpowiadający mu koniec 'zgubienie' lub 'przerwane_inne'.
- Utknięcia występują prawie wyłącznie przy obecności Jointoramix i trolli w stanie walki, przy prędkości pola 14. (pewność 0.4)
  dowód: Okno długie: 5 utknięć na 135 pościgów (3,7%). Jointoramix obecny w 5/5, stan WALKA w 4/5, troll w pobliżu w 4/5, pole v=14 w 4/5 (krok_s 0,66). Jedyne utknięcie w WPADNIECIE (19:17:47) bez trolli. Okno krótkie: 1 utknięcie, również z Jointoramix i trollami, v
  skutek: Pościg staje na czas przerwania, a cel może uciec lub postać nie dochodzi do dobicia. W danych nie widać bezpośredniej straty dobić, ale utknięcia są stale związane z tą samą sytuacją.
  propozycja: Warunek wejścia w pościg z stanu WALKA (funkcja decyzji przejścia WALKA->POŚCIG): rozważyć uwzględnienie obecności Jointoramix w pobliżu celu. Kierunek: pościg w takiej sytuacji powinien być ograniczony lub odłożony. Do rozważenia przez człowieka.
- Klawisz kierunku jest trzymany przez cały czas pościgu, a w większości pościgów naciskany także podczas postoju, co może zwiększać przesterowanie wokół celu. (pewność 0.35)
  dowód: trzymane_proc_czasu=100% w obu oknach. Naciski z postoju: 122 z 135 pościgów (90%), 0,9 na pościg. Zmiany kierunku 0,25 na krok (52 w długim oknie). Mediana kroków na sekundę: 1,61 (trzymaj) vs 2,08 ogółem. Dobicie nadal 99%.
  skutek: Nie widać straty dobić, więc koszt jest raczej pośredni (dodatkowe kroki i zmiany kierunku bez postępu). Dowód na szkodę jest słaby.
  propozycja: Funkcja trzymania klawisza: rozważyć puszczanie klawisza po osiągnięciu odległości <=1 (lub przy braku postępu), bez zmiany progu dobicia. Kierunek: mniej naciśnięć z postoju.
- Dwa najgorsze pościgi z trollami miały wyraźnie wyższą latencję niż mediana, co może być tłem niedobić. (pewność 0.25)
  dowód: lat_med 0,664 s (19:15:55, gryzący, 4 kroki) i 0,554 s (19:14:06, zawracanie, 2 kroki), przy medianie 0,2 s w długim oknie. Oba cele osiągalne (droga 9 i 4). Te dwa pościgi to jedyne niedobicia poza przerwanymi_inne.
  skutek: Niedobicia to 2 z 135 pościgów (1,5%). Próba jest bardzo mała, więc wniosek jest niepewny.
  propozycja: Brak zmiany w kodzie na tym etapie; zbadać zależność latencji od wyniku pościgu na większej próbie.
- Znaczenie drugiej wartości w polu 'stwory' (np. [Jointoramix,0]) nie jest jednoznaczne, więc interpretacja utknięć może być błędna. (pewność 0.5)
  dowód: Jointoramix występuje zawsze z wartością 0, a trolle z 1–3. Nie wiadomo, czy to odległość, stan czy inna cecha.
  skutek: Wnioski o blokowaniu przez Jointoramix mogą być fałszywe, jeśli wartość oznacza coś innego.
  propozycja: Ustalić w kodzie, co zapisuje drugi element tablicy 'stwory' (odległość, stan, HP).

## 2026-10-15 19:32 | ok | pościgów 5 min: 33, 30 min: 145
- Pościgi kończą się dobiciem w 98% przypadków (142/145 w oknie długim), bez zgubień, a dystans do celu maleje z mediany 2 do 1. (pewność 0.8)
  dowód: okno_dlugie: dobicie 142, zgubienie 0, bez_dojscia 1, przerwane_inne 2; odleglosc start_med 2, koniec_med 1, delta_med -1; okno_krotkie dobicie_proc 97.
  skutek: Brak istotnej utraty dobić. Pozostałe 3 nieudane pościgi (1 brak_ruchu, 2 przerwane_inne) to zbyt mało, żeby wskazać wzorzec.
  propozycja: Brak zmiany wymaganej. Monitorować przerwane_inne, żeby sprawdzić, czy ich liczba nie rośnie.
- Najgorsze pościgi z trollami mają latencję około 3 razy wyższą niż mediana, a utknięcia występują wyłącznie w walce z wieloma stworami. (pewność 0.3)
  dowód: najgorsze_poscigi: lat_med 0.574, 0.664, 0.554 s przy medianie 0.186 s w oknie długim; utkniecia 5 (stany WALKA/WPADNIECIE), każde z Jointoramix i Trollami na odl 1-3, pole v 14-20.
  skutek: Wolniejsza reakcja na zmiany pozycji celu w tłoku. Dotyczy 3 pościgów (n<5), więc pewność niska, a dobicia mimo to nastąpiły w 2 z 3 przypadków.
  propozycja: Funkcja odczytu pozycji celu i gracza w pętli pościgu (źródło lat_med): skrócić cykl odczytu w stanie walki, nie wydłużać timeoutów pętli.
- Klawisz kierunku jest trzymany przez 100% czasu pościgu i naciskany podczas postoju w 88% pościgów, ale nie widać z tych danych przesterowania. (pewność 0.3)
  dowód: trzymane_proc_czasu 100; naciski_z_postoju 128 na 145 pościgów (0.88 na pościg); oscylacje 0; zmiany_kierunku_na_krok 0.28.
  skutek: Możliwe marnowanie kroków przy celu, ale oscylacji nie zaobserwowano, więc koszt nie jest potwierdzony.
  propozycja: Funkcja obsługi klawisza kierunku w pętli pościgu: zwalniać klawisz, gdy odl<=1, zamiast go trzymać. Zmiana do rozważenia po pomiarze z hipotezy poniżej.
- Utknięcia są rzadkie (5/145, ok. 3%) i nie wpływają na wynik dobicia. (pewność 0.25)
  dowód: utkniecia.liczba 5 w oknie długim; dobicie_proc 98; utkniecia.ostatnie wszystkie w WALKA lub WPADNIECIE.
  skutek: Niewielki koszt czasu w tłoku, bez wpływu na skuteczność.
  propozycja: Funkcja wyboru ścieżki, gdy droga jest zablokowana przez inne stwory: omijać zajęte pola. Priorytet niski.
- Liczba zgubień w epizodach celu (3) nie zgadza się z liczbą zgubień w wyniku pościgów (0). (pewność 0.5)
  dowód: okno_dlugie.epizody_celu.zgubione 3 oraz koniec.zgubienie 0 i zgubienie_proc 0; epizody 67 vs pościgi 145.
  skutek: Metryki mogą mylnie pokazywać utratę celów, co utrudnia ocenę.
  propozycja: Funkcja liczenia statystyk: ujednolicić definicję zgubienia między epizodami celu a wynikiem pościgu.

## 2026-10-15 19:34 | uwaga | pościgów 5 min: 35, 30 min: 147
- Liczba zgubień na poziomie epizodów celu nie zgadza się z liczbą zgubień na poziomie pościgów, więc część utraconych celów może być klasyfikowana jako inny koniec. (pewność 0.6)
  dowód: okno_dlugie: epizody_celu zabite 63 + porzucone 2 + zgubione 3 = 68 epizodów; koniec pościgów: dobicie 144 + bez_dojscia 1 + przerwane_inne 2 = 147, zgubienie 0. Powód_top epizodów to 'zniknął z widoku żywy'. Okno krótkie: zgubione 1 w epizodach, zgubienie 0 w
  skutek: Wskaźnik zgubień (0%) może być zaniżony, a prawdziwa utrata dobić nie jest widoczna w głównej statystyce wyniku.
  propozycja: Funkcja mapująca koniec epizodu na koniec pościgu: sprawdzić, czy powód 'zniknął z widoku żywy' trafia do 'przerwane_inne' zamiast 'zgubienie'; ujednolicić klasyfikację w jednym miejscu.
- Utknięcia pojawiają się głównie w stanach WALKA/WPADNIECIE, gdy w pobliżu jest Jointoramix i troll, a postać przestaje się przemieszczać. (pewność 0.35)
  dowód: utkniecia 5/147 (3,4%); 5 z 5 w stanach WALKA lub WPADNIECIE; Jointoramix w każdym przypadku na odl 0; pole v 14–20, krok_s 0,66–0,94; dobicie 144/147 mimo utknięć.
  skutek: Pojedyncze pościgi trwają dłużej; w danych nie widać wpływu na wynik dobicia.
  propozycja: Warunek przejścia ze stanu WALKA lub WPADNIECIE, gdy w pobliżu znajduje się dodatkowy stwór (inny niż cel): opisać, czy stan blokuje ruch, i rozważyć jego wcześniejsze zakończenie.
- Klawisz kierunku jest trzymany przez cały pościg, a naciśnięcia z postoju występują w większości pościgów, co może oznaczać przesterowanie przy celu na odległości 1. (pewność 0.3)
  dowód: trzymane_proc_czasu 100%; naciski_z_postoju 124 na 147 pościgów (0,84 na pościg); zmiany_kierunku_na_krok 0,28; kroki_na_s med 1,4 (p10 1,04, p90 1,86); trzymaj n=147, stuk n=0.
  skutek: Możliwe zbędne ruchy przy dobijaniu; nie da się stwierdzić z tych danych, czy wpływa to na czas dobicia.
  propozycja: Funkcja obsługi klawisza kierunku w trybie trzymaj: rozważyć zwolnienie klawisza, gdy odległość do celu wynosi 1, i zmierzyć liczbę naciśnięć na krok w tym stanie.
- Najgorsze pościgi to trzy przypadki z trollem o pełnym HP, zakończone brakiem ruchu lub zawracaniem; próba jest za mała, by wyciągnąć wniosek. (pewność 0.2)
  dowód: najgorsze_poscigi n=3: troll hp 100, brak_ruchu w 2,63 s (2 kroki, odl 5→2, stan UH, ocena_zlego 3,3); troll hp 100 gryzący; troll hp 14 zawracanie; hp_gracza 100 we wszystkich.
  skutek: Brak wyraźnego kosztu w danych; ryzyko dotyczy przypadków z pełnym HP celu.
  propozycja: Sprawdzić, jak stan UH wpływa na funkcję decyzji ruchu, gdy cel ma pełne HP; zebrać więcej przypadków przed zmianą.
- do zmierzenia: Czy powód 'przerwane_inne' (2 w oknie długim) odpowiada zgubionym celom z epizodów: zalogować powód końca pościgu razem z powodem końca epizodu.
- do zmierzenia: Jak zmienia się liczba naciśnięć klawisza kierunku na krok, gdy odległość do celu wynosi 1, w porównaniu z odległością 2 lub więcej (osobna metryka dla odl<=1).
- do zmierzenia: Porównanie trzymaj vs stuk wymaga uruchomienia obu trybów w tym samym oknie czasu; obecne dane mają stuk n=0, więc nie da się rozstrzygnąć, który tryb daje lepsze dobicie.
- do zmierzenia: Czy utknięcia przy Jointoramix na odl 0 są związane z blokowaniem przez stwór, czy z kolizją pola: zapisać pozycje sąsiednich pól i zajętość w chwili utknięcia.
- do zmierzenia: Czy troll z pełnym HP w stanie UH częściej kończy się brakiem ruchu: zebrać co najmniej 10 takich pościgów, zamiast 3.

## 2026-10-15 19:36 | uwaga | pościgów 5 min: 22, 30 min: 142
- Najgorsze pościgi mają wyraźnie wyższą latencję niż typowe, co może być powodem zawracania lub zatrzymania. (pewność 0.3)
  dowód: lat_med 0,574 / 0,664 / 0,554 s w trzech najgorszych pościgach wobec lat_med 0,186 s globalnie (ok. 3x); powody: brak_ruchu, gryzacy, zawracanie; hp_gracza 100 we wszystkich trzech.
  skutek: Gdy reakcja jest spóźniona, cel zdąży zmienić pozycję i pościg się rozjeżdża; przy n=3 nie da się tego potwierdzić.
  propozycja: Funkcja pomiaru/odświeżania stanu (odczyt pozycji stworów) – sprawdzić, czy czas przetwarzania rośnie wraz z liczbą stworów w zasięgu; nie zmieniać zachowania pościgu bez tych danych.
- Klawisz kierunku jest trzymany przez cały pościg, a większość pościgów ma naciśnięcia wykonane z postoju. (pewność 0.4)
  dowód: trzymane_proc_czasu=100 w obu oknach; naciski_z_postoju 119 w 142 pościgach (0,84 na pościg); zmiany_kierunku 0,29 na krok; oscylacje 0.
  skutek: Naciski z postoju mogą być niegroźne (przy odl<=1 pościg i tak kończy się dobiciem w 98%), ale utrudniają diagnozę, czy postać faktycznie stoi, czy atakuje.
  propozycja: Funkcja trzymania klawisza kierunku: sprawdzić, czy naciski z postoju występują przy odl=1 (atak); jeśli tak, zapisać to jako stan 'walka' zamiast 'ruch', żeby nie mylić z utknięciem.
- Zgubienia celu zdarzają się rzadko, a głównym powodem jest zniknięcie celu z widoku przy żywym HP. (pewność 0.35)
  dowód: zgubione 3 z 68 epizodów celu w oknie długim (4,4%); powod_top 'zniknął z widoku żywy'; zgubienie 0 w oknie krótkim; wskaznik zabitych 93%.
  skutek: Ok. 4% epizodów kończy się utratą celu, która nie wynika z dobicia; to mała strata, ale stała.
  propozycja: Funkcja ponownego namierzania po zniknięciu celu z widoku (logika szukania po zniknięciu): zbadać, czy cel znika na krawędzi ekranu lub za innym stworem; nie skracać czasu pościgu.
- do zmierzenia: Czy czas przetwarzania pętli rośnie z liczbą stworów w zasięgu (zapisać lat_med razem z liczbą stworów w każdej próbce)?
- do zmierzenia: Czy utknięcia zawsze mają zajęte pole na drodze do celu (zapisać zajętość sąsiednich pól w momencie wejścia w utknięcie)?
- do zmierzenia: Czy naciski z postoju zachodzą przy odl=1 (zapisać odległość w chwili każdego naciśnięcia)?
- do zmierzenia: Czy trzy zgubienia mają wspólne położenie, np. krawędź ekranu lub przeszkoda (zapisać współrzędne ostatniej widzianej pozycji celu)?
- do zmierzenia: Czy n=3 najgorszych pościgów z trollem to przypadek, czy powtarzający się wzorzec (zebrać co najmniej 15 pościgów z trollem o pełnym HP)?

## 2026-10-15 19:38 | uwaga | pościgów 5 min: 16, 30 min: 141
- Najgorsze pościgi mają wyraźnie wyższą latencję (0.55–0.66 s) niż typowe (med 0.2 s), a w każdym z nich pojawia się zawracanie, gryzienie lub brak ruchu. (pewność 0.3)
  dowód: najgorsze_poscigi: lat_med 0.574, 0.664, 0.554 przy typowym lat_med 0.2 (okno długie); powody: brak_ruchu, gryzacy, zawracanie; okno długie przerwane_inne 2 + bez_dojscia 1 z 141 pościgów
  skutek: Około 3,5% pościgów kończy się bez dobicia; to najczęstsza przyczyna odchyleń od dobicia 98%.
  propozycja: Zmierzyć, czy latencja w tych pościgach koreluje z opóźnieniem wysłania klawisza kierunku. Jeśli tak, rozważyć stałą określającą maksymalny czas oczekiwania na potwierdzenie ruchu przed wysłaniem kolejnego klawisza (zmniejszenie, nie usuwanie pościgu).
- Utknięcia występują wyłącznie w stanach WALKA/WPADNIĘCIE przy obecności Trolla, na polach o niskiej prędkości kroku. (pewność 0.35)
  dowód: utkniecia.liczba 5 (okno długie); stany WALKA x4, WPADNIECIE x1; pole krok_s 0.66 (v=14) w 4 przypadkach i 0.94 (v=20) w 1; stwory Troll obecny we wszystkich 5
  skutek: Postać stoi w walce zamiast gonić, co wydłuża pościg; kroki_na_s p10 1.12 vs med 1.6.
  propozycja: Sprawdzić funkcję decydującą o przejściu ze stanu WALKA do IDŹ przy wielu celach (Troll + Jointoramix); rozważyć stałą progu liczby celów w zasięgu, po której pościg nie czeka na walkę. Próba n=5, więc pewność niska.
- Klawisz kierunku jest wciśnięty przez cały pościg, ale często ponownie wysyłany z postoju, co może spowalniać ruch w tle. (pewność 0.4)
  dowód: trzymane_proc_czasu 100%; naciski_z_postoju 122 na 141 pościgów (0.87 na pościg); zmiany_kierunku_na_krok 0.28 (okno długie) vs 0.21 (krótkie); kroki_na_s_ogolem 2.06
  skutek: Każdy ponowny naciśnięcie z postoju może opóźniać start kroku; nie widać bezpośredniego spadku dobić (98%), więc koszt jest pośredni.
  propozycja: Zbadać funkcję ponownego wysyłania klawisza kierunku (częstotliwość i warunek 'brak zmiany pozycji'); rozważyć stałą minimalnego odstępu między ponownymi naciśnięciami.
- Liczba zgubionych celów w statystykach epizodów (3) nie zgadza się z liczbą zgubień na poziomie pościgu (0). (pewność 0.5)
  dowód: epizody_celu okno długie: zgubione 3, porzucone 2, zabite 64 z 69 (wskaznik 93); koniec.zgubienie 0 i zgubienie_proc 0 w tym samym oknie; powod_top 'zniknął z widoku żywy'
  skutek: Nie wiadomo, czy realna utrata celów to 0% czy ~4%; utrudnia to ocenę skuteczności pościgu.
  propozycja: Ujednolicić definicję 'zgubienia' między liczeniem pościgów a epizodów celu (np. licznik epizodu, który obejmuje kilka pościgów po zmianie celu).
- do zmierzenia: Czy latencja powyżej 0.5 s przed pościgiem przewiduje zawracanie lub brak ruchu (potrzebne więcej pościgów z latencją >0.5 s, obecnie n=3).
- do zmierzenia: Czy utknięcia zdarzają się przy stałym typie terenu (pole v=14) niezależnie od Trolla (test na pościgach bez Trolla na tym samym polu).
- do zmierzenia: Ile naciśnięć z postoju poprzedza kroki o opóźnieniu >0.5 s (korelacja liczby ponownych wysłań z opóźnieniem kroku).
- do zmierzenia: Czy 'zniknął z widoku żywy' w epizodach odpowiada pościgom zakończonym jako przerwane_inne lub zgubienie (zgodność definicji obu liczników).

## 2026-10-15 19:41 | uwaga | pościgów 5 min: 24, 30 min: 151
- Najgorsze pościgi mają wysoką latencję (lat_med 0.55–0.66 s), podczas gdy globalnie wynosi ona 0.2 s; wszystkie trzy dotyczą Trolla. (pewność 0.3)
  dowód: najgorsze_poscigi: lat_med 0.574, 0.664, 0.554; okno długie lat_med 0.2 i dec_med 0.001; wszystkie trzy cel=Troll; kroki_na_s 0.76, 1.25, 2.72; kroki 2–4.
  skutek: Reakcja na ruch celu jest opóźniona o kilkaset milisekund, co może wydłużać dojście lub prowadzić do zawracania i braku ruchu. Próba jest mała (n=3).
  propozycja: Stała lub funkcja odczytu pozycji celu i wysyłki kroku w pętli pościgu: najpierw zmierzyć źródło opóźnienia (odczyt czy serwer), a dopiero potem rozważyć zmianę. Nie zmieniać bez pomiaru.
- Tryb trzymaj jest wciśnięty przez cały pościg, ale klawisz jest często wysyłany ponownie z postoju, a tempo kroków ma długi ogon w dół. (pewność 0.3)
  dowód: okno długie: naciski_z_postoju=122 (0.81 na pościg), zmiany_kierunku_na_krok=0.29, trzymane_proc_czasu=100; kroki_na_s med 1.61, p10 1.12; w oknie krótkim med 1.9, p10 1.65.
  skutek: Część kroków przypada na ponowne naciśnięcia z postoju, co może obniżać efektywne tempo w ogonie rozkładu. Nie ma jeszcze dowodu, że to jest przyczyną spadku tempa.
  propozycja: Funkcja wysyłki kierunku w trybie trzymaj: zbadać, czy liczba ponownych wysyłek z postoju koreluje z kroki_na_s p10 w obrębie tego samego pola. Nie zmieniać wartości interwałów bez tego pomiaru.
- Liczniki zgubień są sprzeczne: epizody celu raportują 3 zgubione, a poziom pościgu raportuje 0 zgubień. (pewność 0.7)
  dowód: epizody_celu.zgubione=3 (powod_top „zniknął z widoku żywy”), wskaznik 92; koniec.zgubienie=0, zgubienie_proc=0; niespojnosci=[] mimo rozbieżności.
  skutek: Nie da się rzetelnie ocenić wskaźnika zgubień: 0% czy około 2%. Może to zaniżać diagnozę pościgów zakończonych zniknięciem celu.
  propozycja: Funkcja klasyfikacji końca pościgu i funkcja zliczania epizodów celu: ujednolicić definicję „zgubienia” w obu licznikach, tak aby zniknięcie celu było liczone tylko raz i tym samym kryterium.
- do zmierzenia: Czy utknięcia WALKA/WPADNIĘCIE są skorelowane z atakami Trolla: zapisać HP gracza i sygnał ataku w każdej ramce utknięcia (w danych HP gracza jest tylko w najgorszych pościgach).
- do zmierzenia: Czy niskie kroki_na_s wynikają z pola (krok_s) niezależnie od obecności Trolla: porównać tempo na tych samych polach bez Trolla.
- do zmierzenia: Czy opóźnienie 0.55–0.66 s przy Trollu leży po stronie odczytu pozycji, czy po stronie serwera: zmierzyć czas od wysłania klawisza do zmiany pozycji w logu.
- do zmierzenia: Porównanie trzymaj vs stuk nie jest możliwe, bo stuk nie był użyty w żadnym oknie; wymagany byłby przebieg z obydwoma trybami na tym samym polu.
- do zmierzenia: Czy trzy epizody „zniknął z widoku żywy” odpowiadają pościgom z końcem innym niż zgubienie (np. przerwane_inne lub porzucone): zestawić identyfikatory epizodów z identyfikatorami pościgów.

## 2026-10-15 19:43 | uwaga | pościgów 5 min: 23, 30 min: 149
- Najgorsze pościgi dotyczą wyłącznie Trolli i mają wielokrotnie wyższą latencję niż średnia globalna. (pewność 0.4)
  dowód: najgorsze_poscigi: lat_med 0.574, 0.664, 0.554 s (n=3); globalnie lat_med 0.2 s w obu oknach. Wszystkie trzy to Troll, stany UH/IDZ/WALKA, powody brak_ruchu/gryzacy/zawracanie.
  skutek: Wolniejsza reakcja na ucieczkę celu, co prowadzi do zawracania, gryzienia i braku ruchu zamiast dobicia. Przy n=3 wniosek jest słaby.
  propozycja: Sprawdzić w kodzie pętli pościgu, czy przy wielu potworach w zasięgu (np. Trolle obok celu) nie dochodzi do blokady lub opóźnienia wysyłania ruchu; rozważyć stałą progu liczby potworów w pobliżu, przy której pościg jest wstrzymywany lub przekazywany walce. Kierunek do oceny przez człowieka.
- Utknięcia pojawiają się głównie w stanach WALKA/WPADNIECIE, gdy w pobliżu stoją Trolle, a pole ma niską prędkość kroków. (pewność 0.35)
  dowód: utkniecia.liczba 5 w oknie 1800 s (3% z 149 pościgów); wszystkie 5 zawiera Troll; pole krok_s 0.66–0.94, v 14–20; stany WALKA (4) i WPADNIECIE (1).
  skutek: Pościg wydłuża się w czasie w sytuacjach walki. Liczba zdarzeń jest mała, więc koszt szacunkowo niewielki.
  propozycja: Zbadać, czy funkcja wykrywania utknięcia nie myli stanu walki z brakiem postępu; rozważyć wyłączenie licznika utknięć w stanie WALKA/WPADNIECIE jako osobnej kategorii w logach.
- Liczniki zgubień są niespójne między poziomem pościgu a epizodami celu. (pewność 0.7)
  dowód: epizody_celu: zgubione 3 (wskaźnik 92, powod_top 'zniknął z widoku żywy'); koniec pościgów: zgubienie 0 (0%), przerwane_inne 2, bez_dojscia 1. Pole niespojnosci jest puste, mimo rozbieżności.
  skutek: Nie da się jednoznacznie ocenić, ile dobić faktycznie przepadło. Realna utrata może być zaniżona (3 epizody) lub zawyżona/źle sklasyfikowana.
  propozycja: Ujednolicić definicję 'zgubienia' między funkcją kończącą pościg a funkcją liczącą epizody celu, tak aby każdy epizod 'zniknął z widoku' miał jednoznaczne mapowanie na powód wyjścia z pościgu.
- do zmierzenia: Latencja i liczba potworów w zasięgu na każdym kroku pościgu: czy wysokie lat_med występuje tylko przy >=2 potworach obok celu (dotyczy wniosku 1).
- do zmierzenia: Porównanie trzymaj vs stuk w tym samym środowisku (Trolle, ta sama pora), bo w danych brak jakichkolwiek pościgów w trybie stuk i nie da się ocenić wyboru trybu.
- do zmierzenia: Dla każdego epizodu 'zniknął z widoku żywy' zapis ostatniej pozycji celu, odległości i tego, czy w tym czasie wystąpiły naciski z postoju.
- do zmierzenia: Czy pole 'v' jest prędkością postaci, a 'krok_s' zmierzoną częstotliwością kroków; czy niskie wartości pokrywają się z utknięciami (dotyczy wniosku 2).
- do zmierzenia: Czy naciski z postoju są retransmisjami przy opóźnieniu wejścia, czy świadomymi ponownymi wysłaniami: zmierzyć odstęp między nimi a odpowiedzią serwera.

## 2026-10-15 19:45 | uwaga | pościgów 5 min: 10, 30 min: 139
- Utknięcia pościgu koncentrują się przy Trollach w stanach WALKA/WPADNIECIE na polu o niskiej prędkości (v14, krok 0.66 s). (pewność 0.5)
  dowód: okno_dlugie.utkniecia: 5 z 139 pościgów (3,6%); 4 z 5 na polu v14/krok 0.66, 1 na v20/krok 0.94; Troll obecny w 4 z 5; stany WALKA x4, WPADNIECIE x1. Tempo kroków p10 1.04 vs med 1.6 w oknie długim.
  skutek: Pościg stoi w miejscu przy otoczeniu innych potworów, a ogon tempa kroków spada; w skrajnych przypadkach kończy się brakiem ruchu (1 pościg) lub gryzieniem.
  propozycja: Funkcja wykrywania utknięcia (próg czasu bez zmiany pozycji) — sprawdzić, czy w stanie WALKA przerywa lub nie przelicza trasy przy zajętych polach; rozważyć uwzględnienie pozycji innych potworów w wyborze kroku. Kierunek do decyzji człowieka.
- Najgorsze pościgi występują przy wysokiej latencji, około 2-3 razy powyżej mediany. (pewność 0.3)
  dowód: lat_med: 0.2 s (okno długie), 0.3 s (krótkie); najgorsze pościgi: Troll brak_ruchu lat_med 0.574 s (n=1, kroki 2), gryzacy lat_med 0.664 s (n=1, kroki 4); dec_med 0.0 s. Próba n=2.
  skutek: Możliwe, że opóźnione decyzje powodują brak ruchu lub gryzienie, ale to na razie tylko zbieżność w 2 przypadkach.
  propozycja: Stała/funkcja obliczania latencji używanej w decyzji o kroku — sprawdzić, czy wartość lat jest uwzględniana w przewidywaniu pozycji celu; kierunek do rozważenia po większej próbie.
- do zmierzenia: Jaki odsetek wszystkich pościgów odbywa się na polu v14 i w obecności Trolla; czy wskaźnik utknięć rośnie w tym podzbiorze względem reszty.
- do zmierzenia: Czy kroki_na_s poniżej p10 (~1.04) korelują z naciskami z postoju w tym samym pościgu.
- do zmierzenia: Czy latencja powyżej ~0.5 s występuje częściej w pościgach zakończonych brak_ruchu lub gryzacy (potrzebna większa próba, n>=5).
- do zmierzenia: Co oznacza Jointoramix w stwory z odległością 0 (ten sam kafel, cel, czy inny stwór) — i czy zawsze jest w zestawie przy utknięciach.
- do zmierzenia: Które epizody z zgubione=3 zostały zapisane jako pościg zakończony innym powodem (np. odl<=1 po ponownym namierzeniu).

## 2026-10-15 19:47 | uwaga | pościgów 5 min: 9, 30 min: 137
- Liczniki zgubień są sprzeczne: na poziomie pościgów zgubienie=0, a na poziomie epizodów celu zgubione=3, a detektor niespójności nie zgłosił tego (niespojnosci=[]). (pewność 0.8)
  dowód: okno_dlugie.koniec.zgubienie=0 (zgubienie_proc=0) vs okno_dlugie.epizody_celu.zgubione=3 (wskaznik 91, porzucone=2); powody_wyjsc nie zawierają 'zgubienie'; niespojnosci=[].
  skutek: Nie wiadomo, czy 3 z 55 epizodów (5,5%) to realne straty dobicia, czy błąd liczenia. Metryka skuteczności pościgu jest niewiarygodna, dopóki nie zostanie ujednolicona.
  propozycja: Ujednolicić warunek 'cel_znikl' między funkcją zapisu wyniku pościgu a funkcją zliczania epizodów celu (jedna wspólna definicja zgubienia); dodać do detektora niespójności regułę 'zgubione_epizodow > 0 przy zgubienie_pościgów = 0' jako błąd.
- Pościg czasem przestaje się posuwać podczas walki z innymi potworami (Troll, Jointoramix), bo ruch nie jest priorytetem przy stanie WALKA/WPADNIECIE. (pewność 0.5)
  dowód: utkniecia.liczba=4 z 137 pościgów (2,9%); wszystkie przy pole v=14, krok_s=0.66; stwory zawsze zawierają Troll lub Jointoramix; stany WALKA (3) i WPADNIECIE (1); czas utknięcia 16-20 s.
  skutek: Około 3% pościgów traci 16-20 s, co wydłuża czas dobicia i zwiększa ryzyko zgubienia celu przez innych graczy lub potwory.
  propozycja: Funkcja decyzji ruchu w pętli pościgu: w stanie WALKA sprawdzić, czy wybór ataku na inny cel nie blokuje kroku w kierunku celu; rozważyć zmianę kolejności priorytetów (ruch do celu przed atakiem na stwory poboczne).
- Najgorszy pościg zakończył się etykietą brak_ruchu mimo że dystans spadł z 5 do 2, a stan gracza to UH; prawdopodobnie użycie leczenia wstrzymuje ruch. (pewność 0.3)
  dowód: najgorsze_poscigi[0]: powod=brak_ruchu, kroki=2, czas=2.63 s, odl [5,2], zmiany_kier=5 przy 2 krokach, stan=UH, hp_gracza=100, lat_med=0.574, osiagalny=true.
  skutek: Pojedynczy przypadek (n=1) ale pokazuje, że etykieta powodu może być błędna i że leczenie może przerywać ruch.
  propozycja: Sprawdzić funkcję obsługi leczenia (stan UH) w pętli pościgu: czy wykonanie akcji leczenia czeka na zakończenie lub resetuje sekwencję kroków; ponadto poprawić funkcję wyznaczania powodu 'brak_ruchu', żeby nie liczyła postępu o ujemnym odległościowo wyniku.
- Przy wyższej latencji tempo kroków spada i ma długi ogon w dół; najgorsze pościgi występują przy latencji ok. 2-3 razy wyższej od mediany. (pewność 0.4)
  dowód: trzymaj krótkie okno: lat_med=0.554 s vs długie 0.2 s (2,8x); kroki_na_s med 1.5, p10 0.79; długie okno: kroki_na_s med 1.56, p10 0.9, ogółem 2.03 (średnia powyżej mediany = skośność); najgorszy pościg lat_med=0.574 (2,9x długiego okna).
  skutek: Przy opóźnieniu kroki są wolniejsze, cel ucieka i pościg się wydłuża. Dane są oparte na jednym najgorszym przypadku i krótkim oknie (n=9), więc pewność jest umiarkowana.
  propozycja: Stała odstępu między kolejnymi wysłaniami kroku a odczytem pozycji (opóźnienie pętli): rozważyć dostosowanie tej stałej do bieżącej mediany latencji zamiast wartości stałej.
- Klawisz trzymany jest wciśnięty 97% czasu pościgu, ale jest często ponownie wysyłany z postoju, co może oznaczać przerwy w ciągłości ruchu. (pewność 0.4)
  dowód: okno_dlugie.trzymaj: trzymane_proc_czasu=97, naciski_z_postoju=108 (0,79 na pościg); okno_krotkie: naciski_z_postoju=11 (1,22 na pościg), trzymane_proc=82; zmiany_kierunku_na_krok=0,27 (długie), 0,39 (krótkie).
  skutek: Ponowne wysyłanie klawisza z postoju może dodawać opóźnienie przy zmianie kierunku. Efekt jest mały (kilka naciśnięć na pościg), ale stały.
  propozycja: Funkcja wysyłania klawisza trzymanego: wysyłać ponownie tylko po potwierdzeniu postoju, nie po każdym odczycie pozycji; sprawdzić, czy ponowne wciśnięcie nie resetuje czasu trzymania.
- do zmierzenia: Czy zgubione epizody (3) mają odpowiadający pościg z powodem cel_znikl, a jeśli nie, kiedy licznik epizodów przyjmuje zgubienie.
- do zmierzenia: Czy 'zmiany_kierunku' (5) przy 2 krokach liczy wciśnięcia klawiszy, a nie zmiany kroku; porównać z pełnym logiem wciśnięć dla tego pościgu.
- do zmierzenia: Stan UH przed i po etykiecie brak_ruchu: logować czas wykonania akcji leczenia względem ostatniego kroku.
- do zmierzenia: Dane z trybu 'stuk' (w tym oknie brak): porównać kroki_na_s, naciski_z_postoju i lat_med trzymaj vs stuk przy tej samej latencji.
- do zmierzenia: Rozkład latencji per pościg (nie tylko mediana) dla pościgów z utknięciem vs bez, przy tym samym polu v=14.

## 2026-10-15 19:49 | uwaga | pościgów 5 min: 27, 30 min: 144
- W ostatnich 5 minutach latencja wzrosła ok. 2,9x względem 30-minutowego okna, a skuteczność dobić spadła z 98% do 93%. (pewność 0.35)
  dowód: lat_med_s: 0.577 (krótkie) vs 0.2 (długie); kroki_na_s med 1.3 vs 1.5, p10 0.79 vs 0.9; dobicie_proc 93 vs 98; przerwane_inne 2 w krótkim oknie (27 pościgów), 2 w długim (144).
  skutek: Wolniejsze zbliżanie się do celu i większa szansa, że cel ucieknie przed dobiciem. Różnica dotyczy 27 pościgów, więc może być szumem.
  propozycja: Funkcja ponawiania wysyłania kroku: sprawdzić, czy czas oczekiwania przed ponowieniem to stała niezależna od mierzonej latencji. Kierunek: powiązać ten czas z lat_med zamiast stałej.
- Epizody celu zapisują zgubienia, których nie ma wśród zakończeń pościgów. (pewność 0.6)
  dowód: epizody_celu.zgubione = 5 (długie) i 2 (krótkie), powod_top 'zniknął z widoku żywy'; jednocześnie koniec.zgubienie = 0 w obu oknach, a powody_wyjsc nie mają 'cel_znikl'.
  skutek: Wskaźnik skuteczności pościgu (zgubienie_proc = 0) może być zaniżony. Dobicie 98% może więc nie opisywać prawdziwej utraty celów.
  propozycja: Funkcja klasyfikacji zakończenia pościgu: sprawdzić, jak zgubiony epizod mapuje się na zakończenie pościgu (np. czy trafia do przerwane_inne albo brak_ruchu). Kierunek: jeden spójny słownik powodów dla epizodu i pościgu.
- Utknięcia pojawiają się tylko w walce z Trollami w bliskim dystansie, w jednym obszarze planszy. (pewność 0.25)
  dowód: utkniecia.liczba = 3 w 1800 s (na 144 pościgi), wszystkie stan WALKA, pozycje ok. (33086-33087, 31744-31770), dystans do trolli 1-3, pole krok_s 0.66; w wpisie Jointoramix ma odległość 0, co wymaga sprawdzenia.
  skutek: Krótkie przestoje w walce z kilkoma potworami naraz. Przy 3 zdarzeniach skala kosztu jest mała.
  propozycja: Funkcja wyboru kroku/ścieżki: sprawdzić, czy pola zajęte przez inne potwory są uwzględniane. Kierunek: traktować zajęte pola jako przeszkody przy wyborze kroku.
- Najgorszy pościg (brak_ruchu) miał stan UH przy pełnym HP gracza, więc wcześniejsza hipoteza o leczeniu nie jest tu potwierdzona. (pewność 0.2)
  dowód: najgorsze_poscigi[0]: Troll, hp_celu 100, powod brak_ruchu, kroki 2, czas 2.63 s, odl 5→2, stan UH, hp_gracza 100, lat_med 0.574.
  skutek: Jeden przypadek na 144 pościgi; koszt mały, ale stan UH może blokować ruch.
  propozycja: Funkcja przejścia stanów (UH): sprawdzić, co ustawia stan UH i czy w tym czasie wstrzymywany jest ruch. Kierunek: ruch nie powinien być blokowany, gdy HP gracza jest pełne.
- Klawisz trzymany bywa ponownie wysyłany z postoju, a liczba kroków różni się od liczby wysłanych ruchów. (pewność 0.3)
  dowód: naciski_z_postoju = 107 (0.74 na pościg), zmiany_kierunku_na_krok = 0.3 (długie), 0.49 (krótkie); kroki 188 vs wyslane 163; ponow_brak 9.
  skutek: Możliwe krótkie przerwy w ciągłości ruchu. Przy tempie 1,5 kroku/s i dobiciu 98% koszt wydaje się niewielki.
  propozycja: Funkcja wysyłania klawisza trzymanego: sprawdzić warunek ponownego wysłania z postoju i to, czy kroki bez wysłania są liczone. Kierunek: ograniczyć ponowne wysyłanie do realnego zatrzymania postaci.
- do zmierzenia: Dla każdego z 5 zgubionych epizodów: czy odpowiadający im pościg kończy się przerwane_inne, brak_ruchu czy innym powodem, i jaki był jego czas.
- do zmierzenia: Histogram latencji w 1-sekundowych kubełkach obok zdarzeń brak_ruchu, aby sprawdzić, czy przestoje występują tylko powyżej określonego progu latencji.
- do zmierzenia: Czas spędzony w stanie UH na pościg i to, czy w tym czasie wysyłane są ruchy.
- do zmierzenia: Dla utknięć: zapis zajętych pól w promieniu 3 i kolejności kroków trolli, aby sprawdzić blokowanie ścieżki.
- do zmierzenia: Różnica kroki (188) vs wyslane (163): czy brakujące 25 kroków to ruchy bez wysłania klawisza, czy błąd liczenia pozycji.

## 2026-10-15 19:51 | uwaga | pościgów 5 min: 30, 30 min: 145
- Utknięcia pojawiają się niemal wyłącznie w walce, w jednym obszarze planszy, przy Trollach obok Jointoramixa. (pewność 0.5)
  dowód: okno_dlugie.utkniecia: 4 z 4 w stanie WALKA; 3 z 4 zawierają Trolle w 'stwory'; pozycje x 33086-33092, y 31744-31770; okno_krotkie: 1 utknięcie w tym samym obszarze; 4 utknięcia na 145 pościgów (2,8%)
  skutek: Pościgi w tym obszarze stoją w miejscu (długie okno: 1 brak_ruchu). Dobicie nadal 98%, więc koszt jest niewielki, ale to skupisko powtarza się w obu oknach.
  propozycja: Funkcja wykonująca krok pościgu w stanie WALKA: rozważyć uwzględnienie zajętości sąsiednich pól przez inne stwory przed wysłaniem kroku (opis warunku, bez zmiany stałych bez pomiaru).
- Liczba zgubionych epizodów celu nie zgadza się z liczbą zgubień liczonych na poziomie pościgów. (pewność 0.6)
  dowód: okno_dlugie: epizody_celu.zgubione 5 (powod_top 'zniknął z widoku żywy'), a koniec.zgubienie 0 (zgubienie_proc 0); okno_krotkie: epizody zgubione 2 przy koniec.zgubienie 0
  skutek: Strata dobić może być niedoszacowana albo źle sklasyfikowana (zgubienie zapisane jako inny powód), więc skuteczność 98% może być zawyżona.
  propozycja: Funkcja klasyfikacji zakończenia pościgu i zamykania epizodu: sprawdzić, jaki warunek (cel_znikl vs przerwane_inne) jest przypisywany przy zniknięciu celu z widoku.
- Krótkie okno ma niższą skuteczność i wolniejsze tempo niż długie, ale to mała próba. (pewność 0.3)
  dowód: krótkie (n=30): dobicie_proc 93, kroki_na_s p10 0,79 (długie: 1,11), med 1,3 (długie: 1,56), zmiany_kierunku_na_krok 0,44 (długie: 0,29)
  skutek: Możliwe, że część wolniejszych pościgów wynika z walki; przy n=30 różnica może być szumem.
  propozycja: Brak zmiany w kodzie; powtórzyć pomiar na większej próbie i rozbić wyniki według obecności Trolli.
- Opóźnienie wysyłania było w krótkim oknie wyraźnie wyższe niż w długim; może to wpływać na wolniejsze pościgi. (pewność 0.3)
  dowód: lat_med_s: 0,559 (krótkie) vs 0,2 (długie); dec_med_s 0,001 vs 0,0
  skutek: Wyższe opóźnienie reakcji na ruch celu może zwiększać liczbę zmian kierunku i wolniejsze dojście; wpływ nie jest potwierdzony.
  propozycja: Brak zmiany w kodzie; zmierzyć lat_med w czasie, żeby sprawdzić, czy wzrost pokrywa się z obciążeniem systemu.
- do zmierzenia: Czy utknięcia w walce mają związek z liczbą stworów w sąsiedztwie postaci w chwili utknięcia (porównać stwory w promieniu 1-2 przy utknięciu vs bez utknięcia).
- do zmierzenia: Brak danych dla trybu stuk w tych oknach, więc nie da się ocenić, który tryb (trzymaj vs stuk) jest skuteczniejszy; zebrać pościgi w trybie stuk.
- do zmierzenia: Czy zgubione epizody to pościgi, w których cel zniknął bez zapisu zgubienia; zapisywać powód zakończenia w jednym miejscu, żeby uzgodnić oba liczniki.
- do zmierzenia: Czy zmiany kierunku w krótkim oknie (0,44 na krok) wynikają z walki z Trollami; rozbić zmiany kierunku według obecności Trolli.
- do zmierzenia: Czy wysokie lat_med (0,56 s) w krótkim oknie pokrywa się z obciążeniem systemu w tym czasie.

## 2026-10-15 19:53 | uwaga | pościgów 5 min: 18, 30 min: 142
- Liczniki zgubień nie zgadzają się: pościgi raportują 0 zgubień w obu oknach, a epizody celu raportują zgubione 2 (krótkie okno) i 4 (długie okno), oba z powodem 'zniknął z widoku żywy'. (pewność 0.6)
  dowód: koniec.zgubienie=0 i zgubienie_proc=0 w obu oknach; epizody_celu.zgubione=2 (krótkie, 2/12) i 4 (długie, 4/59); wskaznik zabite 83% i 92%.
  skutek: Nie da się ustalić, czy realna utrata dobić wynosi 0%, czy około 7% epizodów (4/59). Wskaźnik dobić 98% może być zawyżony.
  propozycja: Ujednolicić definicję 'zgubienia' w funkcji klasyfikującej powód wyjścia z pościgu tak, by zniknięcie żywego celu z widoku liczyło się jako zgubienie w obu licznikach.
- Ponad połowa wysłanych kroków przypada na naciski z postoju, choć klawisz 'trzymaj' jest wciśnięty przez 97–100% czasu pościgu. (pewność 0.4)
  dowód: Krótkie okno: naciski_z_postoju=20 przy kroki=35 (57%), 1.11 na pościg; długie okno: 106 przy kroki=191 (55%), 0.75 na pościg; kroki_na_s med 1.6 (długie) vs ogólem 1.92, p10 1.11.
  skutek: Część czasu pościgu przechodzi bez ruchu, co obniża tempo mediany i wydłuża najwolniejsze pościgi. Nie wiadomo, czy te naciski są zbędne, czy postać stoi za blokadą.
  propozycja: Funkcja obsługi trzymania klawisza w pętli pościgu: dodać warunek wykrywający brak zmiany pozycji i sprawdzać go przed ponownym wysłaniem klawisza. Do rozważenia przez człowieka, bez zmiany długości pościgu.
- Utknięcia w stanie WALKA pojawiają się przy polu o niższej prędkości, przy celach Troll i Jointoramix. (pewność 0.35)
  dowód: Długie okno: 3 utknięcia (stan WALKA, pole v 14–16, krok_s 0.66–0.75), stwory: Jointoramix+2×Troll, Jointoramix; krótkie okno: 1 utknięcie z tym samym profilem.
  skutek: Małe: 3 z 142 pościgów (2%) z długimi czasami (16–20 s). Przy większej liczbie prób może to być stały koszt walki na tym polu.
  propozycja: Funkcja decydująca, czy pościg wstrzymuje ruch przy aktywnej walce ze strony pola (stan WALKA): sprawdzić, czy wstrzymanie zachodzi wtedy, gdy potwory blokują drogę.
- Najgorszy pościg (Troll, HP gracza 100) przerwany jako brak_ruchu w stanie UH, przy opóźnieniu ponad trzykrotnie wyższym od mediany. (pewność 0.3)
  dowód: Najgorsze_poscigi[0]: stan UH, hp_gracza 100, powod brak_ruchu, kroki=2, czas 2.63 s, lat_med 0.574 (mediana okna 0.19), odl 5→2.
  skutek: Jeden przypadek: możliwe, że akcja leczenia (UH) zablokowała krok pościgu i ten pościg został zakończony zbyt wcześnie.
  propozycja: Funkcja kolejkowania akcji w pętli: sprawdzić, czy wysłanie leczenia wstrzymuje wysyłanie kroków pościgu; ewentualnie ustalić priorytet kroku przed leczeniem, gdy HP gracza jest pełne.
- Krótkie okno wygląda gorzej (89% dobić, 2 przerwane, czas pościgu ~1.05 s vs ~0.70 s), ale opóźnienie wysyłania nie jest wyższe, więc wcześniejszy wniosek o opóźnieniu nie znajduje potwierdzenia w danych. (pewność 0.3)
  dowód: lat_med 0.193 s (krótkie) vs 0.188 s (długie); dec_med 0.001 s w obu; czas_s/n: 18.9/18 ≈ 1.05 s vs 99.6/142 ≈ 0.70 s; n=18.
  skutek: Różnicę w tempie łatwo wyjaśnić małą próbą i kilkoma wolnymi pościgami; nie ma dowodu, że problem dotyczy opóźnienia.
  propozycja: Brak zmiany kodu na podstawie tego okna; najpierw zebrać więcej pościgów w krótkim oknie.

## 2026-10-15 19:55 | uwaga | pościgów 5 min: 20, 30 min: 146
- Pościg skutecznie dobija cele; przerwania są rzadkie i w trzech najgorszych przypadkach towarzyszy im wysokie opóźnienie. (pewność 0.35)
  dowód: okno_dlugie: 143 dobicia z 146 pościgów (98%), zgubienie 0. Trzy najgorsze pościgi mają lat_med 0.574, 0.587 i 0.583 s, przy medianie w oknach 0.186–0.2 s (ok. 3x). Wszystkie trzy zakończyły się przed dobiciem (brak_ruchu, gryzacy x2).
  skutek: Około 2% pościgów kończy się bez dobicia. W obserwowanej próbce wszystkie trzy najgorsze przypadki mają podwyższone opóźnienie, ale n=3 i brak grupy kontrolnej.
  propozycja: Funkcja mierzenia opóźnienia (lat_med) i jej użycie przy decyzji o wysłaniu kroku: sprawdzić, czy próg ponawiania lub odrzucania kroków przy wysokim lat_med wpływa na przerwania. Do rozważenia przez człowieka.
- Liczniki zgubień w epizodach celu nie zgadzają się z licznikami zakończeń pościgów, a dane deklarują brak niespójności. (pewność 0.7)
  dowód: epizody_celu (okno_dlugie): zgubione 4, wskaznik 91, powod_top 'zniknął z widoku żywy'. koniec.zgubienie: 0, powody_wyjsc bez cel_znikl. niespojnosci: []. Dodatkowo ostatnie_wnioski podają 89% dobić w oknie krótkim, a koniec.dobicie_proc wynosi 100.
  skutek: Nie wiadomo, czy 4 zgubienia w epizodach to pościgi, które w statystykach są liczone jako inne zakończenia. Ocena skuteczności może być zawyżona lub zaniżona.
  propozycja: Ujednolicić definicję 'epizodu celu' i 'pościgu' w funkcji raportującej statystyki, tak aby każde zgubienie było liczone raz i w jednym miejscu.
- Dane nie zawierają trybu 'stuk', więc nie da się ocenić, który tryb jest lepszy; w trybie trzymaj pojawiają się liczne naciśnięcia z postoju. (pewność 0.4)
  dowód: Tryb trzymaj: 146 pościgów, trzymane_proc_czasu 97%. Tryb stuk nie występuje w żadnym oknie. naciski_z_postoju: 113 w oknie długim (0.77 na pościg) i 24 w krótkim (1.2 na pościg). zmiany_kierunku_na_krok 0.34 (długie) i 0.48 (krótkie).
  skutek: Nie wiadomo, czy naciski z postoju są potrzebne do korekty kierunku, czy marnują czas. Porównanie trzymaj vs stuk pozostaje niemożliwe.
  propozycja: Funkcja wyboru trybu ruchu (trzymaj/stuk) w pościgu, z przełączeniem na stuk w określonych warunkach, do przetestowania na osobnej próbce. Do rozważenia przez człowieka.
- do zmierzenia: Czy lat_med powyżej ok. 0.4 s częściej prowadzi do przerwania pościgu (brak_ruchu, gryzacy)? Zmierzyć odsetek przerwań w kubełkach lat_med dla co najmniej 30 pościgów.
- do zmierzenia: Czy przerwania 'gryzacy' z kroki=1 wynikają z tego, że cel atakuje w trakcie pościgu? Zmierzyć, ile z takich pościgów kończy się dobiciem przy kontynuacji (bez skracania).
- do zmierzenia: Czy utknięcia w WALKA zależą od pola (pole.v, krok_s) czy od celu? Zebrać utknięcia na polach z różną prędkością i porównać z pościgami bez utknięć na tych samych polach.
- do zmierzenia: Czy naciski z postoju poprawiają zbieżność (zmniejszają odległość) czy tylko zwiększają liczbę kroków? Zmierzyć delta odległości po naciśnięciu z postoju i porównać z trybem stuk, gdy będzie użyty.
- do zmierzenia: Jak definiowany jest 'epizod celu' w kodzie i skąd biorą się 4 zgubienia w epizodach przy zerze w zakończeniach pościgów? Sprawdzić log zdarzeń cel_znikl przypisany do konkretnych pościgów.

## 2026-10-15 19:57 | uwaga | pościgów 5 min: 26, 30 min: 149
- Pościg skutecznie dobija cel; zgubienia w zakończeniach pościgów nie występują. (pewność 0.8)
  dowód: Okno krótkie: dobicie 26/26 (100%), zgubienie 0. Okno długie: dobicie 146/149 (98%), zgubienie 0, bez_dojscia 1, przerwane_inne 2. Odległość końcowa med 1 (start med 2).
  skutek: Brak istotnej utraty dobić w samych pościgach; ryzyko koncentruje się w pozostałych punktach (niespójność liczników, outliery opóźnienia).
  propozycja: Brak zmiany wymaganej przez te dane; zachować obecną logikę pościgu bez skracania.
- Liczniki epizodów celu nie zgadzają się z zakończeniami pościgów: epizody liczą 4 zgubienia, a pościgi 0. (pewność 0.6)
  dowód: okno_dlugie.epizody_celu: epizody 54, zabite 49, porzucone 1, zgubione 4, wskaznik 91%, powod_top 'zniknął z widoku żywy'. Równocześnie koniec.zgubienie = 0 przy 149 pościgach. Pole niespojnosci jest puste, mimo tej rozbieżności.
  skutek: Nie da się jednoznacznie ustalić, czy zgubienia są nieodnotowane w pościgu, czy epizody liczą zniknięcia spoza pętli pościgu. Zawyża to lub zaniża ocenę skuteczności o kilka punktów procentowych.
  propozycja: Sprawdzić, która funkcja ustawia powód 'cel_znikl' i czy zniknięcie celu przed startem pościgu (lub poza nim) jest wliczane do epizodów celu. Ujednolicić definicję jednostki (pościg vs epizod).
- Najgorsze pościgi (Troll) mają wyraźnie wyższe opóźnienie odpowiedzi niż typowe pościgi i kończą się w 1–2 krokach. (pewność 0.3)
  dowód: najgorsze_poscigi: lat_med 0.574, 0.587, 0.583 s przy medianie globalnej 0.19 s (okno długie). Powody: brak_ruchu (2 kroki), gryzacy (1 krok) x2. Wszystkie w stanie UH lub WALKA, hp_celu 100 lub 16.
  skutek: Krótkie, nieudane pościgi przy wysokim opóźnieniu; przy n=3 to sygnał wstępny, nie wniosek.
  propozycja: Rozważyć, czy stała limitu opóźnienia odświeżania pozycji celu (używana przed decyzją o ruchu) nie jest zbyt niska względem lat_med ~0.58 s dla celów typu Troll; kierunek: zwiększyć tolerancję opóźnienia lub dodać ją zależną od typu celu.
- W trybie trzymaj pojawia się wiele naciśnięć z postoju, co może generować zbędne sygnały podczas dochodzenia do celu. (pewność 0.4)
  dowód: okno_dlugie: naciski_z_postoju 112 na 149 pościgów (0.75 na pościg), zmiany_kierunku_na_krok 0.35, trzymane_proc_czasu 97%. Okno krótkie: naciski_z_postoju 26 na 26 pościgów (1.0 na pościg).
  skutek: Możliwe marnowanie kroków przy stojącej postaci, choć tempo kroków (med 1.5/s) nie spada; wpływ na dobicie nie jest zmierzony.
  propozycja: Opisać funkcję wysyłania klawisza w trybie trzymaj i sprawdzić warunek ponownego naciśnięcia, gdy postać stoi; kierunek: nie naciskać ponownie, dopóki pozycja się nie zmieni lub nie minie próg czasu.
- Jedno utknięcie w stanie WALKA przy polu o niskiej prędkości; zależność od prędkości pola nie jest potwierdzona. (pewność 0.2)
  dowód: utkniecia.liczba 1 przy 149 pościgach: Jointoramix, WALKA, 16 s, pole v=16, krok_s 0.75. Ostatni wniosek w danych o związku z prędkością pola opiera się na tym jednym przypadku.
  skutek: Pojedynczy przypadek kosztował 16 s; brak podstaw do uogólnienia.
  propozycja: Brak zmiany; obserwować kolejne utknięcia w polach o niskiej prędkości.
- do zmierzenia: Które zdarzenie ustawia powód 'cel_znikl' i czy zniknięcia poza pętlą pościgu trafiają do epizodów celu (rozstrzygnie rozbieżność 4 zgubień vs 0).
- do zmierzenia: Co oznacza powód 'gryzacy' i czy pościg kończony nim traci dobicie, czy tylko zmienia walkę.
- do zmierzenia: Rozkład lat_med per typ celu i stan (UH/WALKA), żeby sprawdzić, czy opóźnienia >0.5 s są specyficzne dla Trolla, a nie przypadkowe.
- do zmierzenia: Zmierzyć naciski_z_postoju tylko w ramkach, gdy odległość >1, żeby odróżnić zbędne naciski od konieczności dochodzenia.
- do zmierzenia: Dane z trybem 'stuk' (obecnie brak): porównanie kroki_na_s i naciski_z_postoju trzymaj vs stuk, zanim cokolwiek zmieni się w obsłudze klawisza.

## 2026-10-15 19:59 | uwaga | pościgów 5 min: 23, 30 min: 149
- Dane pościgów są wewnętrznie niespójne w liczbie zgubień: koniec.zgubienie wynosi 0, a epizody_celu.zgubione wynosi 3 (powód_top: 'zniknął z widoku żywy'). (pewność 0.6)
  dowód: okno_dlugie: koniec.zgubienie=0, zgubienie_proc=0; epizody_celu: epizody=53, zabite=49, porzucone=1, zgubione=3, wskaznik=92. Pozostałe sumy się zgadzają (dobicie 145 = odl<=1 128 + cel_martwy 17). Lista niespojnosci jest pusta, więc rozbieżności nie wykryto a
  skutek: Nie wiadomo, czy realna utrata celu wynosi 0% (koniec) czy ok. 2% (epizody). Ocena skuteczności zależy od tego, która definicja jest poprawna.
  propozycja: Sprawdzić w kodzie, czy 'zgubienie' w podsumowaniu koniec i 'zgubione' w epizodach_celu liczą ten sam warunek (np. zniknięcie celu z widoku w trakcie pościgu vs. zniknięcie między pościgami). Ujednolicić jedną funkcję klasyfikacji powodu wyjścia.
- Najgorsze pościgi są skupione przestrzennie i mają ok. 3x wyższe opóźnienie odpowiedzi niż typowo. (pewność 0.35)
  dowód: 4 najgorsze pościgi (Troll) mają poz x 33079–33086, y 31766–31772, z=8; lat_med 0.574–0.587 s przy medianie 0.192 s (długie) i 0.255 s (krótkie). Trzy z czterech zakończyły się przed dobiciem (brak_ruchu, gryzacy, gryzacy).
  skutek: Pościgi w tym rejonie częściej kończą się bez dobicia. Przy n=4 nie da się oszacować, jak częste jest to zjawisko.
  propozycja: Sprawdzić w kodzie, czy czas odczytu/aktualizacji pozycji celu i decyzji (lat) zależy od lokalizacji lub od obciążenia w tym obszarze (np. funkcja odczytu pozycji celu, jej timeout lub częstotliwość odpytywania). Zweryfikować, czy inne pościgi w tym prostokącie też mają podwyższone lat.
- Przerwania przez 'gryzacy' zdarzają się, gdy cel jest jeszcze żywy i daleko, a pościg kończy się przejściem na walkę. (pewność 0.4)
  dowód: przerwane_inne: 3 w oknie długim i 1 w krótkim (2% pościgów). W najgorszych: 2 z 4 pościgów gryzacy przy hp_celu=100 (po 5 i 1 kroku) i 2 przy hp_celu=16 (po 1 kroku).
  skutek: Każde takie przerwanie to utracone dobicie celu. Koszt w danych jest mały (ok. 2%), ale przy hp_celu=100 cel nie był bliski śmierci.
  propozycja: Przejrzeć funkcję decyzji o przerwaniu pościgu przy powodzie 'gryzacy' i rozważyć, czy warunek nie powinien uwzględniać hp_celu i odległości celu (opis zmiany warunku, do oceny przez człowieka).
- do zmierzenia: Tryb stuk nie pojawił się w danych (wszystkie 149 i 23 pościgi to trzymaj), więc porównanie trzymaj vs stuk nie jest możliwe; zebrać dane z obu trybów w tym samym oknie.
- do zmierzenia: Naciski z postoju: 114 w oknie długim (0.77 na pościg), a 97% czasu klawisz jest trzymany. Zmierzyć, w jakiej sytuacji się pojawiają (np. ściana, inny gracz, lag) i czy wydłużają czas dojścia.
- do zmierzenia: Zmiany kierunku: 0.38 na krok (długie) i 0.49 (krótkie) przy zerowych oscylacjach A-B-A-B. Sprawdzić, czy to omijanie przeszkód na trasie (naturalne), czy szum kierunku; zmierzyć odsetek zmian, po któ
- do zmierzenia: Jedno utknięcie (WALKA, Jointoramix, pole v=16, krok 0.75 s) jest za małe, by wiązać je z prędkością pola. Zebrać więcej utknięć z polem v i oznaczeniem typu terenu.
- do zmierzenia: Rozstrzygnąć, co oznacza stan 'UH' w najgorszym pościgu (brak_ruchu, 2 kroki) i czy leczenie w trakcie pościgu blokuje ruch.

## 2026-10-15 20:01 | uwaga | pościgów 5 min: 48, 30 min: 164
- Pościgi prawie zawsze kończą się dobiciem; utrata dobić wynika głównie z przerwań 'gryzacy', gdy cel jest jeszcze żywy i stoi w odległości 4-6. (pewność 0.5)
  dowód: okno_krotkie: dobicie 47/48 (98%), gryzacy 1; okno_dlugie: dobicie 160/164 (98%), gryzacy 3, przerwane_inne 3; najgorsze pościgi: gryzacy przy hp_celu 16 i odl [4,6] oraz [5,2] (stan WALKA/IDZ)
  skutek: Około 2% pościgów kończy się bez dobicia, a cel (żywy) zostaje w pobliżu, więc trzeba go gonić od nowa.
  propozycja: Funkcja warunku wyjścia z pościgu (powód 'gryzacy'): rozważyć sprawdzanie tego wyjścia dopiero po zachowaniu progu odległości do celu (nazwa stałej progu, kierunek: wyżej) albo po wcześniejszym sprawdzeniu, czy cel jest żywy i w zasięgu.
- W trybie trzymaj ok. połowa wysłanych naciśnięć przypada na postój postaci, a zmiany kierunku są częste. (pewność 0.35)
  dowód: naciski_z_postoju: 29/53 (krótkie, 55%) i 115/205 (długie, 56%); zmiany_kierunku_na_krok 0.45 i 0.41; trzymane_proc_czasu 97-100%
  skutek: Nadmiarowe wejścia mogą obciążać pętlę i zwiększać liczbę zmian kierunku bez postępu; wpływ na skuteczność nie jest zmierzony, bo dobicie wynosi 98%.
  propozycja: Stała odstępu między ponownymi naciśnięciami klawisza w trybie trzymaj (np. interwał ponawiania ruchu): rozważyć zwiększenie lub warunek ponawiania tylko po potwierdzeniu braku ruchu (kierunek do oceny człowieka).
- Pojedyncze utknięcie i pojedynczy brak ruchu w stanie UH; zbyt mało zdarzeń, by wskazać przyczynę. (pewność 0.2)
  dowód: utkniecia: 1 (16 s, pole v16, krok_s 0.75, stan WALKA, cel Jointoramix); najgorszy pościg 19:32:19: brak_ruchu, 2 kroki, 2.63 s, stan UH, hp_gracza 100
  skutek: Pojedyncze straty czasu; brak dowodu na powtarzalny problem.
  propozycja: Funkcja wyboru stanu (priorytet UH nad pościgiem): tylko do obserwacji, bez zmiany w kodzie na podstawie tych danych.
- do zmierzenia: Czy 3 epizody 'zgubione' (epizody_celu) to te same 3 przypadki co 'przerwane_inne' w koniec? Logować powód zakończenia przy każdym epizodzie, żeby zobaczyć mapowanie.
- do zmierzenia: Czy przerwania 'gryzacy' zależą od liczby innych potworów w zasięgu 2 kroków? Logować liczbę celów przy każdym wyjściu.
- do zmierzenia: Czy opóźnienie 0.57-0.59 s jest specyficzne dla tego miejsca (hotspot) czy dla Trolli? Porównać lat na innych lokalizacjach i przy innych potworach.
- do zmierzenia: Czy naciśnięcia z postoju odpowiadają blokadom (ściana, inna postać) czy redundancji? Logować odpowiedź serwera na każdy krok z postoju.
- do zmierzenia: Czy zmiany kierunku wynikają z ruchu celu (zmiana cel_dxdy) czy z własnych korekt? Zapisać dx/dy celu obok każdej zmiany kierunku.

## 2026-10-15 20:03 | uwaga | pościgów 5 min: 48, 30 min: 163
- Pościgi kończą się dobiciem w zdecydowanej większości, ale najgorsze przypadki to pościgi na Trollach, gdzie opóźnienie odpowiedzi jest ok. 3x wyższe niż typowo. (pewność 0.4)
  dowód: Długie okno: dobicie 160/163 (98%), zgubienie 0, przerwane_inne 3. Krótkie okno: dobicie 48/48. Najgorsze pościgi: lat_med 0.587, 0.583 i 0.578 s przy lat_med ogólnym 0.188 s; wszystkie na celu Troll w obszarze poz ~[33079-33086, 31767-31772].
  skutek: Większość pościgów działa poprawnie. Opóźnienie w tej strefie może powodować spóźnione reakcje i przerwania, a w dłuższym oknie przekłada się to na ok. 2% nieudanych pościgów.
  propozycja: Sprawdzić, czy licznik opóźnienia (lat_med) w funkcji oceny pościgu nie miesza się z czasem reakcji na konkretne stwory; rozważyć dodanie lat_med do logu per strefa/cel, bez zmiany stałych czasowych pościgu.
- Pościgi na Trollach kończą się przez 'gryzacy' zanim dojdzie do dobicia, nawet gdy cel ma niskie HP. (pewność 0.35)
  dowód: powody_wyjsc.gryzacy = 3 w długim oknie (0 w krótkim). Wszystkie 3 to najgorsze pościgi: kroki 1, 1 i 5, hp_gracza 100, hp_celu 16, 16 i 100, cel_dxdy małe (-5,-4), (-5,1), (4,5).
  skutek: Pościg przerwany na starcie nie kończy się dobiciem; przy trzech zdarzeniach to ok. 2% wszystkich pościgów w długim oknie, ale nie da się tego jeszcze jednoznacznie przypisać do jednej przyczyny.
  propozycja: Przeanalizować stałą lub warunek, który wywołuje powód 'gryzacy' (próg odległości lub HP celu przy ataku gryzącego); rozważyć, czy pościg na cel z niskim HP powinien być kontynuowany mimo ataku innego stwora. Nie skracać pościgu.
- W trybie trzymaj postać często nie rusza się mimo wciśniętego klawisza, a wysyłane naciśnięcia z postoju stanowią dużą część wszystkich wysłanych. (pewność 0.5)
  dowód: Długie okno: naciski_z_postoju 115 z wyslane 196 (ok. 59%); naciski_z_postoju_na_poscig 0.71; trzymane_proc_czasu 97%; ponow_brak 12. Krótkie okno: 25 naciśnięć z postoju na 48 pościgów (0.52).
  skutek: Część naciśnięć nie daje ruchu, co zwiększa czas dojścia do celu i może pogłębiać opóźnienia; przy obecnym dobiciu 98% koszt jest niewielki, ale nie jest zerowy.
  propozycja: Zbadać funkcję wysyłania kroków i jej ponowienia (ponow_brak): czy wysyła nowe naciśnięcie przed potwierdzeniem zmiany pozycji; rozważyć mechanizm oczekiwania na potwierdzenie ruchu lub sprawdzanie blokady przez stwora/ścianę.
- Zgubienia celu zdarzają się rzadko, a jedyny zapisany powód to zniknięcie żywego celu z widoku. (pewność 0.3)
  dowód: Długie okno: epizody_celu.zgubione = 2 z 52 (wskaznik 94), powod_top 'zniknął z widoku żywy'; krótkie okno: 0 zgubień. Brak danych o odległości w chwili zgubienia.
  skutek: Około 1% pościgów kończy się bez dobicia, a utracony cel może wrócić w inne miejsce, co zwiększa czas pościgu.
  propozycja: Dodać zapis odległości, kierunku i ostatniej pozycji celu w chwili zgubienia, aby ustalić, czy to zasięg widzenia, czy nagłe odejście celu.
- Jedno utknięcie w stanie WALKA przy prędkości pola 0.75 kroku/s, bez wzorca powtarzalnego. (pewność 0.2)
  dowód: utkniecia.liczba = 1 (19:50:55, stan WALKA, s=16, pole v=16, krok_s 0.75); oscylacje = 0, bez_postepu = 0.
  skutek: Brak wyraźnego kosztu; pojedynczy przypadek nie pozwala wskazać przyczyny.
  propozycja: Brak zmiany w kodzie na podstawie tego zdarzenia; obserwować, czy utknięcia pojawią się częściej w strefie Trolli.
- do zmierzenia: Czy wysokie opóźnienie (lat_med ~0.58 s) dotyczy tylko strefy Trolli [33079-33086, 31767-31772], czy wszystkich pościgów w tym czasie? Zmierzyć lat_med osobno dla stref i dla innych celów.
- do zmierzenia: Czy 'gryzacy' przerywa pościgi, gdy cel ma HP <=16, a gracz ma 100 HP? Zebrać więcej przypadków 'gryzacy' (obecnie n=3).
- do zmierzenia: Czy naciśnięcia z postoju wynikają z opóźnienia odczytu pozycji, z blokady przez stwora/ścianę, czy z ponowień? Rozdzielić te trzy przyczyny w logu.
- do zmierzenia: Jaka jest odległość celu w chwili zgubienia (2 przypadki)? Czy cel znika z zasięgu widzenia, czy wychodzi poza strefę pościgu?
- do zmierzenia: Jak wypada tryb stuk względem trzymaj? Obecnie wszystkie pościgi są w trybie trzymaj, więc porównanie nie jest możliwe.

## 2026-10-15 20:05 | uwaga | pościgów 5 min: 27, 30 min: 150
- W trybie trzymaj klawisz jest trzymany przez prawie cały czas, a znaczna część wysłanych naciśnięć pada, gdy postać stoi. (pewność 0.6)
  dowód: okno_dlugie: trzymane_proc_czasu=97, naciski_z_postoju=109 z wyslane=191 (57%); okno_krotkie: naciski_z_postoju=15 na 27 pościgów (0.56 na pościg); ponow_brak=12
  skutek: Część wejść nie przynosi ruchu, ale dobicia nie spadają (98% w długim oknie, 100% w krótkim), więc koszt jest głównie czasowy i w logach.
  propozycja: Sprawdzić w kodzie funkcję wysyłania kroku w pętli pościgu (warunek ponowienia naciśnięcia przy trybie trzymaj): rozważyć, czy ponowne wysyłanie powinno czekać na potwierdzenie zmiany pozycji lub na czas większy niż lat_med (~0.19 s), zamiast wysyłać przy każdym cyklu.
- Liczniki zgubień w epizodach celu nie zgadzają się z podsumowaniem końca pościgu. (pewność 0.7)
  dowód: okno_dlugie: epizody_celu.zgubione=2 (wskaznik 96, powod_top 'zniknął z widoku żywy'), ale koniec.zgubienie=0 i zgubienie_proc=0; podobnie epizody=51 przy pościgach=150 (różne jednostki liczenia)
  skutek: Nie da się jednoznacznie ustalić, ile dobić faktycznie uciekło; możliwe zaniżenie lub zawyżenie utraty celów.
  propozycja: Ujednolicić definicję zgubienia w funkcji liczącej epizody z tą używaną w 'koniec' (ten sam warunek cel_znikl), a licznik epizodów powiązać z liczbą pościgów.

## 2026-10-15 20:07 | uwaga | pościgów 5 min: 16, 30 min: 148
- Liczenie zgubień jest niespójne: podsumowanie końca pościgu podaje zero zgubień, a liczniki epizodów celu podają dwa zgubienia z powodem 'zniknął z widoku żywy'. (pewność 0.7)
  dowód: okno_dlugie: koniec.zgubienie=0 i zgubienie_proc=0, ale epizody_celu.zgubione=2 (wskaźnik 96, powod_top 'zniknął z widoku żywy'); niespojnosci=[] mimo tej sprzeczności.
  skutek: Wskaźnik dobić 97% może być zawyżony, bo zgubienia nie trafiają do metryki końca; nie da się wiarygodnie ocenić, ile dobić przepada.
  propozycja: Ujednolicić klasyfikację końca pościgu w jednej funkcji zapisu, z której korzystają zarówno 'koniec', jak i 'epizody_celu', tak aby zgubienie 'zniknął z widoku' liczyło się w obu miejscach.
- Pościgi za trollami podczas walki mają wyraźnie wyższe opóźnienie reakcji niż typowe, a wyjścia z powodu 'gryzacy' zdarzają się głównie przy tym typie celu. (pewność 0.4)
  dowód: najgorsze_pościgi (4 próbki, n<5, niska pewność): lat_med 0.58–0.69 s, mediana długiego okna 0.19 s; powod 'gryzacy' w 4 z 4 najgorszych; stan WALKA/IDZ przy hp_gracza=100; w długim oknie powod 'gryzacy'=4 z 148.
  skutek: Opóźnienie ok. 3x względem mediany powoduje, że troll zdąża zaatakować i przerywa pościg; w danych to 4 utracone pościgi w długim oknie (3% prób).
  propozycja: Sprawdzić funkcję obsługi wyjścia 'gryzacy' i obsługę stanu WALKA w pętli pościgu: czy czas reakcji po wykryciu ataku celu nie jest liczony wspólnie z odświeżaniem pozycji (rozważyć osobną stałą opóźnienia dla celów z atakiem).
- Częste zmiany kierunku w trakcie pościgu nie prowadzą do oscylacji, ale są wyraźnie częstsze niż w krótkim oknie. (pewność 0.3)
  dowód: okno_dlugie: zmiany_kierunku=81 na 198 kroków (0.41/krok) przy oscylacje.liczba=0 i bez_postepu=0; okno_krotkie: 0.29/krok; kroki_na_s med 1.57 (p10 1.11).
  skutek: Brak dowodu straty dobić (97%), ale kroki z korektą kierunku mogą marnować ruch i wydłużać dojście do celu.
  propozycja: Zbadać funkcję wyznaczania kierunku w pętli pościgu (częstość przeliczania ścieżki); ewentualnie stała progu, po której zmiana kierunku jest ignorowana, jeśli cel jest w zasięgu 2.
- Klawisz jest trzymany przez niemal cały pościg, także gdy postać stoi, co może być źródłem powtórnych naciśnięć przy braku ruchu. (pewność 0.35)
  dowód: okno_dlugie: trzymane_proc_czasu=97, naciski_z_postoju=107 (0.72 na pościg), ponow_brak=12 na 188 wysłanych; okno_krotkie: naciski_z_postoju=11 na 16 pościgów.
  skutek: Naciski z postoju nie zmieniły wyniku (brak zgubień od braku ruchu), więc koszt jest prawdopodobnie niewielki, ale nie wiadomo, czy nie blokują kolejnych kroków.
  propozycja: Sprawdzić funkcję wysyłania klawisza w trybie trzymaj: warunek ponownego wysłania, gdy pozycja się nie zmienia (rozważyć stałą minimalnego czasu między ponowieniami).
- do zmierzenia: Ręcznie zweryfikować 2 epizody oznaczone jako 'zgubione' i sprawdzić, czy cel naprawdę zniknął, czy to błąd klasyfikacji końca pościgu.
- do zmierzenia: Zmierzyć, czy opóźnienie (lat_med) rośnie w chwili otrzymania ataku celu, osobno dla pościgów z powodem 'gryzacy' i bez niego, przy większej próbie trolli (n>=20).
- do zmierzenia: Zebrać dane w trybie stuk, aby porównać kroki_na_s i zgubienia z trybem trzymaj; obecnie w danych jest tylko trzymaj, więc porównanie jest niemożliwe.
- do zmierzenia: Zapisać przyczynę każdego ponow_brak (12 przypadków), aby sprawdzić, czy wiąże się z naciskami z postoju.
- do zmierzenia: Zmierzyć, czy zmiany kierunku przed dojściem do celu w zasięgu 2 wydłużają czas pościgu w porównaniu z pościgami bez zmian.

## 2026-10-15 20:09 | uwaga | pościgów 5 min: 19, 30 min: 148
- Najgorsze pościgi kończą się wyjściem 'gryzacy' po 1-5 krokach, gdy cel (Troll) ma pełne HP i stoi w stanie IDZ lub WALKA, więc pościg przerywa się zanim cel zostanie dogoniony. (pewność 0.5)
  dowód: okno_dlugie: powody_wyjsc gryzacy=4 z 148 (2,7%); najgorsze_poscigi: 3 z 4 to gryzacy, kroki 1-5, czas 1,01-4,07 s, hp_celu 100 w dwóch przypadkach, ocena_zlego 0,1-3,2; okno_krotkie: gryzacy=1 z 19
  skutek: Około 3% pościgów w długim oknie kończy się bez dobicia i bez zgubienia celu; dobicie spada do 97% zamiast ok. 100%.
  propozycja: Funkcja decydująca o wyjściu z pościgu po zdarzeniu 'gryzacy': rozważyć, by wyjście zależało od hp_celu i od odległości (np. ponowna próba dojścia, gdy cel ma pełne HP i jest w zasięgu 2-3), zamiast natychmiastowego zakończenia.
- W długim oknie część celów znika z widoku żywych, mimo że w samych pościgach nie zanotowano żadnego zgubienia; obie liczby nie zgadzają się ze sobą. (pewność 0.35)
  dowód: okno_dlugie.epizody_celu: zgubione=2 z 49 (wskaźnik 96%, powod_top 'zniknął z widoku żywy'); okno_dlugie.koniec: zgubienie=0, dobicie_proc=97; niespojnosci=[] (brak wpisu mimo rozbieżności)
  skutek: Około 4% epizodów celu kończy się zgubieniem; przy 2 przypadkach nie da się jednoznacznie ocenić, czy to stała, czy szum.
  propozycja: Funkcja wykrywania warunku cel_znikl: sprawdzić, czy zgubienie nie jest liczone na poziomie epizodu, a pościgu osobno; rozważyć dłuższe przeszukiwanie okolicy ostatniej znanej pozycji celu przed uznaniem go za zgubionego.
- Liczba zmian kierunku na krok wzrosła w długim oknie w porównaniu z krótkim, przy zerowej liczbie oscylacji A-B-A-B; postać nie zawraca, ale często przelicza kierunek. (pewność 0.4)
  dowód: zmiany_kierunku_na_krok: 0,28 (okno krótkie, 8 zmian w 29 krokach) vs 0,38 (okno długie, 79 zmian w 208 krokach); oscylacje.liczba=0 w obu oknach; kroki_na_s med 1,6 vs 1,57
  skutek: Część kroków idzie w niepotrzebnym kierunku, ale nie prowadzi do pętli i nie wydłuża pościgu w mierzalny sposób (koniec_med 1,0 w obu oknach).
  propozycja: Funkcja wyboru kierunku ruchu w pościgu: rozważyć rzadsze przeliczanie drogi (np. tylko gdy cel zmieni pozycję o więcej niż 1 pole), zamiast przy każdym kroku.
- Klawisz jest trzymany przez niemal cały pościg, także gdy postać stoi, co generuje około 0,8 naciśnięcia z postoju na pościg; w danych nie ma trybu 'stuk', więc nie da się porównać obu trybów. (pewność 0.3)
  dowód: okno_dlugie.puszczanie_klawisza: trzymane_proc_czasu=97, naciski_z_postoju=119, naciski_z_postoju_na_poscig=0,8; tryby zawierają tylko 'trzymaj' (n=148), brak wpisu 'stuk'; lat_med_s=0,2
  skutek: Część naciśnięć przypada na chwile bez ruchu postaci (zwykle po dojściu do odl<=1); koszt czasowy jest niewielki, bo dobicie nadal wynosi 97%.
  propozycja: Funkcja sterowania klawiszem w pościgu: rozważyć zwolnienie klawisza (lub przejście na tryb 'stuk') w momencie wejścia w warunek odl<=1, tak by naciśnięcia z postoju były mierzalne jako osobna metryka.
- do zmierzenia: Dla 4 wyjść 'przerwane_inne' w długim oknie zapisać przyczynę (np. timeout, błąd odczytu pozycji), żeby odróżnić je od 'gryzacy'.
- do zmierzenia: Dla 'gryzacy' zapisać hp_celu i odległość w chwili wyjścia dla wszystkich przypadków, nie tylko czterech najgorszych, by sprawdzić, czy przerwanie zależy od HP celu.
- do zmierzenia: Dla 2 zgubień w epizodach zapisać ostatnią znaną odległość i kierunek ucieczki celu, żeby ustalić, czy cel uciekł poza zasięg widzenia.
- do zmierzenia: Uruchomić sesję z trybem 'stuk' (dla porównania z 'trzymaj'), żeby zmierzyć wpływ na naciśnięcia z postoju i na kroki_na_s.
- do zmierzenia: Zmierzyć, czy naciśnięcia z postoju pojawiają się przed wykryciem odl<=1 (opóźnienie lat_med_s=0,2 s), czy po nim.

## 2026-10-15 20:11 | uwaga | pościgów 5 min: 41, 30 min: 169
- Liczba zgubień pościgów nie zgadza się z liczbą zgubionych epizodów celu: w obu oknach koniec.zgubienie=0, a w długim oknie epizody_celu.zgubione=2 z powodem 'zniknął z widoku żywy'. (pewność 0.7)
  dowód: okno_dlugie.koniec.zgubienie=0, zgubienie_proc=0; okno_dlugie.epizody_celu.zgubione=2, wskaznik=96, powod_top='zniknął z widoku żywy'; 2/51 epizodów.
  skutek: Wskaźnik skuteczności (98% dobić w pościgach) może nie obejmować części utraconych celów, więc skuteczność może być zawyżona.
  propozycja: Sprawdzić funkcję, która przypisuje powód zakończenia pościgu (mapowanie 'cel_znikl' na koniec pościgu) oraz to, czy liczniki epizodów i pościgów są liczone w tej samej jednostce.
- Wszystkie cztery pościgi zakończone powodem 'gryzacy' to najgorsze przypadki, a ich mediana latencji jest wyraźnie wyższa niż średnia; dwa dotyczyły trolla z pełnym HP. (pewność 0.45)
  dowód: okno_dlugie.powody_wyjsc.gryzacy=4 (= przerwane_inne=4); najgorsze_poscigi: lat_med 0.578–0.687 s wobec globalnego 0.188 s; hp_celu=100 w dwóch przypadkach (Troll, 19:58:11 i 20:05:55), kroki 2–5.
  skutek: 4 z 169 pościgów (2,4%) przerwanych, w tym 2 na celu z pełnym HP, który nie jest typowym słabym potworem uciekającym; dobicie nie następuje.
  propozycja: Sprawdzić funkcję wyboru celu pościgu (filtr po HP lub typie potwora) oraz próg, po którym latencja wpływa na decyzję o przerwaniu w obsłudze warunku 'gryzacy'.
- Jedno utknięcie w długim oknie przy prędkości pola niższej od typowej, bez powtórzeń i bez oscylacji; sygnał jest słaby. (pewność 0.2)
  dowód: okno_dlugie.utkniecia.liczba=1 (Jointoramix, s=16, stan WALKA, krok_s=0.75, pole v=16); bez_postepu=0; oscylacje.liczba=0; w oknie krótkim utkniecia=0.
  skutek: Brak dowodu na systemowy problem z dojściem; pojedynczy przypadek może wynikać z walki, nie z pościgu.
  propozycja: Brak zmiany w kodzie na tej podstawie; obserwować, czy utknięcia się powtarzają przy większej próbie.
- do zmierzenia: Czy 2 zgubione epizody są w danych pościgów jako 'przerwane_inne' lub jako pościgi bez zapisanego powodu? Zalogować powód końca dla każdego pościgu osobno, także gdy cel znika z widoku żywy.
- do zmierzenia: Czy wysoka latencja (lat_med > 0.5 s) predykcyjnie prowadzi do 'gryzacy'? Zebrać więcej pościgów z latencją z rozbiciem na powody wyjścia, bo n=4 jest za małe.
- do zmierzenia: Czy cele z pełnym HP (np. Troll hp_celu=100) są częstą przyczyną przerwań? Porównać wskaźnik dobić według hp_celu w dłuższym oknie.
- do zmierzenia: Czy naciski klawisza z postoju (122 w długim oknie) wynikają z blokady ścieżki? Sprawdzić, czy występują przy 'osiagalny=false' lub przy dużym 'droga' w logach.
- do zmierzenia: Porównanie trzymaj vs stuk nie jest możliwe, bo tryb stuk ma n=0 w obu oknach; uruchomić oba tryby na próbie co najmniej 30 pościgów każdy.

## 2026-10-15 20:13 | uwaga | pościgów 5 min: 65, 30 min: 196
- Wyjścia z pościgu z powodem 'gryzacy' skupiają się na trollach i mają wyraźnie wyższą latencję niż ogół pościgów. (pewność 0.35)
  dowód: okno_dlugie: powody_wyjsc 'gryzacy'=4 z 196 (2%), przerwane_inne=4; najgorsze_poscigi: 4 trolle, kroki 1/5/2/1, lat_med 0.578–0.687 s vs lat_med ogółem 0.189 s; dwa z nich przy hp_celu=100.
  skutek: W tych 4 przypadkach pościg został przerwany zamiast dobić cel (ok. 2% pościgów w długim oknie).
  propozycja: Przejrzeć w kodzie warunek wyjścia 'gryzacy' w pętli pościgu (jak i kiedy jest wykrywany atak celu); rozważyć, czy wyjście powinno być warunkowane odległością i czy dotyczy wyłącznie trolli. Nie skracać pościgu.
- Udział naciśnięć wysyłanych z postoju w trybie trzymaj wzrósł między oknami, mimo że tempo kroków pozostaje stabilne. (pewność 0.4)
  dowód: naciski_z_postoju_na_poscig: 0.35 (okno krótkie, 23/65) vs 0.63 (okno długie, 124/196); kroki_na_s med 1.43 vs 1.49; trzymane_proc_czasu 100 vs 98.
  skutek: Część naciśnięć nie przekłada się na ruch; nie widać jeszcze wpływu na dobicia (98% w długim oknie).
  propozycja: Sprawdzić funkcję wysyłania kroków w trybie trzymaj: warunek ponownego naciśnięcia, gdy pozycja się nie zmienia; ustalić, czy wzrost wynika z opóźnień (lat_med) czy z logiki.
- Skuteczność pościgu jest wysoka: prawie wszystkie zakończyły się dobiciem, bez zgubień i bez braku dojścia. (pewność 0.8)
  dowód: okno_krotkie: dobicie 65/65 (100%), odrzucone 0, bez_postepu 0, oscylacje 0; okno_dlugie: dobicie 192/196 (98%), zgubienie 0, bez_dojscia 0; odleglosc koniec_med=1 (start_med 2).
  skutek: Brak istotnej utraty dobić; ryzyko koncentruje się w pojedynczych wyjściach 'gryzacy' i w niespójności liczników.
  propozycja: Brak zmiany wymaganej; utrzymać obecną logikę pościgu i monitorować wyjścia 'gryzacy'.
- Jedno utknięcie w oknie długim nie tworzy wzorca; sygnał jest słaby. (pewność 0.2)
  dowód: utkniecia.liczba=1 (19:50:55, WALKA, 16 s, Jointoramix, pole v=16, krok_s=0.75); oscylacje 0; bez_postepu 0; brak powtórzeń.
  skutek: Brak wyraźnego kosztu; możliwe jednorazowe zakłócenie.
  propozycja: Brak akcji; obserwować, czy utknięcia się powtarzają.
- do zmierzenia: Czy wyjścia 'gryzacy' zdarzają się wyłącznie przy trollach i czy korelują z momentem, w którym cel zadał obrażenia (zapis hp_gracza w czasie wyjścia); zebrać większą próbę (n>=20).
- do zmierzenia: Czy 2 epizody z powodem 'zniknął z widoku żywy' odpowiadają pościgom zakończonym jako 'zgubienie' lub zostały pominięte w liczniku pościgów.
- do zmierzenia: Czy wzrost naciśnięć z postoju (0.35 -> 0.63) koreluje z wyższą lat_med lub z sekwencjami kroków, które nie zmieniły pozycji; porównać je z oknami o niższej latencji.
- do zmierzenia: Co dokładnie oznacza pole 'v' i 'krok_s' w statystykach pola; bez tego nie da się ocenić, czy utknięcie 16 s przy krok_s=0.75 jest nietypowe.
- do zmierzenia: Czy tryb stuk był w użyciu w jakimkolwiek oknie; obecne dane nie zawierają porównania trzymaj vs stuk.

## 2026-10-15 20:15 | uwaga | pościgów 5 min: 64, 30 min: 217
- Nieudane pościgi w oknie długim to niemal wyłącznie Trolle, które odpowiadają na atak (powód gryzacy), a opóźnienie reakcji w tych przypadkach jest wyraźnie wyższe niż ogółem. (pewność 0.4)
  dowód: powod gryzacy: 4 z 217 pościgów (okno długie), wszystkie na Trollu; lat_med w tych 4 przypadkach 0.58-0.69 s vs lat_med ogółem 0.2 s; hp_celu 100 w 2 z 4; przerwane_inne 4; ocena_zlego 3.2, 0.4, 0.2, 0.1
  skutek: Około 2% pościgów (4/217) kończy się przerwaniem zamiast dobicia. Trolle o pełnym HP nie są słabym uciekającym potworem, dla którego pościg został zaprojektowany.
  propozycja: Funkcja wyboru celu pościgu: rozważyć wykluczenie celów o wysokim hp_celu lub wysokim ocena_zlego (zaostrzenie progu kwalifikacji celu, nie skracanie samego pościgu). Dodatkowo sprawdzić, czy stała progu opóźnienia (lat_med) wpływa na decyzję o podjęciu pościgu.
- Naciśnięcia wysyłane z postoju w trybie trzymaj rosną między oknami, a liczba ponowień po braku ruchu rośnie równolegle. (pewność 0.35)
  dowód: naciski_z_postoju: 23 (krótkie) -> 129 (długie), na pościg 0.36 -> 0.59; ponow_brak 1 -> 13; trzymane_proc_czasu 100 -> 98; kroki_na_s med 1.6 -> 1.5 (stabilne); dobicie_proc 100 -> 98
  skutek: Więcej wejść wysyłanych bez ruchu postaci, potencjalnie marnowane wejścia. Wpływu na skuteczność dobicia nie da się stwierdzić z tych danych (spadek 2 pp przy n=217 jest słaby).
  propozycja: Funkcja wysyłania kroku w trybie trzymaj: sprawdzić warunek ponawiania wysyłki po braku ruchu (ponow_brak) oraz to, czy naciśnięcie z postoju jest wysyłane po zmianie kierunku przed potwierdzeniem ruchu. Do rozważenia przez człowieka.
- Liczba zmian kierunku na pościg wzrosła około dwukrotnie między oknami, co może być reakcją na zygzakowanie celu. (pewność 0.25)
  dowód: zmiany_kierunku na pościg: 12/64 = 0.19 (krótkie) -> 86/217 = 0.40 (długie); zmiany_kierunku_na_krok 0.28 -> 0.36; oscylacje 0 w obu oknach
  skutek: Więcej zmian kierunku bez oscylacji A-B-A-B nie przekłada się w danych na gorsze dobicie (dobicie 98-100%), ale zwiększa liczbę sterowanych zmian w pościgu.
  propozycja: Funkcja wyznaczania kierunku pościgu: rozważyć histerezę lub wygładzenie zmiany kierunku, tak aby mały ruch celu nie wymuszał zmiany kierunku przy każdym kroku.
- do zmierzenia: Czy zgubione epizody (2 w oknie długim, powód 'zniknął z widoku żywy') składają się z pościgów o zerowym liczniku zgubienie; porównać liczbę pościgów na epizod i powody końca na poziomie pościgu, bo e
- do zmierzenia: Czy naciśnięcia z postoju zbiegają się ze zmianą kierunku w tym samym kroku: policzyć naciski z postoju w krokach z zmianą kierunku vs bez zmiany.
- do zmierzenia: Czy opóźnienie 0.58-0.69 s jest cechą celu (Troll) czy chwilowym lagiem: zebrać lat_med osobno dla Trolli i innych celów oraz dla pościgów bez gryzacy.
- do zmierzenia: Wpływ trybu stuk: w danych nie ma pościgów stuk, więc nie da się porównać trzymaj vs stuk; zmierzyć skuteczność dobicia w obu trybach na tym samym typie celu.
- do zmierzenia: Czy ponow_brak jest przyczyną nacisków z postoju: zmierzyć, ile nacisków z postoju przypada na pojedyncze ponowienie.

## 2026-10-15 20:17 | uwaga | pościgów 5 min: 50, 30 min: 213
- Pościg dobija cel w 98% przypadków w obu oknach, bez zgubień w oknie krótkim. Utrata dobić koncentruje się w pościgach przerwanych przez gryzienie celu (powód 'gryzacy'). (pewność 0.5)
  dowód: okno_krotkie: dobicie 49/50 (98%), zgubienie 0; okno_dlugie: dobicie 208/213 (98%), gryzacy 4 (1,9%), przerwane_inne 4. Wszystkie 6 pozycji w najgorsze_poscigi to Troll, z czego 3 mają powod 'gryzacy'.
  skutek: Około 2% pościgów kończy się bez dobicia. Przy powtarzających się Trollach zaangażowanych w walkę może to zmniejszać liczbę dobić na godzinę.
  propozycja: Funkcja decyzji o wejściu/przerwaniu pościgu w stanie WALKA (obsługa powodu 'gryzacy'): dodać rejestrowanie HP gracza i celu oraz dystansu w chwili przerwania, zanim zmieni się reakcja. Do rozważenia przez człowieka po analizie danych.
- Opóźnienie reakcji (lat_med) w pościgach 'gryzacy' wydaje się wyraźnie wyższe niż ogółem, ale dane pochodzą tylko z najgorszych przypadków i nie pozwalają na porównanie grup. (pewność 0.4)
  dowód: Ogólnie lat_med 0,183 s (okno krótkie) i 0,186 s (długie). Dla najgorszych pościgów lat_med 0,575–0,687 s (n=6, wszystkie Trolle). Brak rozkładu lat_med dla pościgów 'gryzacy' vs pozostałe.
  skutek: Jeśli opóźnienie rośnie w walce, bot reaguje na ruch celu z opóźnieniem, co zwiększa ryzyko, że cel odpowie i przerwie pościg.
  propozycja: Funkcja pomiaru lat_med: zbierać wartości osobno dla każdego powodu wyjścia, nie tylko dla najgorszych pościgów.
- Ponowienia po braku ruchu rosną między oknami, co może wskazywać na postój postaci przy celu, jednak liczby są małe. (pewność 0.3)
  dowód: ponow_brak: okno krótkie 1/50 pościgów (0,02), okno długie 13/213 (0,061), czyli ok. 3×. Naciski z postoju na pościg są stabilne: 0,60 (krótkie) vs 0,64 (długie), więc poprzedni wniosek o ich wzroście nie jest potwierdzony w tej formie.
  skutek: Pojedyncze ponowienia są rzadkie, ale wzrost może oznaczać rosnące przypadki braku dojścia do celu.
  propozycja: Funkcja ponowienia po braku ruchu: zapisywać przyczynę (przeszkoda, zajęte pole, cel w walce) przy każdym ponowieniu.
- Zmiany kierunku wzrosły między oknami; poprzedni wniosek o 'dwukrotnym' wzroście dotyczył liczby na pościg, a na krok wzrost jest mniejszy (×1,5). (pewność 0.4)
  dowód: zmiany_kierunku_na_krok: 0,24 (krótkie) → 0,36 (długie), ×1,5. Na pościg: 10/50 = 0,20 → 86/213 = 0,40, ×2. Obie liczby pochodzą z tych samych danych, różnica wynika z mianownika.
  skutek: Więcej zmian kierunku może przedłużać pościg lub oznaczać zygzakowanie celu, co zwiększa liczbę kroków bez postępu, choć bez_postepu wynosi 0.
  propozycja: Funkcja liczenia zmian kierunku: rozdzielić zmiany wynikające z ruchu celu od zmian wynikających z korekty trasy bota.
- Liczba epizodów celu zgubionych (2) nie zgadza się z liczbą pościgów zakończonych zgubieniem (0). Prawdopodobnie różne definicje zliczania. (pewność 0.5)
  dowód: okno_dlugie: koniec.zgubienie 0, epizody_celu.zgubione 2, wskaznik 96, powod_top 'zniknął z widoku żywy'. niespojnosci w danych: pusta lista, więc nie zostało to zgłoszone.
  skutek: Nie wiadomo, czy wskaźnik 96% opisuje realną utratę celu, czy inną definicję, co utrudnia ocenę skuteczności.
  propozycja: Funkcja liczenia epizodów celu: dopisać warunek zgodności z powodami wyjść tak, aby zgubione epizody były liczone tylko przy powodzie 'zgubienie'.

## 2026-10-15 20:19 | ok | pościgów 5 min: 34, 30 min: 219
- Pościgi za trollami (hp celu 100), które skończyły się brakiem ruchu lub gryzieniem, miały wyraźnie wyższą latencję niż typowy pościg. (pewność 0.3)
  dowód: 3 najgorsze pościgi (Troll): lat_med 0.575, 0.578, 0.687 s vs lat_med ogólne 0.186 s (okno długie); start odl 4-5 vs med 2; kroki 2, 5, 2.
  skutek: Dłuższe dojście do celu i powtórne próby, bez utraty celu w danych (zgubienie 0%). Koszt czasowy, nie utrata dobić.
  propozycja: Sprawdzić funkcję filtrowania celów pościgu i stałą progu oceny zagrożenia (ocena_zlego) lub maksymalnego HP celu; kierunek: zawęzić pościg do celów słabych, zgodnie z opisem roli pościgu. Decyzja po stronie człowieka.
- Klawisz 'trzymaj' pozostaje wciśnięty także wtedy, gdy postać stoi w miejscu; przy 'brak_ruchu' i ponowieniach rośnie liczba takich naciśnięć. (pewność 0.4)
  dowód: Okno długie: naciski_z_postoju 140 przy trzymane_proc_czasu 100 (0.64 na pościg); ponow_brak 11 (okno krótkie 1); brak_ruchu 1 wyjście.
  skutek: Część czasu pościgu idzie na naciskanie bez postępu. Dobicia nadal 99%, więc koszt jest ograniczony.
  propozycja: Funkcja obsługi trzymania klawisza: dodać warunek puszczenia klawisza, gdy pozycja nie zmienia się przez kilka próbek (kierunek: krótszy czas trzymania w miejscu przed reakcją).
- Zmiany kierunku na krok rosną między oknami, co sugeruje częstsze korekty trasy. (pewność 0.25)
  dowód: zmiany_kierunku_na_krok: 0.27 (okno krótkie) → 0.34 (okno długie); zmiany_kierunku 85 w długim oknie przy 249 krokach.
  skutek: Część kroków to korekty, a nie ruch w stronę celu; wzrost jest umiarkowany i nie przekłada się na zgubienia.
  propozycja: Funkcja wyboru kierunku na trasie pościgu: rozważyć histerezę (nie zmieniać kierunku dla małej różnicy odległości); kierunek: mniej korekt na krok.
- do zmierzenia: Czy trolle mają wyższą latencję przez sam typ celu (n=3 najgorsze, za mało), czy przez odległość startową? Zmierzyć lat_med i start odl dla wszystkich pościgów na Troll vs inne cele (n>=20 na grupę).
- do zmierzenia: Porównanie trzymaj vs stuk: w danych brak pościgów w trybie 'stuk' (tryby zawierają tylko 'trzymaj'), więc nie da się ocenić, czy stuk poprawia wynik przy brak_ruchu. Zalogować tryb stuk przy tych sam
- do zmierzenia: Przyczyna brak_ruchu: czy postać stoi przez zablokowane pole (ściana, inny potwór), czy przez opóźnienie wejścia? Dodać do logu powód zablokowania ostatniego kroku.
- do zmierzenia: Przyczyna 'gryzacy' (2 wyjścia przy hp_gracza 100): czy cel atakuje postać i to przerywa pościg? Logować ataki celu w czasie pościgu.
- do zmierzenia: Czy zmiany kierunku przy zmianie odległości >1 są rzeczywistymi korektami, czy szumem pozycji? Zmierzyć liczbę zmian kierunku przy stałej pozycji celu.

## 2026-10-15 20:21 | uwaga | pościgów 5 min: 37, 30 min: 226
- Klawisz 'trzymaj' jest wciśnięty także wtedy, gdy postać stoi, i to w większości pościgów. (pewność 0.5)
  dowód: Okno długie: naciski_z_postoju=147 na 226 pościgów (0.65/pościg); okno krótkie: 35 na 37 (0.95/pościg). trzymane_proc_czasu=100, brak_ruchu tylko 1 raz.
  skutek: Nie ma w danych bezpośredniego pomiaru straty czasu. Dobicia są wysokie (97–99%), więc koszt jest prawdopodobnie mały, ale nie da się go policzyć z tych liczb.
  propozycja: Funkcja obsługi trzymania klawisza w cavebocie: rozważyć zwolnienie klawisza, gdy pozycja nie zmienia się przez stałą liczbę ms (nazwa stałej do ustalenia w kodzie). Decyzja po zmierzeniu kosztu (patrz hipotezy).
- Pościg jest skuteczny: prawie wszystkie kończą się dobiciem, żaden nie kończy się zgubieniem. (pewność 0.85)
  dowód: Okno długie: dobicie 223/226 (99%), zgubienie 0, odl_koniec_med=1.0. Okno krótkie: dobicie 36/37 (97%), zgubienie 0. Oscylacje 0 w obu oknach.
  skutek: Brak utraty dobić w obserwowanym zakresie.
  propozycja: Brak zmiany w kodzie wynikającej z tego punktu.
- Wnioski z poprzedniej analizy (ostatnie_wnioski) nie zgadzają się z bieżącymi liczbami w dwóch miejscach. (pewność 0.6)
  dowód: Podany wniosek, że naciski z postoju rosną między oknami, nie potwierdza się: na pościg spadły z 0.95 do 0.65. Zmiany kierunku na krok to 0.32 vs 0.33, czyli praktycznie bez zmiany.
  skutek: Wnioski oparte na błędnym odczycie mogą prowadzić do złych zmian w kodzie.
  propozycja: Nie powtarzać tych wniosków bez nowej przesłanki; sprawdzić, skąd wzięto trend.
- Wpis o utknięciu w stanie WALKA z potworem Jointoramix nie ma pokrycia w statystykach utknięć. (pewność 0.5)
  dowód: utkniecia.liczba=0 i utkniecia.ostatnie=[] w obu oknach, przy czym ostatnie_wnioski wspominają jedno utknięcie przy prędkości pola 0.75.
  skutek: Albo wpis pochodzi z innego okna/logu, albo licznik utknięć nie łapie tego przypadku; nie wiadomo, który.
  propozycja: Sprawdzić, czy licznik utknięć wyklucza stan WALKA albo czy wpis pochodzi z innego źródła danych.
- Najgorsze pościgi dotyczą celu Troll z HP 100, a nie słabego potwora z niskim HP, który jest typowym celem pościgu. (pewność 0.3)
  dowód: Trzy najgorsze pościgi to wszystkie Troll, hp_celu=100, kroki 2–5, czas 2.0–4.1 s, odl start 4–5. Dwa zakończyły się gryzacy lub brak_ruchu, jeden brak_ruchu. Próba n=3.
  skutek: Gryzący atak lub brak ruchu przerywa pościg zanim cel zostanie dobity; przy większym HP celu pościg trwa dłużej i jest bardziej podatny na przerwanie.
  propozycja: Kryterium wyboru celu pościgu (funkcja decydująca o rozpoczęciu pościgu): rozważyć wykluczenie lub osobny próg dla celów o dużym HP. Wartość progu do ustalenia po zebraniu większej próby.
- do zmierzenia: Ile ms upływa od ostatniego ruchu do puszczenia klawisza w pościgach z naciskami z postoju; jeśli to dziesiątki ms, koszt jest pomijalny; jeśli sekundy, to realna strata.
- do zmierzenia: Czy naciski z postoju występują przed dojściem do celu, po dojściu (w trakcie walki), czy przy blokadzie przez ścianę/potwora.
- do zmierzenia: Rozkład wyników per typ celu (Troll vs inne) na większej próbie, np. ≥30 pościgów z hp_celu=100, zanim uzna się wzorzec za stały.
- do zmierzenia: Czy wpis o utknięciu w WALKA pochodzi z tego samego okna i tego samego licznika co utkniecia.liczba.
- do zmierzenia: Czy gryzacy występuje częściej przy celach o HP 100 niż przy słabych celach, licząc udział w każdej grupie HP.

## 2026-10-15 20:23 | ok | pościgów 5 min: 36, 30 min: 230
- Wszystkie 3 pościgi, które nie skończyły się dobiciem, mają podwyższone opóźnienie (lat_med), a 3 najgorsze pościgi w oknie długim to dokładnie te 3 przypadki. (pewność 0.45)
  dowód: okno_dlugie: przerwane_inne=2 (gryzacy), bez_dojscia/brak_ruchu=1; najgorsze_poscigi lat_med 0.575, 0.578, 0.687 przy medianie okna długiego 0.185 s; tryb trzymaj, dec_med 0.0.
  skutek: 3 z 230 pościgów (1,3%) skończyło się bez dobicia; w oknie krótkim 0 takich przypadków przy 36 pościgach, więc nie da się tego potwierdzić na krótkiej próbce.
  propozycja: Sprawdzić w kodzie, co dzieje się z ruchem po przekroczeniu progu opóźnienia (funkcja obsługująca lat/dec w pętli pościgu); rozważyć, czy przy wysokim lat_med pościg nie powinien przechodzić w ponowną ocenę celu zamiast ślepego trzymania klawisza (opis zmiany do rozważenia, bez wartości).
- Wszystkie 3 nieudane pościgi dotyczą celu Troll z HP 100 i rejonu o niskiej prędkości pola, a nie słabego potwora z niskim HP. (pewność 0.35)
  dowód: najgorsze_poscigi: cel Troll, hp_celu 100 (3/3); pole.v 14, 16, 14 i krok_s 0.66, 0.75, 0.66 wobec kroki_na_s med 1.73 w oknie długim; osiagalny=true w dwóch przypadkach.
  skutek: Obecne dane nie pozwalają oddzielić wpływu typu celu od wpływu terenu i opóźnienia, bo wszystkie 3 porażki mają te same cechy naraz.
  propozycja: Dodać do logu typ celu i wartość pole.v dla każdego pościgu, żeby policzyć wskaźnik dobicia osobno dla celu i terenu (nie zmieniać progów, dopóki nie ma tych danych).
- Naciśnięcia klawisza wykonywane z postoju występują w większości pościgów w trybie trzymaj, choć klawisz jest trzymany przez 100% czasu. (pewność 0.3)
  dowód: okno_dlugie: naciski_z_postoju=137 na 230 pościgów (0,6 na pościg); okno_krotkie: 26 na 36 (0,72 na pościg); trzymane_proc_czasu=100.
  skutek: Nie wiadomo, czy to zbędne wysyłanie wejścia, czy tylko nadmiarowe zdarzenia; w danych nie ma kosztu w postaci utraconego kroku (odrzucone=0).
  propozycja: Sprawdzić funkcję wysyłającą klawisz w trybie trzymaj: czy wysyła key-down także wtedy, gdy klawisz jest już trzymany i postać stoi; ewentualna zmiana dotyczyłaby warunku wysyłania, nie stałej czasowej.
- W bieżącym oknie długim nie ma żadnego utknięcia ani oscylacji, więc wpis o utknięciu w stanie WALKA z Jointoramix nie znajduje potwierdzenia w tych danych. (pewność 0.8)
  dowód: okno_dlugie: utkniecia.liczba=0, oscylacje.liczba=0, bez_postepu.poscigow=0, odrzucone=0; niespojnosci=[].
  skutek: Jeśli wpis pochodzi z innego czasu lub logu, nie da się go tu ocenić; ryzyko przypisania problemu w złym miejscu.
  propozycja: Brak zmiany w kodzie; sprawdzić źródło wpisu (inne okno czasowe lub inny log) przed przypisaniem mu przyczyny.
- Tryb stuk nie był używany w żadnym z dwóch okien, więc nie ma porównania trzymaj vs stuk. (pewność 0.9)
  dowód: okno_krotkie i okno_dlugie: tryby zawierają tylko trzymaj; brak wpisów stuk.
  skutek: Nie da się ocenić, czy tryb trzymaj jest lepszy dla tych celów; wnioski o wyższości trybu byłyby zgadywaniem.
  propozycja: Uruchomić porównanie trybów na tym samym typie celu, żeby mieć dane do decyzji.
- do zmierzenia: Czy opóźnienie (lat_med) powyżej ~0,5 s koreluje z przerwanymi pościgami: zebrać lat per pościg dla wszystkich pościgów i porównać odsetek dobić w grupach lat niskie/wysokie.
- do zmierzenia: Czy wynik zależy od typu celu: policzyć dobicie osobno dla słabych potworów z niskim HP i dla Trolla (w danych jest tylko 3 pościgi Troll, więc n za małe na wniosek).
- do zmierzenia: Czy prędkość pola (pole.v) obniża kroki_na_s i szansę dobicia: zebrać pole.v dla wszystkich pościgów i porównać z kroki_na_s.
- do zmierzenia: Co znaczy powód 'gryzacy' (nie występuje w schemacie powodów z opisu); zdefiniować go, zanim policzy się go jako porażkę.
- do zmierzenia: Czy naciski_z_postoju są zbędnymi zdarzeniami wejścia: porównać liczbę naciśnięć z liczbą faktycznych kroków w tych samych przedziałach czasu.

## 2026-10-15 20:25 | ok | pościgów 5 min: 24, 30 min: 227
- Pościg kończy się dobiciem w prawie wszystkich przypadkach; utrata dobić jest marginalna i nie wynika z jednego wzorca. (pewność 0.6)
  dowód: Okno długie: dobicie 224/227 (99%), zgubienie 0, bez_dojscia/brak_ruchu 1, przerwane_inne 2. Okno krótkie: dobicie 24/24 (100%). Epizody celu: 49/49 zabite w długim oknie.
  skutek: Koszt to około 1% pościgów przerwanych bez dobicia (3 z 227), co przy tej skali jest nieistotne.
  propozycja: Brak zmiany wymaganej. Obserwować funkcję wykrywającą brak_ruchu w pościgu (przy wyjściu z trybu IDZ), bo to jedyne przerwanie bez oczywistej przyczyny.
- Naciski klawisza z postoju pojawiają się w większości pościgów, mimo że klawisz jest trzymany przez 100% czasu; nie wiadomo, czy to zbędne wysyłki, czy powtórzenia ruchu. (pewność 0.4)
  dowód: naciski_z_postoju: 135 w oknie długim, czyli 0.59 na pościg (135/227 pościgów z co najmniej jednym naciskiem); trzymane_proc_czasu 100; zmiany_kierunku_na_krok 0.3; kroki_na_s med 1.8.
  skutek: Jeśli naciski są zbędne, mogą zakłócać ciągłość ruchu, ale w danych nie widać to w utracie dobić (99%). Efekt nie jest rozstrzygnięty.
  propozycja: Sprawdzić w kodzie, czy logika trybu trzymaj wysyła ponowne naciśnięcie klawisza, gdy postać stoi (np. funkcja decydująca o ponowieniu ruchu); opisać warunek, a nie zmieniać wartości.
- Trzy najgorsze pościgi występują przy wyższej latencji niż mediana, co może sugerować, że opóźnienie sprzyja wyjściom typu brak_ruchu lub gryzacy. (pewność 0.3)
  dowód: lat_med 0.575, 0.578, 0.687 s w najgorszych pościgach vs mediana 0.186 s w oknie długim (oraz 0.6 s w oknie krótkim). Próba n=3, więc niska pewność.
  skutek: Przy wysokim opóźnieniu cel może zostać zgubiony lub postać może zostać uznana za stojącą, co kończy pościg przed dobiciem.
  propozycja: Rozważyć w kodzie, czy próg czasu wykrywania brak_ruchu (stała czasowa w logice IDZ) powinien uwzględniać zmierzoną latencję; zmiana kierunkowa: próg wrażliwy na lat_med.
- Wyjścia z powodu gryzacy i przerwane_inne sugerują, że atak celu przerywa pościg zamiast być obsłużony. (pewność 0.25)
  dowód: Okno długie: powody gryzacy 2 (0.9%), przerwane_inne 2; najgorszy pościg gryzacy: kroki 5, czas 4.07 s, hp_gracza 100. Liczba bardzo mała.
  skutek: Pojedyncze przerwania, koszt niewielki; w tych przypadkach pościg kończy się bez dobicia.
  propozycja: Zbadać funkcję decydującą o wyjściu z pościgu przy otrzymaniu ataku; rozważyć, czy przy wysokim hp_gracza przerwanie jest konieczne. Opisać warunek, nie zmieniać progów.
- Jeden pościg przerwany przez brak_ruchu mimo osiągalnej drogi: postać zrobiła 2 kroki i stanęła przy dystansie 3. (pewność 0.2)
  dowód: Najgorszy pościg: Troll, powod brak_ruchu, kroki 2, czas 2.64 s, odl [5,3], droga 9, osiagalny true, lat_med 0.575, pole krok_s 0.66.
  skutek: Pojedynczy przypadek utraty dobicia; nie da się stwierdzić, czy to wzorzec.
  propozycja: Bez wniosku o zmianie; sprawdzić, czy przy tej samej pozycji powtarza się brak ruchu (logowanie zdarzeń ruchu).
- do zmierzenia: Logować zdarzenia klawisza (wciśnięcie/puszczenie z czasem), aby odróżnić ponowne wysłanie klawisza od rzeczywistego ruchu postaci i sprawdzić, czy 135 naciśnięć z postoju to powtórki.
- do zmierzenia: Zmierzyć korelację lat_med z powodem brak_ruchu i gryzacy na większej próbie (np. kilkaset pościgów), aby odrzucić przypadkowość wyników n=3.
- do zmierzenia: Zebrać dane z trybu stuk; obecnie nie było użycia, więc nie da się porównać go z trzymaj.
- do zmierzenia: Zapisać typ celu i jego prędkość przy wyjściach gryzacy i brak_ruchu, aby sprawdzić, czy przerwania są specyficzne dla danego potwora (np. Troll).

## 2026-10-15 20:27 | uwaga | pościgów 5 min: 49, 30 min: 245
- Wyjścia typu „gryzacy” (cel atakuje) przerywają pościg zamiast go kontynuować. (pewność 0.4)
  dowód: Okno długie: powody_wyjsc gryzacy=2 z 245 pościgów (0.8%), koniec przerwane_inne=2; oba w najgorszych, Troll, hp_celu 100, lat_med 0.578 i 0.687 (mediana 0.2), kroki 5 i 2.
  skutek: Około 1% pościgów kończy się bez dobicia (łącznie 3/245 niedobicia: 2 gryzacy + 1 brak_ruchu), a cel zostaje przy życiu.
  propozycja: Funkcja obsługi wyjścia „gryzacy” w pętli pościgu: sprawdzić, czy przerwanie po ataku celu jest zamierzone; rozważyć kontynuację ruchu w kierunku celu mimo ataku.
- Pościg został przerwany jako brak_ruchu, mimo że droga do celu była osiągalna. (pewność 0.3)
  dowód: Najgorszy pościg 20:17:16: powod brak_ruchu, kroki 2, czas 2.64 s, odl start 5 -> koniec 3, droga 9, osiagalny=true, stan IDZ, lat_med 0.575, zmiany_kier 5.
  skutek: Pojedyncze dobicie utracone, mimo że cel był w zasięgu drogi (1 przypadek, niska próba).
  propozycja: Funkcja warunku brak_ruchu (licznik bezruchu/timeout pętli): sprawdzić, czy wyjście nie uruchamia się zbyt wcześnie przy wyższej latencji; rozważyć wydłużenie okna bezruchu o czas latencji.
- Najgorsze pościgi mają wyraźnie wyższą latencję niż mediana, ale to tylko 3 przypadki. (pewność 0.25)
  dowód: lat_med w najgorszych: 0.575, 0.578, 0.687 s; mediana okna długiego: 0.2 s (ok. 3x). Brak rozkładu latencji (p90) dla wszystkich pościgów, więc nie wiadomo, czy to wyróżnik.
  skutek: Jeśli latencja realnie sprzyja wyjściom, błędy będą rosły przy lagach serwera; obecnie nie da się tego potwierdzić.
  propozycja: Dodać do statystyk p90 latencji per pościg i korelację latencji z wyjściami innymi niż odl<=1.
- Wszystkie 3 najgorsze pościgi dotyczą Trolla z pełnym HP, ale dane nie rozbijają skuteczności per potwór. (pewność 0.2)
  dowód: najgorsze_poscigi: cel Troll, hp_celu 100 we wszystkich trzech; okno długie: zabite 49/49 epizodów celu, bez rozbicia na typy potworów.
  skutek: Możliwe, że trudniejsze cele (silniejszy atak) częściej przerywają pościg; nie da się tego ocenić z obecnych liczb.
  propozycja: Dodać do statystyk wskaźnik dobicia i gryzacy per nazwa celu (np. klucz cel w agregacji wyjść).
- Duża liczba „nacisków z postoju” w trybie trzymaj, przy 100% czasu trzymania. (pewność 0.25)
  dowód: Okno długie: trzymane_proc_czasu 100, naciski_z_postoju 135 (0.55 na pościg), zmiany_kierunku 67 (0.27 na krok); okno krótkie: naciski_z_postoju 19 przy 49 pościgach.
  skutek: Nie wiadomo, czy postać traci czas na klawisze w miejscu; może to dokładać opóźnień przy brak_ruchu, ale brak dowodu.
  propozycja: Funkcja wysyłania klawisza w trybie trzymaj: sprawdzić, co liczy się jako „naciśnięcie z postoju” i czy generuje zbędne sygnały ruchu.

## 2026-10-15 20:29 | ok | pościgów 5 min: 49, 30 min: 239
- Pościg dobija prawie wszystkie cele: w oknie krótkim 49/49 (100%), w długim 237/239 (99%), bez żadnego zgubienia celu. (pewność 0.85)
  dowód: okno_krotkie: koniec.dobicie=49, zgubienie=0; okno_dlugie: dobicie=237 z 239, zgubienie=0, dobicie_proc=99; epizody_celu.wskaznik=100 (krótkie) i 100 (długie).
  skutek: Brak istotnej utraty dobić. Jedyne niedobicia w oknie długim to 2 pościgi (brak_ruchu, gryzacy) i 1 przerwane_inne, czyli około 0,8% prób.
  propozycja: Brak zmiany wymagana na podstawie tych danych.
- Oba najgorsze pościgi kończą się bardzo wcześnie (2 kroki) na dystansie 3, przy pełnym HP celu, mimo osiągalnej drogi; powody to brak_ruchu i gryzacy. (pewność 0.3)
  dowód: najgorsze_poscigi: Troll, hp_celu=100, kroki=2, odl [5,3] i [4,3], droga 9 i 6, osiagalny=true, lat_med 0.575 i 0.687 s vs mediana 0.2 s (okno długie).
  skutek: Pościg zatrzymuje się przed dobiciem, cel zostaje przy życiu; w danych to tylko 2 przypadki z 239, więc wzorzec jest niepewny.
  propozycja: Sprawdzić funkcję decydującą o wyjściu z pętli przy braku ruchu (warunek brak_ruchu) oraz logikę wyjścia powodu gryzacy; rozważyć, czy próg czasu bez zmiany pozycji nie jest zbyt krótki przy dłuższej latencji.
- W trybie trzymaj licznik naciśnięć z postoju jest wysoki, mimo że trzymane_proc_czasu wynosi 100%, co sugeruje rozbieżną definicję tych metryk. (pewność 0.4)
  dowód: okno_dlugie: naciski_z_postoju=124 (0,52 na pościg), trzymane_proc_czasu=100; okno_krotkie: naciski_z_postoju=14 (0,29 na pościg), trzymane_proc_czasu=100.
  skutek: Nie wiadomo, czy bot wysyła klawisz bez ruchu postaci (np. zablokowany przez przeszkodę), czy to tylko błąd w liczeniu; to utrudnia ocenę efektywności kroków.
  propozycja: Sprawdzić funkcję liczącą naciski_z_postoju oraz miejsce, w którym wysyłany jest klawisz trzymany, gdy pozycja się nie zmienia; ustalić jednoznaczną definicję.
- Latencja mediana w oknie krótkim jest ponad trzykrotnie wyższa niż w długim, co może być chwilowym zjawiskiem. (pewność 0.3)
  dowód: lat_med_s: 0.6 (krótkie, n=49) vs 0.2 (długie, n=239); kroki_na_s p10: 1.44 vs 1.17.
  skutek: Krótsza próba nie pozwala odróżnić chwilowego obciążenia od stałego problemu; wpływ na dobicia jest niewidoczny (100% w krótkim).
  propozycja: Brak konkretnej zmiany; obserwować latencję w dłuższym oknie.
- W oknie długim wysłano 186 z 233 kroków (80%), a 47 kroków nie ma wyjaśnienia w danych. (pewność 0.3)
  dowód: okno_dlugie.tryby.trzymaj: kroki=233, wyslane=186, odrzucone=0, ponow_brak=4.
  skutek: Nie wiadomo, czy część kroków nie jest wysyłana, czy są liczone z różnicy pozycji; to wpływa na wiarygodność kroki_na_s.
  propozycja: Sprawdzić, jak liczony jest licznik kroki (różnica pozycji vs liczba wysłanych poleceń ruchu) oraz co to ponow_brak.

## 2026-10-15 20:32 | uwaga | pościgów 5 min: 21, 30 min: 226
- Dwa z 226 pościgów w oknie długim zakończyły się bez dobicia, oba na Trollu z pełnym HP (100), po 2 krokach, co nie pasuje do założenia, że cel to słaby uciekający potwór. (pewność 0.5)
  dowód: najgorsze_poscigi: Troll hp_celu=100, powod=brak_ruchu (kroki=2, odl 5->3) i Troll hp_celu=100, powod=gryzacy (kroki=2, odl 4->3); koniec: bez_dojscia=1, przerwane_inne=1 (łącznie 0.9%); dobicie_proc=99.
  skutek: Około 1% pościgów nie kończy się dobiciem; oba przypadki to cele, których pościg nie powinien był zaczynać lub z którymi walka wygląda inaczej niż ucieczka.
  propozycja: Sprawdzić w kodzie, czy filtr wyboru celu pościgu uwzględnia HP celu i typ potwora; rozważyć zawężenie kryterium (stała progu HP celu w warunku startu pościgu) w kierunku wykluczania celów o pełnym HP.
- W nieudanych pościgach mediana latencji była wyraźnie wyższa niż w całym oknie długim, co może pośrednio prowadzić do utraty kontaktu z celem. (pewność 0.3)
  dowód: lat_med_s=0.575 i 0.687 w dwóch najgorszych pościgach vs lat_med_s=0.2 dla trzymaj w oknie długim; w oknie krótkim lat_med_s=0.6.
  skutek: Możliwe opóźnienie reakcji na zmianę pozycji celu, co zwiększa ryzyko brak_ruchu lub gryzacy; przy n=2 to tylko sygnał.
  propozycja: Zbadać funkcję odczytu pozycji i wysyłania kroku (timeout/oczekiwanie na potwierdzenie ruchu) i sprawdzić, czy długa latencja wiąże się z porażką; kierunek: skrócenie oczekiwania, jeśli okaże się czynnikiem.
- Metryka naciśnięć z postoju jest niespójna z metryką trzymania: tryb trzymaj ma 100% czasu trzymania, a mimo to rejestruje 118 naciśnięć z postoju. (pewność 0.6)
  dowód: okno_dlugie: trzymane_proc_czasu=100, naciski_z_postoju=118 (0.52 na pościg); okno_krotkie: trzymane_proc_czasu=100, naciski_z_postoju=6 (0.29 na pościg).
  skutek: Nie da się ocenić, czy naciśnięcia z postoju to rzeczywisty koszt (przerwy w ruchu), czy błąd liczenia; decyzje o trybie mogą opierać się na złej metryce.
  propozycja: Ujednolicić definicję naciśnięcia z postoju i czasu trzymania w funkcji liczącej statystyki (jedna stała/licznik dla stanu 'klawisz wciśnięty, postać stoi'), a potem ponownie policzyć.
- Liczba wysłanych kroków nie zgadza się z liczbą kroków pościgu w trybie trzymaj, a różnica nie jest wyjaśniona. (pewność 0.4)
  dowód: okno_dlugie trzymaj: kroki=226, wyslane=178 (różnica 48), odrzucone=0, ponow_brak=4.
  skutek: Część kroków może być liczona, lecz nie wysyłana (lub odwrotnie), co utrudnia ocenę skuteczności komend ruchu.
  propozycja: Dodać w logowaniu wysyłania kroku identyfikator powiązany z pozycją i sprawdzić, które kroki nie dotarły do klienta; kierunek: spójne liczenie 'kroki' i 'wyslane' w jednej funkcji.
- Zmiany kierunku są częstsze w oknie krótkim niż długim, a tempo kroków ma długi ogon wolnych wartości. (pewność 0.2)
  dowód: zmiany_kierunku_na_krok: 0.44 (krótkie) vs 0.27 (długie); kroki_na_s p10=1.17 (długie) vs med=1.8; utkniecia: 1 zdarzenie w stanie WALKA, pole v=16, krok_s=0.75.
  skutek: Wolniejsze dojście w części pościgów wydłuża czas ucieczki celu; pojedyncze utknięcie przy walce z Trollem nie daje podstaw do wniosku.
  propozycja: Obserwować rozkład kroków/s w kolejnych oknach zanim cokolwiek zmieniać; ewentualnie zbadać funkcję obliczania kierunku ruchu przy zmianach pozycji celu.

## 2026-10-15 20:34 | uwaga | pościgów 5 min: 14, 30 min: 222
- Pościg dobija prawie wszystkie cele, a dystans do celu maleje w każdym pościgu z danych (delta_med -1). (pewność 0.9)
  dowód: Okno długie: dobicie 220/222 (99%), zgubienie 0, delta_med -1.0, bez_postepu 0, oscylacje 0. Okno krótkie: dobicie 14/14 (100%).
  skutek: Brak utraty celów poza 2 przypadkami na 222 pościgi; nie ma dowodu na problem strukturalny.
  propozycja: Brak zmiany wymaganej przez te dane.
- Oba nieudane pościgi dotyczą Trolla z pełnym HP celu i kończą się po 2 krokach przy wyraźnie podwyższonym opóźnieniu. (pewność 0.4)
  dowód: Najgorsze pościgi: Troll 20:17:16 brak_ruchu, kroki 2, lat_med 0.575 s, droga 9, osiagalny true; Troll 20:05:55 gryzacy, kroki 2, lat_med 0.687 s. Mediana lat_med w oknie długim to 0.187 s, czyli ok. 3x mniej. Te dwa przypadki to jedyne niedobicia w oknie dług
  skutek: Każde takie zdarzenie to utracone dobicie, a przy opóźnieniu pościg przestaje działać zanim cel zostanie dogoniony.
  propozycja: Stała czasu wykrywania 'brak_ruchu' (licznik bez zmiany pozycji) powinna uwzględniać bieżące lat_med, zamiast być stałą; do rozważenia: funkcja liczenia bez_ruchu z marginesem proporcjonalnym do lat_med. Dla powodu 'gryzacy' sprawdzić, czy warunek przerwania nie zadziała, gdy cel nadal ucieka (cel_dxdy wskazuje oddalan
- Przypadek 'brak_ruchu' pojawił się mimo istniejącej drogi (droga 9, osiagalny true), więc postać stała, a nie została źle wyznaczona trasa. (pewność 0.3)
  dowód: Troll 20:17:16: stan IDZ, czas 2.64 s, kroki 2 (0.76 kroków/s), odl [5,3], pole v 14, krok_s 0.66, osiagalny true, droga 9.
  skutek: Pościg został przerwany mimo możliwej trasy, co kosztuje dobicie.
  propozycja: Funkcja wykonująca krok po wyznaczeniu trasy: sprawdzić, czy przy wysokim lat_med nie wysyłane są ponowne komendy ruchu, zanim poprzednie zostaną potwierdzone.
- Tempo kroków w oknie długim ma wyraźny ogon wolnych wartości, a w oknie krótkim mediana jest niższa. (pewność 0.3)
  dowód: Okno długie: kroki_na_s med 1.82, p10 1.17, p90 2.24. Okno krótkie: med 1.6, p10 1.44 (n=14, niska pewność).
  skutek: Wolniejsze pościgi dają cel więcej czasu na ucieczkę, ale w danych nie prowadzą do zgubienia.
  propozycja: Funkcja liczenia kroków/s w oknie: zbadać, czy wolne wartości pokrywają się z podwyższonym lat_med.
- Pojedyncze utknięcie w stanie WALKA (Jointoramix i Troll) trwało 15 s przy tempie pola 0.75 kroku/s. (pewność 0.2)
  dowód: Utkniecia: liczba 1, poz [33078,31772,8], s 15, pole v 16, krok_s 0.75, godz 20:30:05.
  skutek: Jednorazowe zdarzenie w walce, nie w pościgu; nie da się z niego wyciągnąć trendu.
  propozycja: Brak; obserwować, czy się powtórzy.
- do zmierzenia: Czy lat_med > ~0.4 s przewiduje wyjścia brak_ruchu/gryzacy? Zmierzyć lat_med dla wszystkich pościgów i porównać odsetek niedobić powyżej i poniżej progu.
- do zmierzenia: Czy niedobicia dotyczą wyłącznie Trolli? Policzyć łączną liczbę pościgów Trolla i ich odsetek niedobić względem innych celów.
- do zmierzenia: Czym są 'naciski_z_postoju' (117 w oknie długim) przy 100% czasu trzymania? Sprawdzić, czy to zdarzenia powtórzenia klawisza, czy rzeczywiste postoje, i czy korelują ze zmianami kierunku.
- do zmierzenia: Dlaczego wysłane (176) są mniejsze niż kroki (217) w oknie długim? Zmierzyć, czy kroki są liczone z odczytu pozycji, a wysłane z komend, i czy różnica pokrywa się z kolizjami lub odrzuceniami.
- do zmierzenia: Czy zdarzenia 'gryzacy' zachodzą przy zmianie pozycji celu (cel_dxdy), czy niezależnie od ucieczki? Zapisać kierunek ruchu celu w chwili wyjścia.
