# Pomoc Karola: co zrobił inaczej niż bot

## 2026-10-11 15:20:20-15:20:32 (12 s) Karol pomaga botowi; powód: zmiana_celu; HP 100% -> 100%; exp 5; żywych 4->maks 4, stykających maks 2.
- zmienił cel z Rat 5% (uciekinier) na Rat 75% (najsłabszego stykającego), bot celował w innego.
- zaatakował Rat 20% zamiast celu bota (dobił uciekiniera).
- bot przed tym: stan WALKA, cel Rat 80% (odl 4), ostatnio: nowy cel Rat (hp 20%).

## 2026-10-11 15:21:25-15:21:33 (7 s) Karol pomaga botowi; powód: zmiana_celu; HP 99% -> 99%; exp 0; żywych 4->maks 4, stykających maks 2.
- zmienił cel z Rat 75% na Rat 100% (stykającego).
- zaatakował Rat 100% zamiast celu bota.
- bot przed tym: stan WALKA, cel Rat 100% (odl 1), ostatnio: nowy cel Rat (hp 100%).

## 2026-10-11 15:22:34-15:22:37 (3 s) Karol gra (bot bez telemetrii); powód: ruch_bez_telemetrii_bota, gra_reczna_bot_cichy; HP 99% -> 99%; exp 0; żywych 1->maks 1, stykających maks 0.
- przeszedł 2 pól, zabił ok. 0 (wg exp).
- bot przed tym: stan WALKA, ostatnio: loot.

## 2026-10-11 15:32:13-15:32:16 (4 s) Karol pomaga botowi; powód: zmiana_celu, ruch_nie_zlecony; HP 68% -> 68%; exp 5; żywych 4->maks 4, stykających maks 3.
- zmienił cel z Rat 45% na Rat 15% (najsłabszego stykającego).
- zmienił cel z Rat 15% na Rat 10% (najsłabszego stykającego).
- zaatakował Rat 45% zamiast celu bota.
- zmienił pozycję o 4 kroków, choć bot stał przy celu.
- bot przed tym: stan WALKA, cel Rat 20% (odl 3), ostatnio: nowy cel Rat (hp 20%).

## 2026-10-11 15:33:52-15:36:12 (140 s) Karol gra przy zatrzymanym bocie; powód: stop_reczny, ruch_przy_zatrzymanym_bocie, aktywnosc_przy_zatrzymanym_bocie; HP 68% -> 80%; exp 10; żywych 0->maks 5, stykających maks 3.
- zmienił cel z Rat 100% na Rat 100%.
- zmienił cel z Rat 100% na Rat 95% (najsłabszego stykającego).
- zmienił cel z Rat 25% na Rat 100% (stykającego).
- uciekał o 41 pól od skupiska (bot tego nie robi).
- zatrzymał bota (STOP_RECZNY).
- przeszedł 99 pól, zabił ok. 2 (wg exp).

## 2026-10-11 15:37:43-15:39:12 (89 s) Karol gra przy zatrzymanym bocie; powód: ruch_przy_zatrzymanym_bocie, aktywnosc_przy_zatrzymanym_bocie; HP 80% (min 70%) -> 70%; exp 0; żywych 0->maks 6, stykających maks 3.
- zmienił cel z Rat 100% na Rat 100% (stykającego).
- uciekał o 15 pól od skupiska (bot tego nie robi).
- przeszedł 33 pól, zabił ok. 0 (wg exp).

## 2026-10-11 15:39:12-15:39:14 (2 s) Karol gra (bot bez telemetrii); powód: gra_reczna_bot_cichy; HP 70% -> 70%; exp 0; żywych 5->maks 5, stykających maks 3.
- bot przed tym: stan WALKA.

## 2026-10-11 15:43:12-15:43:14 (1 s) Karol gra (bot bez telemetrii); powód: ruch_bez_telemetrii_bota, gra_reczna_bot_cichy; HP 45% -> 45%; exp 0; żywych 0->maks 0, stykających maks 0.
- przeszedł 2 pól, zabił ok. 0 (wg exp).
- bot przed tym: stan LOOT.

## 2026-10-11 15:49:52-15:49:53 (1 s) Karol gra przy zatrzymanym bocie; powód: ruch_przy_zatrzymanym_bocie, aktywnosc_przy_zatrzymanym_bocie; HP 45% -> 45%; exp 0; żywych 2->maks 2, stykających maks 0.
- przeszedł 2 pól, zabił ok. 0 (wg exp).

## 2026-10-11 15:52:17-15:52:20 (2 s) Karol gra (bot bez telemetrii); powód: ruch_bez_telemetrii_bota, gra_reczna_bot_cichy; HP 56% -> 57%; exp 0; żywych 0->maks 0, stykających maks 0.
- przeszedł 2 pól, zabił ok. 0 (wg exp).
- bot przed tym: stan LOOT.

## 2026-10-11 15:53:48-15:54:01 (13 s) Karol gra (bot bez telemetrii); powód: ruch_bez_telemetrii_bota, gra_reczna_bot_cichy; HP 65% -> 66%; exp 0; żywych 2->maks 2, stykających maks 0.
- przeszedł 7 pól, zabił ok. 0 (wg exp).
- bot przed tym: stan WALKA.

## 2026-10-11 15:56:55-15:56:58 (4 s) Karol gra (bot bez telemetrii); powód: ruch_bez_telemetrii_bota, gra_reczna_bot_cichy; HP 82% -> 84%; exp 0; żywych 0->maks 0, stykających maks 0.
- przeszedł 2 pól, zabił ok. 0 (wg exp).
- bot przed tym: stan WALKA, ostatnio: loot.

## 2026-10-11 15:57:22-15:57:23 (1 s) Karol gra (bot bez telemetrii); powód: ruch_bez_telemetrii_bota, gra_reczna_bot_cichy; HP 85% -> 86%; exp 0; żywych 0->maks 0, stykających maks 0.
- przeszedł 1 pól, zabił ok. 0 (wg exp).
- bot przed tym: stan WALKA.

## 2026-10-11 16:01:16-16:01:30 (14 s) Karol gra przy zatrzymanym bocie; powód: stop_reczny, ruch_przy_zatrzymanym_bocie, aktywnosc_przy_zatrzymanym_bocie; HP 100% -> 100%; exp 3; żywych 0->maks 0, stykających maks 0.
- zatrzymał bota (STOP_RECZNY).
- przeszedł 5 pól, zabił ok. 0 (wg exp).

## 2026-10-11 16:10:14-16:10:20 (6 s) Karol gra (bot bez telemetrii); powód: ruch_bez_telemetrii_bota, gra_reczna_bot_cichy; HP 100% -> 100%; exp 0; żywych 0->maks 0, stykających maks 0.
- przeszedł 7 pól, zabił ok. 0 (wg exp).
- bot przed tym: stan LOOT, ostatnio: loot.

## 2026-10-11 16:12:55-16:13:04 (9 s) Karol gra przy zatrzymanym bocie; powód: aktywnosc_przy_zatrzymanym_bocie, ruch_przy_zatrzymanym_bocie; HP 100% -> 100%; exp 0; żywych 2->maks 3, stykających maks 2.
- cofnął się o 2 pól od skupiska (bot tego nie robi).
- przeszedł 2 pól, zabił ok. 0 (wg exp).

## 2026-10-11 16:17:06-16:17:13 (7 s) Karol gra (bot bez telemetrii); powód: ruch_bez_telemetrii_bota, gra_reczna_bot_cichy; HP 100% -> 100%; exp 0; żywych 0->maks 0, stykających maks 0.
- przeszedł 3 pól, zabił ok. 0 (wg exp).
- bot przed tym: stan LOOT.

## 2026-10-11 16:20:30-16:20:33 (3 s) Karol gra przy zatrzymanym bocie; powód: ruch_przy_zatrzymanym_bocie, aktywnosc_przy_zatrzymanym_bocie; HP 100% -> 100%; exp 0; żywych 1->maks 2, stykających maks 0.
- przeszedł 4 pól, zabił ok. 0 (wg exp).

## 2026-10-11 16:22:10-16:22:11 (1 s) Karol gra (bot bez telemetrii); powód: ruch_bez_telemetrii_bota, gra_reczna_bot_cichy; HP 100% -> 100%; exp 0; żywych 0->maks 0, stykających maks 0.
- przeszedł 1 pól, zabił ok. 0 (wg exp).
- bot przed tym: stan WALKA, ostatnio: loot.

## 2026-10-11 16:29:17-16:29:18 (1 s) Karol gra (bot bez telemetrii); powód: ruch_bez_telemetrii_bota, gra_reczna_bot_cichy; HP 100% -> 100%; exp 0; żywych 0->maks 0, stykających maks 0.
- przeszedł 1 pól, zabił ok. 0 (wg exp).
- bot przed tym: stan WALKA.

## 2026-10-11 16:44:40-16:44:42 (1 s) Karol pomaga botowi; powód: zmiana_celu; HP 99% -> 100%; exp 5; żywych 4->maks 6, stykających maks 1.
- zaatakował Rat 20% zamiast celu bota (dobił uciekiniera).
- cofnął się o 6 pól od skupiska (bot tego nie robi).
- bot przed tym: stan WALKA, cel Rat 20% (odl 5), ostatnio: poscig_koniec.

## 2026-10-11 16:45:43-16:45:43 (1 s) Karol gra (bot bez telemetrii); powód: ruch_bez_telemetrii_bota, gra_reczna_bot_cichy; HP 100% -> 100%; exp 0; żywych 0->maks 0, stykających maks 0.
- przeszedł 1 pól, zabił ok. 0 (wg exp).
- bot przed tym: stan LOOT, ostatnio: loot.

## 2026-10-11 16:47:02-16:47:02 (1 s) Karol gra (bot bez telemetrii); powód: ruch_bez_telemetrii_bota, gra_reczna_bot_cichy; HP 100% -> 100%; exp 0; żywych 1->maks 1, stykających maks 0.
- przeszedł 1 pól, zabił ok. 0 (wg exp).
- bot przed tym: stan LOOT, ostatnio: loot.

## 2026-10-11 17:01:22-17:01:27 (5 s) Karol gra przy zatrzymanym bocie; powód: aktywnosc_przy_zatrzymanym_bocie; HP 100% -> 100%; exp 0; żywych 1->maks 1, stykających maks 1.


## 2026-10-11 17:06:20-17:06:36 (15 s) Karol gra (bot bez telemetrii); powód: ruch_bez_telemetrii_bota, gra_reczna_bot_cichy; HP 100% -> 100%; exp 0; żywych 0->maks 0, stykających maks 0.
- przeszedł 2 pól, zabił ok. 0 (wg exp).
- bot przed tym: stan LOOT, ostatnio: loot.

## 2026-10-11 17:23:00-17:23:01 (1 s) Karol gra (bot bez telemetrii); powód: ruch_bez_telemetrii_bota, gra_reczna_bot_cichy; HP 100% -> 100%; exp 0; żywych 0->maks 0, stykających maks 0.
- przeszedł 1 pól, zabił ok. 0 (wg exp).
- bot przed tym: stan WALKA, ostatnio: loot.

## 2026-10-11 17:27:19-17:27:25 (6 s) Karol gra przy zatrzymanym bocie; powód: stop_reczny, ruch_przy_zatrzymanym_bocie, aktywnosc_przy_zatrzymanym_bocie; HP 100% -> 100%; exp 0; żywych 0->maks 0, stykających maks 0.
- zatrzymał bota (STOP_RECZNY).
- przeszedł 4 pól, zabił ok. 0 (wg exp).

## 2026-10-11 17:35:36-17:35:37 (1 s) Karol gra przy zatrzymanym bocie; powód: ruch_przy_zatrzymanym_bocie, aktywnosc_przy_zatrzymanym_bocie; HP 100% -> 100%; exp 0; żywych 0->maks 0, stykających maks 0.
- przeszedł 1 pól, zabił ok. 0 (wg exp).

## 2026-10-11 17:54:37-17:54:39 (1 s) Karol pomaga botowi; powód: zmiana_celu; HP 100% -> 100%; exp 0; żywych 2->maks 2, stykających maks 2.
- zmienił cel z Rat 75% na Rat 100% (stykającego).
- zaatakował Rat 75% zamiast celu bota.
- bot przed tym: stan WALKA, cel Rat 100% (odl 1), ostatnio: poscig_koniec.

## 2026-10-11 18:06:47-18:06:49 (2 s) Karol pomaga botowi; powód: zmiana_celu; HP 100% -> 100%; exp 0; żywych 3->maks 3, stykających maks 2.
- zmienił cel z Rat 100% na Rat 100% (stykającego).
- zaatakował Rat 100% zamiast celu bota.
- bot przed tym: stan WALKA, cel Rat 100% (odl 1), ostatnio: poscig_koniec.

## 2026-10-11 18:08:17-18:08:22 (5 s) Karol gra przy zatrzymanym bocie; powód: aktywnosc_przy_zatrzymanym_bocie; HP 100% -> 100%; exp 0; żywych 1->maks 1, stykających maks 1.


## 2026-10-11 18:23:20-18:23:21 (1 s) Karol gra przy zatrzymanym bocie; powód: stop_reczny, ruch_przy_zatrzymanym_bocie, aktywnosc_przy_zatrzymanym_bocie; HP 100% -> 100%; exp 0; żywych 0->maks 0, stykających maks 0.
- zatrzymał bota (STOP_RECZNY).
- przeszedł 1 pól, zabił ok. 0 (wg exp).

## 2026-10-11 18:23:48-18:23:53 (6 s) Karol gra przy zatrzymanym bocie; powód: ruch_przy_zatrzymanym_bocie, aktywnosc_przy_zatrzymanym_bocie; HP 100% -> 100%; exp 0; żywych 0->maks 1, stykających maks 0.
- przeszedł 6 pól, zabił ok. 0 (wg exp).

## 2026-10-11 18:24:34-18:24:38 (4 s) Karol gra przy zatrzymanym bocie; powód: ruch_przy_zatrzymanym_bocie, aktywnosc_przy_zatrzymanym_bocie; HP 100% -> 100%; exp 0; żywych 0->maks 0, stykających maks 0.
- przeszedł 3 pól, zabił ok. 0 (wg exp).

## 2026-10-11 18:26:01-18:29:02 (181 s) Karol gra przy zatrzymanym bocie; powód: ruch_przy_zatrzymanym_bocie, aktywnosc_przy_zatrzymanym_bocie; HP 100% (min 97%) -> 100%; exp 45; żywych 0->maks 7, stykających maks 3.
- zmienił cel z Rat 45% na Rat 100% (stykającego).
- zmienił cel z Rat 25% na Rat 100% (najsłabszego stykającego).
- zmienił cel z Rat 5% na Rat 100%.
- zmienił cel z Rat 5% na Rat 100% (najsłabszego stykającego).
- uciekał o 16 pól od skupiska (bot tego nie robi).
- przeszedł 81 pól, zabił ok. 9 (wg exp).

## 2026-10-11 18:29:02-18:30:36 (94 s) Karol gra przy zatrzymanym bocie; powód: aktywnosc_przy_zatrzymanym_bocie, ruch_przy_zatrzymanym_bocie; HP 100% -> 100%; exp 5; żywych 1->maks 3, stykających maks 1.
- zmienił cel z Rat 40% na Rat 100%.
- zmienił cel z Rat 100% na Rat 100%.
- cofnął się o 7 pól od skupiska (bot tego nie robi).
- przeszedł 41 pól, zabił ok. 1 (wg exp).

## 2026-10-11 18:30:36-18:30:37 (1 s) Karol gra (bot bez telemetrii); powód: gra_reczna_bot_cichy; HP 100% -> 100%; exp 0; żywych 0->maks 0, stykających maks 0.
- bot przed tym: stan IDZ.

## 2026-10-11 18:30:37-18:30:41 (4 s) Karol gra (bot bez telemetrii); powód: gra_reczna_bot_cichy; HP 100% -> 100%; exp 0; żywych 0->maks 0, stykających maks 0.
- bot przed tym: stan IDZ.

## 2026-10-11 19:15:20-19:15:22 (2 s) Karol gra przy zatrzymanym bocie; powód: ruch_przy_zatrzymanym_bocie, aktywnosc_przy_zatrzymanym_bocie; HP 100% -> 100%; exp 0; żywych 1->maks 1, stykających maks 0.
- przeszedł 2 pól, zabił ok. 0 (wg exp).

## 2026-10-11 19:39:56-19:40:00 (4 s) Karol gra przy zatrzymanym bocie; powód: ruch_przy_zatrzymanym_bocie, aktywnosc_przy_zatrzymanym_bocie; HP 100% -> 100%; exp 0; żywych 0->maks 0, stykających maks 0.
- przeszedł 5 pól, zabił ok. 0 (wg exp).

## 2026-10-11 20:16:59-20:17:01 (1 s) Karol pomaga botowi; powód: zmiana_celu; HP 100% -> 100%; exp 5; żywych 1->maks 1, stykających maks 1.
- zaatakował Rat 100% zamiast celu bota.
- bot przed tym: stan WALKA, cel Rat 30% (odl 1), ostatnio: nowy cel Rat (hp 100%).

## 2026-10-11 20:21:48-20:23:53 (125 s) Karol gra przy zatrzymanym bocie; powód: stop_reczny, aktywnosc_przy_zatrzymanym_bocie, ruch_przy_zatrzymanym_bocie; HP 100% (min 99%) -> 100%; exp 10; żywych 1->maks 5, stykających maks 2.
- zmienił cel z Rat 20% na Rat 10% (uciekiniera).
- zmienił cel z Rat 10% (uciekinier) na Rat 100% (najsłabszego stykającego).
- uciekał o 18 pól od skupiska (bot tego nie robi).
- prawdopodobnie jadł (cap wzrósł bez lootu).
- zatrzymał bota (STOP_RECZNY).
- przeszedł 58 pól, zabił ok. 2 (wg exp).

## 2026-10-11 20:24:15-20:24:31 (16 s) Karol gra przy zatrzymanym bocie; powód: ruch_przy_zatrzymanym_bocie, aktywnosc_przy_zatrzymanym_bocie; HP 100% -> 100%; exp 0; żywych 0->maks 0, stykających maks 0.
- przeszedł 8 pól, zabił ok. 0 (wg exp).

## 2026-10-11 20:24:53-20:26:18 (85 s) Karol gra przy zatrzymanym bocie; powód: ruch_przy_zatrzymanym_bocie, aktywnosc_przy_zatrzymanym_bocie; HP 100% -> 100%; exp 0; żywych 0->maks 1, stykających maks 1.
- przeszedł 30 pól, zabił ok. 0 (wg exp).

## 2026-10-11 20:30:55-20:33:54 (179 s) Karol gra przy zatrzymanym bocie; powód: ruch_przy_zatrzymanym_bocie, aktywnosc_przy_zatrzymanym_bocie; HP 100% -> 100%; exp 20; żywych 0->maks 4, stykających maks 2.
- zmienił cel z Rat 5% na Rat 100% (najsłabszego stykającego).
- zmienił cel z Rat 20% na Rat 100% (stykającego).
- zmienił cel z Rat 25% na Rat 100% (najsłabszego stykającego).
- cofnął się o 3 pól od skupiska (bot tego nie robi).
- przeszedł 70 pól, zabił ok. 4 (wg exp).

## 2026-10-11 20:33:56-20:36:50 (174 s) Karol gra przy zatrzymanym bocie; powód: ruch_przy_zatrzymanym_bocie, aktywnosc_przy_zatrzymanym_bocie; HP 100% (min 99%) -> 100%; exp 35; żywych 0->maks 3, stykających maks 3.
- zmienił cel z Rat 40% na Rat 100% (najsłabszego stykającego).
- zmienił cel z Rat 10% na Rat 90% (najsłabszego stykającego).
- zmienił cel z Rat 15% na Rat 100% (najsłabszego stykającego).
- zmienił cel z Rat 15% na Rat 10% (uciekiniera).
- prawdopodobnie jadł (cap wzrósł bez lootu).
- przeszedł 65 pól, zabił ok. 7 (wg exp).

## 2026-10-11 20:36:57-20:39:58 (181 s) Karol gra przy zatrzymanym bocie; powód: ruch_przy_zatrzymanym_bocie, aktywnosc_przy_zatrzymanym_bocie; HP 100% (min 96%) -> 99%; exp 25; żywych 0->maks 4, stykających maks 4.
- zmienił cel z Rat 40% na Rat 100% (stykającego).
- zmienił cel z Rat 100% na Rat 100% (najsłabszego stykającego).
- zmienił cel z Rat 5% na Rat 100% (stykającego), przy 3 stykających.
- zmienił cel z Rat 25% na Rat 95% (najsłabszego stykającego).
- uciekał o 8 pól od skupiska (bot tego nie robi).
- prawdopodobnie jadł (cap wzrósł bez lootu).
- przeszedł 108 pól, zabił ok. 5 (wg exp).

## 2026-10-11 20:39:58-20:41:00 (62 s) Karol gra przy zatrzymanym bocie; powód: ruch_przy_zatrzymanym_bocie, aktywnosc_przy_zatrzymanym_bocie; HP 99% -> 100%; exp 25; żywych 0->maks 3, stykających maks 2.
- zmienił cel z Rat 10% na Rat 100%.
- zmienił cel z Rat 10% na Rat 65% (najsłabszego stykającego).
- zmienił cel z Rat 30% na Rat 100%.
- zmienił cel z Rat 15% na Rat 100% (najsłabszego stykającego).
- przeszedł 25 pól, zabił ok. 5 (wg exp).

## 2026-10-11 20:41:15-20:43:58 (163 s) Karol gra przy zatrzymanym bocie; powód: ruch_przy_zatrzymanym_bocie, aktywnosc_przy_zatrzymanym_bocie; HP 100% (min 98%) -> 100%; exp 15; żywych 0->maks 3, stykających maks 2.
- zmienił cel z Rat 55% na Rat 100%.
- zmienił cel z Rat 100% na Rat 20% (uciekiniera).
- zmienił cel z Rat 20% (uciekinier) na Rat 100% (stykającego).
- zmienił cel z Rat 25% na Rat 55% (najsłabszego stykającego).
- przeszedł 91 pól, zabił ok. 3 (wg exp).

