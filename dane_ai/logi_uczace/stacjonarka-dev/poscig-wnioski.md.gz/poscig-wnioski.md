## 2026-10-14 18:17 | uwaga | pościgów 5 min: 59, 30 min: 196
- Pięć wyjść 'brak_ruchu' w oknie długim to jeden klaster: gracz stoi na tym samym kaflu, a cel jest w zasięgu drogi. (pewność 0.55)
  dowód: 5 z 196 pościgów (2,6%) zakończyło się brak_ruchu; wszystkie na poz [32487,32300,9] w ciągu ~8 s, kroki=0, odl 2-3, droga=2, osiagalny=true, stan WALKA, hp_gracza 100, cel Troll hp 24. Okno krótkie: 0 brak_ruchu.
  skutek: Każdy taki pościg kończy się bez dobicia po czasie, a cel jest na wyciągnięcie. Strata 5 dobić w 30 min, zlokalizowana w jednym miejscu.
  propozycja: Funkcja kroku pościgu: sprawdzić, czy w stanie WALKA krok jest wstrzymywany (warunek blokujący ruch przy innym celu w pobliżu) albo czy ścieżka ignoruje kafle zajęte przez inne stwory. Kierunek: pościg powinien wybierać alternatywny krok lub wrócić do ścieżki, gdy pozycja się nie zmienia.
- Klawisz jest trzymany przez cały czas, a mimo to część naciśnięć następuje z postoju, bez zmiany pozycji. (pewność 0.4)
  dowód: trzymane_proc_czasu=100%, naciski_z_postoju=64 w 195 pościgach trzymaj (0,33 na pościg; okno krótkie: 16 na 59, 0,27). Bez postępu: 0 pościgów.
  skutek: Nie wiadomo, czy te naciśnięcia tracą czas (gra ich nie przyjmuje) czy są zbędnym powtórzeniem. Przy 0 pościgów bez postępu nie widać bezpośredniego kosztu w wyniku.
  propozycja: Funkcja wysyłania ruchu trzymaj: sprawdzić warunek ponownego naciśnięcia (czy pozycja zmieniła się od ostatniego naciśnięcia) i stałą czasu między naciśnięciami. Kierunek: naciśnięcie z postoju powinno być ponawiane tylko po potwierdzeniu braku zmiany pozycji.
- Utknięcia pojawiają się w ciasnych miejscach z kilkoma stworami (Jointoramix + Troll), gdzie pole ma niską prędkość. (pewność 0.3)
  dowód: 4 utknięcia w oknie długim (3 w stanie WALKA, 1 w IDZ); stwory obok gracza przy każdym: Jointoramix (0) i Troll (1-3); pole v 12-16, krok_s 0,56-0,75. Mediana kroków na s w trzymaj 1,95, p10 1,35.
  skutek: Pościg trwa dłużej przy wolnym kroku, co zwiększa ryzyko, że cel ucieknie lub zostanie zgubiony w tłoku.
  propozycja: Funkcja wyboru kroku/ścieżki pościgu: uwzględnić inne stwory jako przeszkody kosztowne. Kierunek: omijanie zajętych kafli zamiast czekania na wolny.
- Pościg w większości działa poprawnie: dobicia są normą, a dystans spada. (pewność 0.8)
  dowód: Okno krótkie: dobicie 59/59 (100%), zgubienie 0, odległość start med 2 -> koniec med 1; oscylacje 0. Okno długie: dobicie 188/196 (96%), zgubienie 0, oscylacje 0.
  skutek: Brak strat poza 8 niedobiciami w oknie długim (5 brak_ruchu, 3 przerwane_inne).
  propozycja: Brak zmiany wymagana; monitorować klaster brak_ruchu i przerwane_inne.
- do zmierzenia: Czy na kaflu [32487,32300,9] inny stwór (Troll) faktycznie blokował krok w chwili naciśnięć: zapisać zajętość sąsiednich kafli przy każdym brak_ruchu.
- do zmierzenia: Czy naciśnięcia z postoju powodują zmianę pozycji z opóźnieniem: logować czas naciśnięcia i czas zmiany pozycji, żeby odróżnić 'gra nie przyjęła' od 'przyjęła z opóźnieniem'.
- do zmierzenia: Co oznacza 'ponow_brak' (10 w oknie długim) i czy odpowiada za część naciśnięć z postoju.
- do zmierzenia: Jaka jest przyczyna 3 wyjść 'przerwane_inne' (nie zapisano powodu): dodać nazwę powodu do logu.
- do zmierzenia: Czy pole 'pole v' to prędkość pola, a 'krok_s' czas na krok: potwierdzić definicję, bo wpływa na interpretację utknięć.

## 2026-10-14 18:19 | uwaga | pościgów 5 min: 87, 30 min: 250
- Pięć wyjść brak_ruchu skupia się w jednym miejscu i czasie: postać stoi na tym samym polu przy Trollu, mimo że ścieżka jest osiągalna. (pewność 0.5)
  dowód: najgorsze_poscigi: 5 wpisów w 18:01:21–18:01:29, poz [32487,32300,9], kroki 0, czas 1.74–1.82 s, odl [2–3], droga 2, osiagalny true, stan WALKA, hp_gracza 100; utkniecia: wpis 18:01:07 przy poz [32485,32298,9] z dwoma Trollami
  skutek: 5 z 250 pościgów (2%) nie doszło do celu w tym miejscu; czas pętli przepadł, a Troll (hp 24) nie został dobity w tych próbach
  propozycja: Sprawdzić funkcję osiągalności ścieżki: czy traktuje pola zajęte przez inne stwory (Trolle w sąsiedztwie) jako wolne. Kierunek: pola zajęte przez stwory powinny być uznawane za zablokowane albo omijane. Rozważyć też, czy stała progu brak_ruchu (~1.7–1.8 s) nie jest za krótka w stanie WALKA.
- Trzy przerwania (zawracanie 2, gryzący 1) nie mają w danych wyjaśnionej przyczyny. (pewność 0.35)
  dowód: koniec: przerwane_inne 3; powody_wyjsc: zawracanie 2, gryzacy 1; w oknie krótkim 0 nieudanych (dobicie 87/87)
  skutek: 3 z 250 dobić (1,2%) utraconych bez diagnozy; razem z brak_ruchu 8 nie-dobić (3,2%) w oknie długim
  propozycja: Dopisać do logu szczegóły zawracania i gryzienia (który stwór, dystans). Nie zmieniać progów, dopóki przyczyna nie jest znana.
- Tryb stuk nie da się ocenić: użyty raz, odrzucony i bez kroków, więc brak porównania trzymaj vs stuk. (pewność 0.6)
  dowód: okno_dlugie stuk: n=1, odrzucone_proc 100, kroki 0, ponow_brak 1; okno_krotkie: brak stuk; roznice_trybow: uwaga 'mało pościgów na tryb'
  skutek: brak podstaw, czy stuk działa gorzej; n<5, więc pewność niska
  propozycja: Ustalić w kodzie funkcję wyboru trybu trzymaj/stuk i warunki, przy których stuk jest wybierany. Nie zmieniać logiki na podstawie jednej próby.
- Zmiany kierunku na krok wzrosły w oknie długim przy niemal niezmienionym tempie; prawdopodobnie to efekt walk z kilkoma stworami. (pewność 0.4)
  dowód: zmiany_kierunku_na_krok 0.18 (krótkie) vs 0.30 (długie); kroki_na_s med 1.76 vs 1.80; lat_med_s 0.5 vs 0.435; 3 z 4 utknięć w stanie WALKA z 2–3 stworami
  skutek: więcej zbędnych zmian kierunku, ale dobicia nadal 97%; w danych nie widać kosztu w tempie
  propozycja: Nic nie zmieniać. Rozbić zmiany_kierunku na stany IDZ vs WALKA, żeby potwierdzić przyczynę.
- Pościg ogólnie działa: dobicia są prawie wszystkie, zgubień nie ma, oscylacji i braku postępu też nie. (pewność 0.85)
  dowód: krótkie: dobicie 87/87 (100%), zgubienie 0; długie: dobicie 242/250 (97%), zgubienie 0, oscylacje 0, bez_postepu 0 pościgów
  skutek: brak istotnego kosztu; ryzyko skupia się w jednym klastrze i kilku przerwaniach
  propozycja: Brak zmiany do wykonania.
- do zmierzenia: Czy w chwili brak_ruchu w okolicy poz [32485–32487, 32298–32300] (piętro 9) sąsiednie pola są zajęte przez Trolle? Zapisać zajętość 8 sąsiednich pól przy każdym brak_ruchu.
- do zmierzenia: Jaki jest rozkład czasu do wyjścia brak_ruchu, i czy po ponowieniu pościg kończy się dobiciem?
- do zmierzenia: Czy przerwania zawracanie i gryzacy mają wspólne położenie lub stwory w pobliżu?
- do zmierzenia: Ile razy w ogóle wybrano tryb stuk i jakie warunki to wywołały?
- do zmierzenia: Podział zmian_kierunku na stany IDZ vs WALKA, żeby sprawdzić, czy wzrost 0.18→0.30 wynika z walk.

## 2026-10-14 18:21 | uwaga | pościgów 5 min: 73, 30 min: 268
- Pięć pościgów utknęło w jednym miejscu, przy stoczonej walce z Jointoramixem (dystans 0), mimo osiągalnej drogi do celu. (pewność 0.55)
  dowód: Najgorsze_poscigi: 5/5 z kroki=0, ta sama pozycja [32487,32300,9], odl celu 2-3, droga=2, osiagalny=true, hp_gracza=100, stan=WALKA, w oknie 18:01:21-18:01:29. Wszystkie 5 utknięć w oknie długim ma Jointoramixa w dystansie 0.
  skutek: 5 z 268 pościgów (ok. 2%) skończyło się brak_ruchu zamiast dobiciem. To główna różnica między 97% dobić a 100%.
  propozycja: Funkcja wyboru akcji w stanie WALKA: warunek priorytetu walki nad ruchem w pościgu. Rozważyć, czy przy stworze w dystansie 0 i osiągalnej drodze do celu w dystansie 2-3 ruch do celu powinien mieć pierwszeństwo.
- Tempo pościgu jest zgodne z fizycznym limitem prędkości pola, a nie z trzymaniem klawisza. (pewność 0.7)
  dowód: Okno długie: kroki_na_s med=1.79 ≈ 1/0.56 s (pole v=12); p10=1.35 ≈ 1/0.75 s (pole v=16). Krok_s w danych to v*0.047, więc obserwowane wartości pasują do sufitu pola.
  skutek: Brak dowodu na to, że logika pościgu spowalnia postać. Zmiany tempa nie są tu uzasadnione.
  propozycja: Brak zmiany w kodzie tempa. Można dopisać do logu krok_s dla każdego kroku, aby ten wniosek był bezpośrednio sprawdzalny.
- Naciski klawisza z postoju (klawisz trzymany, brak kroku) są częste, ale większość nie wiąże się z utknięciami. (pewność 0.35)
  dowód: Okno długie: naciski_z_postoju=83 (0.31 na pościg), trzymane_proc=98%; tylko 5 przypadków brak_ruchu. Okno krótkie: 20 naciśków z postoju przy 73 pościgach.
  skutek: Możliwe marnowanie czasu klawisza lub wysyłanie poleceń w trakcie blokady. Brak strat dobić (97%), więc koszt nieudowodniony.
  propozycja: Funkcja zwalniania klawisza trzymanego: stała czasu bez zmiany pozycji, po której klawisz jest puszczany. Do rozważenia, czy ma działać tylko przy blokadzie przez stwór.
- Wniosek o wzroście zmian kierunku w oknie długim nie jest poparty tymi liczbami; zmiany wyglądają na korekty ścieżki, a nie cofanie. (pewność 0.5)
  dowód: zmiany_kierunku_na_krok: okno krótkie 0.34, długie 0.31 (spadek). oscylacje.liczba=0 w obu oknach.
  skutek: Poprzedni wniosek jest niezgodny z danymi; nie ma dowodu na problem z kierunkiem.
  propozycja: Rozróżnić w liczeniu zmiany_kierunku prawdziwe zawrócenie od korekty po przekątnej (funkcja liczenia zmian kierunku w logu).
- do zmierzenia: Czy 5 przypadków brak_ruchu to jeden epizod walki (18:01:21-18:01:29)? Zmierzyć dystans i stan każdego stwora w klatkach przed każdym ruchem.
- do zmierzenia: Czy naciski_z_postoju korelują z obecnością stwora w dystansie 0 lub z blokadą drogi?
- do zmierzenia: Niespójność: epizody_celu.zgubione=1 w obu oknach, a koniec.zgubienie=0. Sprawdzić, czy to inna definicja (epizod celu vs pościg) i ujednolicić.
- do zmierzenia: Czy tryb stuk jest odrzucany przez decyzję trybu, czy przez brak kroków? Obecnie n=1 (okno długie), więc nie da się ocenić.
- do zmierzenia: Czy utknięcia w polach v=12 i v=16 różnią się częstością? Obecnie 3 z 5 przy v=12 i 2 z 5 przy v=16, n=5, pewność niska.

## 2026-10-14 18:26 | uwaga | pościgów 5 min: 71, 30 min: 325
- Niemal wszystkie pościgi kończą się dobiciem, ale 5 nieudanych prób ma jedną wspólną lokalizację i ten sam wzorzec: brak ruchu bez kroków. (pewność 0.6)
  dowód: okno_dlugie: koniec.dobicie 317/325 (98%), zgubienie 0, bez_dojscia 5 (powod brak_ruchu 5). Wszystkie 5 z najgorsze_poscigi ma poz [32487,32300,9], cel Troll hp 24, kroki 0, hp_gracza 100, droga 2, osiagalny true, w przedziale 18:01:21–18:01:29. Utkniecie o 18
  skutek: Około 1,5% pościgów (5/325) kończy się bez dobicia, a wszystkie w jednym miejscu i w ciągu około 8 s. Każda próba zużywa czas cyklu bez postępu.
  propozycja: Funkcja wykrywania 'brak_ruchu' (i powód 'bez_dojscia'): rozważyć, czy po stwierdzeniu droga=2 i osiagalny=true z 0 krokami bot powinien przeliczyć ścieżkę z uwzględnieniem zajętych pól, zamiast ponawiać ten sam ruch. Nazwa stałej progu czasu bez ruchu nieznana w danych, do ustalenia w kodzie.
- Tryb 'stuk' ma tylko jeden pościg w danych, który został odrzucony, więc nie da się ocenić jego skuteczności. (pewność 0.2)
  dowód: roznice_trybow: stuk n=1, wyslane 1, odrzucone 1 (100%), kroki_na_s_ogolem 0.0. Trzymaj ma n=324 i odrzucone 0.
  skutek: Brak podstaw, by ocenić, czy stuk zawodzi systematycznie, czy to przypadek; 1 próba to za mało.
  propozycja: Funkcja wyboru trybu (trzymaj/stuk): zebrać więcej pościgów w trybie stuk przed jakąkolwiek zmianą. Na razie bez zmiany w kodzie.
- Zmiany kierunku na krok nie rosną w oknie długim; wcześniejsza teza o wzroście nie ma pokrycia w liczbach. (pewność 0.5)
  dowód: zmiany_kierunku_na_krok: okno krótkie 0.41, okno długie 0.31 (trzymaj). Odrzucone 0 w obu oknach.
  skutek: Brak wykazanego kosztu. Obecne dane nie uzasadniają zmiany ścieżki pod kątem zmian kierunku.
  propozycja: Brak zmiany w kodzie. Wniosek do odłożenia, dopóki nie pojawi się nowa przesłanka.
- Naciski klawisza z postoju są częste, ale nie wiążą się z utknięciami w tym samym stopniu, więc nie są główną przyczyną nieudanych pościgów. (pewność 0.5)
  dowód: okno_dlugie: naciski_z_postoju 88 (0.27 na pościg), brak_ruchu 5. okno_krotkie: naciski 6 (0.08 na pościg), brak_ruchu 0. Trzymane 98% czasu.
  skutek: Naciski z postoju kosztują czas, ale 88 przypadków nie dało więcej niż 5 porażek, więc ten koszt nie wydaje się główną przyczyną.
  propozycja: Funkcja obsługi klawisza trzymanego (wywołanie naciśnięcia przy postoju): nie zmieniać na podstawie tych danych; ewentualnie sprawdzić, czy naciski z postoju poprzedzają 5 przypadków brak_ruchu.
- Utknięcia (6 w oknie długim, 1 w krótkim) występują podczas walki z wieloma stworami, a nie podczas swobodnego biegu. (pewność 0.4)
  dowód: utkniecia długie: 6 zdarzeń, wszystkie stan WALKA poza jednym IDZ; wszystkie zawierają Jointoramix(0), 5 z nich dodatkowo Trolla (1–3 sztuki). Pole v 12–16, krok_s 0.56–0.75.
  skutek: Pościg wchodzi w dłuższą walkę z obstrukcją; liczba utknięć jest mała w stosunku do 325 pościgów, ale wskazuje na konkretny scenariusz.
  propozycja: Funkcja przejścia w stan WALKA przy obecności wielu stworów na ścieżce: opisać, czy pościg powinien być przerywany lub przeliczany, gdy w pobliżu stoi więcej niż jeden stwór.
- do zmierzenia: Czy pole na ścieżce (droga=2) jest zajęte przez inny stwór w momentach brak_ruchu w okolicy [32487,32300,9]? Zarejestrować zajętość kolejnych pól przy każdym brak_ruchu.
- do zmierzenia: Dlaczego kroki_na_s (med 1.8) są tak wyższe niż krok_s pola w utknięciach (0.56–0.75)? Ustalić, czy to inne jednostki pomiaru, i czy pole krok_s faktycznie ogranicza tempo.
- do zmierzenia: Czy zgubienie=1 w epizodach celu (okno długie) ma odpowiednik w poziomie pościgów (koniec.zgubienie=0)? Sprawdzić, czy te liczniki liczą to samo zdarzenie.
- do zmierzenia: Czy tryb stuk jest w ogóle wybierany poza jednym przypadkiem? Zebrać więcej pościgów stuk, zanim oceni się jego skuteczność.
- do zmierzenia: Czy naciski z postoju poprzedzają brak_ruchu? Zmierzyć odstęp czasu między naciśnięciem z postoju a pierwszym krokiem w zdarzeniach brak_ruchu.

## 2026-10-14 18:28 | ok | pościgów 5 min: 66, 30 min: 342
- Wszystkie 5 przypadków brak_ruchu (bez dojścia) w oknie długim to jeden epizod ok. 8 s w jednym punkcie, a nie problem systemowy. (pewność 0.5)
  dowód: 5 najgorszych pościgów z powodem brak_ruchu ma poz [32487,32300,9], czas 1.74–1.82 s, kroki 0, hp_gracza 100, stan WALKA, droga 2, osiagalny true, godz. 18:01:21–18:01:29. Koniec brak_ruchu=5 w oknie długim = dokładnie te 5 wpisów.
  skutek: 5 z 342 pościgów (1,5%) bez dojścia, koszt ok. 8 s czasu w jednym miejscu; w oknie krótkim brak takich przypadków.
  propozycja: Sprawdzić funkcję wyboru stanu (WALKA vs POŚCIG): czy stan WALKA wstrzymuje wykonanie kroku pościgu, gdy droga do celu jest osiągalna (droga<=2). Do rozważenia przez człowieka: warunek priorytetu WALKA nad POŚCIGIEM w tej funkcji.
- Wynik 100% odrzuconych dla trybu stuk nie jest miarą trybu, bo pochodzi z jednego pościgu. (pewność 0.85)
  dowód: stuk: n=1 w oknie długim, odrzucone=1, kroki=0, czas 1.82 s; ten sam epizod co brak_ruchu w najgorszych pościgach (18:01:21). W oknie krótkim stuk n=0.
  skutek: Brak porównania trybów trzymaj vs stuk; ryzyko błędnej decyzji, jeśli ktoś oprze się na tej liczbie. Próba n=1, niska pewność.
  propozycja: Nie zmieniać kodu na podstawie tej statystyki. Zebrać więcej pościgów w trybie stuk (min. n>=5) zanim wyciągnie się wniosek o trybie.
- Utknięcia pojawiają się prawie wyłącznie przy walce z Trollem w wąskim obszarze i rzadko (1,8% pościgów). (pewność 0.4)
  dowód: Okno długie: 6 utknięć, 5 w stanie WALKA z Trollem w stwory; 1 w IDZ (17:58:26) tylko z Jointoramix. Współrzędne x 32479–32508, y 32272–32300, z 8–9. Okno krótkie: 1 utknięcie (18:23:11) w tym samym obszarze. pole.krok_s w utknięciach 0.56–0.75.
  skutek: Około 1,8% pościgów traci czas w jednym obszarze; koszt ograniczony, ale powtarzalny.
  propozycja: Sprawdzić funkcję wykrywania utknięcia i sposób liczenia pole.krok_s: czy niskie wartości wynikają z zajętych kafelków przez inne potwory na trasie. Do rozważenia: uwzględnienie zajętości kafelków w funkcji wyboru kroku.
- Liczba zgubień w statystykach pościgów (0) nie zgadza się z liczbą zgubień w statystykach epizodów (1). (pewność 0.6)
  dowód: okno_dlugie: koniec.zgubienie=0, zgubienie_proc=0; epizody_celu.zgubione=1, wskaznik=98, powod_top 'zniknął z widoku żywy'. niespojnosci=[] mimo różnicy.
  skutek: Możliwe zaniżenie liczby zgubień w raporcie pościgów; ocena skuteczności może być zbyt optymistyczna.
  propozycja: Ujednolicić definicję zgubienia w funkcji liczącej statystyki (pościg vs epizod celu), tak by oba raporty liczyły to samo zdarzenie.
- Cztery pościgi (w oknie długim) zakończyły się z powodem przerwane_inne, którego nie da się zaklasyfikować z danych. (pewność 0.5)
  dowód: okno_dlugie koniec.przerwane_inne=4 (1 w krótkim); powody_wyjsc nie mają kategorii dla tych przypadków.
  skutek: Nieznany udział w nieudanych pościgach (4/342, ok. 1,2%).
  propozycja: Dodać rozróżnienie przyczyn w funkcji kończącej pościg, tak by przerwane_inne miało konkretny powód.
- do zmierzenia: Co w stanie WALKA blokuje krok pościgu w punkcie [32487,32300,9] w godz. 18:01:21–18:01:29: zapis decyzji stanu i zajętość kafelków na trasie w tych sekundach.
- do zmierzenia: Jaki powód kryje się pod przerwane_inne (4 przypadki): zapisać przyczynę zakończenia przy każdym pościgu.
- do zmierzenia: Czy niskie pole.krok_s w utknięciach wynika z blokady przez innego potwora (liczyć zajęte kafelki na trasie w chwili utknięcia) i czy ta miara jest tą samą co kroki_na_s.
- do zmierzenia: Czy epizod 'zniknął z widoku żywy' to pościg zgubiony (wtedy przypisać go do zgubienie) czy inny przypadek: sprawdzić logi tego epizodu.
- do zmierzenia: Próbka trybu stuk w tych samych warunkach co trzymaj (n>=5), żeby porównać odrzucone i kroki_na_s.

## 2026-10-14 18:30 | uwaga | pościgów 5 min: 27, 30 min: 318
- Pościgi bez dojścia (brak_ruchu, utknięcia) skupiają się przy walce z Trollem w wąskim polu, zwykle na tej samej pozycji. (pewność 0.55)
  dowód: Okno długie: 11 bez_dojscia (3,5% z 318 pościgów), utkniecia=6, wszystkie w stanie WALKA z Trollem, pole v 12-16. Najgorsze pościgi: 3 wpisy brak_ruchu z kroki=0 na tej samej pozycji [32487,32300,9] w ciągu 6 s, odległość 2-3, osiagalny=true.
  skutek: Około 3,5% pościgów kończy się bez dobicia, a w tych przypadkach cel jest osiągalny, więc strata to czas i możliwe zgubienia, a nie brak drogi.
  propozycja: Funkcja ponawiania ruchu po ponow_brak (obsługa zajętego pola): rozważyć, czy przy zajętym polu przez inny potwór przelicza trasę zamiast ponawiać ten sam krok; kierunek: wcześniejsze wybranie alternatywnego pola obok Trolla.
- Trzymanie klawisza często generuje naciśnięcia z postoju i zmiany kierunku, co może oznaczać, że postać najpierw obraca się, a dopiero potem idzie. (pewność 0.35)
  dowód: Okno długie, trzymaj: naciski_z_postoju=98 przy 317 pościgach (0,31 na pościg), zmiany_kierunku_na_krok=0,34, trzymane_proc_czasu=90. Okno krótkie: 19 naciśnięć z postoju przy 27 pościgach.
  skutek: Część naciśnięć nie daje przesunięcia; nie wiadomo, ile czasu to kosztuje, bo kroki_na_s_ogolem (1,7) jest zbliżone do mediany (1,8).
  propozycja: Funkcja wysyłania kierunku trzymania klawisza: sprawdzić, czy zmiana kierunku wysyła dodatkowy impuls bez zmiany pozycji; kierunek: uniknąć wysyłania nowego kierunku, gdy poprzedni nie został jeszcze wykonany.
- Liczba zgubień jest rozbieżna między statystykami pościgów a epizodów celu w tym samym oknie. (pewność 0.6)
  dowód: Okno długie: koniec.zgubienie=0 (zgubienie_proc=0), ale epizody_celu.zgubione=1, powod_top 'zniknął z widoku żywy'. Okno krótkie: 0 zgubień w obu, więc rozjazd dotyczy tylko długiego okna.
  skutek: Jedno zgubienie jest w danych epizodów, ale nie w pościgach, więc wskaźnik skuteczności może być zawyżony o ok. 0,3 punktu procentowego.
  propozycja: Funkcja zapisu wyniku pościgu i funkcja zapisu epizodu celu: sprawdzić, czy oba zapisy korzystają z tego samego powodu wyjścia; kierunek: jedno źródło prawdy dla zgubienia.
- Tryb stuk ma tylko jedną próbę, więc porównanie trzymaj vs stuk nie jest możliwe. (pewność 0.2)
  dowód: Okno długie, stuk: n=1, odrzucone_proc=100, kroki=0; roznice_trybow.uwaga: 'mało pościgów na tryb'.
  skutek: Nie można ocenić, czy stuk działa gorzej, czy to przypadek.
  propozycja: Brak zmiany w kodzie na podstawie tych danych; najpierw zebrać więcej próbek stuk.
- do zmierzenia: Czy brak_ruchu przy Trollu wiąże się z zajęciem następnego pola przez inny potwór: zapisywać stwory na 8 polach wokół gracza w momencie każdego brak_ruchu.
- do zmierzenia: Czy lat_med=0,5 s (opóźnienie między wysłaniem a ruchem) różni się między pościgami z zmianą kierunku a bez niej.
- do zmierzenia: Jakie są powody przerwane_inne: zapisać stan gry i ostatnią akcję dla każdego z 4 przypadków.
- do zmierzenia: Ile naciśnięć z postoju zamienia się w faktyczny krok w ciągu 0,5 s po zmianie kierunku.
- do zmierzenia: Czy tryb stuk daje odrzucone_proc porównywalne z trzymaj przy co najmniej 5 pościgach na tryb w tym samym oknie.

## 2026-10-14 18:32 | uwaga | pościgów 5 min: 31, 30 min: 303
- Wszystkie 6 pościgów zakończonych brak_ruchu wystąpiło w ostatnich 5 minutach, w jednym skupisku przy ~18:29, przy celu Troll (hp 14) i stanie WALKA; to one obniżają dobicia w krótkim oknie. (pewność 0.6)
  dowód: okno_krotkie: brak_ruchu=6 z 31 (19%), dobicie_proc=77; okno_dlugie: brak_ruchu=6 z 303 (2%), dobicie_proc=97; najgorsze_poscigi: 5/5 to brak_ruchu, stan WALKA, kroki 0 (lub 7), czas ~1.6 s, osiagalny=true, droga 3-8, hp_gracza 100.
  skutek: W ostatnich 5 min 7 z 31 pościgów (23%) nie kończy się dobiciem; cel w zasięgu (odl 4-5) nie jest gonony, a postać nie ginie, więc to czysta strata dobić.
  propozycja: Sprawdzić w kodzie, czy gałąź ruchu pościgu jest tłumiona lub nadpisywana, gdy stan == WALKA (priorytet walki nad ruchem w pętli cavebota). Oraz zbadać stałą progu czasu brak_ruchu (obecnie ok. 1.6 s) pod kątem zbyt wczesnego wyzwalania przy trwającej walce.
- Prawdopodobną przyczyną utknięć jest zajęte przez inny potwór pole na drodze, którego pościg nie omija; Jointoramix obecny we wszystkich utknięciach z WALKA. (pewność 0.4)
  dowód: utkniecia (okno długie) 5/5 zawiera Jointoramix (indeks 0) i stan WALKA, pole v 12-16, krok_s 0.56-0.75; okno krótkie 1/1 też Jointoramix; droga do celu 3-8 kroków, a kroki 0. Wiadomo tylko, że Jointoramix występuje razem z utknięciami, nie że blokuje ścieżkę.
  skutek: Pościg stoi zamiast podejść do celu, co zwiększa czas do dobicia i ryzyko zgubienia celu w otwartej walce.
  propozycja: Funkcja wyznaczania ścieżki pościgu: traktować pola zajęte przez inne potwory jako przeszkody i przeliczać trasę zamiast czekać. Do rozważenia przez człowieka po potwierdzeniu, że to blokada, a nie stan walki.
- W ostatnich 5 min pogorszyły się wskaźniki płynności ruchu (trzymane_proc, naciski z postoju, zmiany kierunku, kroki/s), co jest prawdopodobnie efektem utknięć, ale nie wykluczam innej przyczyny. (pewność 0.35)
  dowód: trzymane_proc 66 vs 88; naciski_z_postoju_na_poscig 0.74 vs 0.29; zmiany_kierunku_na_krok 0.38 vs 0.31; kroki_na_s_ogolem 1.41 vs 1.81; p10 kroki/s 1.21 vs 1.33. Latencja stabilna (lat_med 0.495 vs 0.487 s, dec_med ~0).
  skutek: Więcej naciśnięć z postoju i mniej czasu w trybie trzymaj; koszt w czasie pościgu, bez wpływu na zgubienia.
  propozycja: Sprawdzić, czy po wyjściu z brak_ruchu start następnego pościgu wykonuje naciśnięcie z postoju (funkcja inicjacji ruchu/trzymania klawisza). Wynik zależy od próby n=31, więc traktować jako wskazówkę.
- Liczba zgubień jest rozbieżna między statystykami pościgów a epizodami celu w oknie długim, a dodatkowo przerwane_inne nie zgadza się z ostatnimi wnioskami. (pewność 0.5)
  dowód: okno_dlugie koniec.zgubienie=0 i zgubienie_proc=0, ale epizody_celu.zgubione=1 (powod_top 'zniknął z widoku żywy'); przerwane_inne=2 w oknie długim, a poprzednie wnioski mówiły o czterech.
  skutek: Może być niedoliczone zgubienie celu, co zawyża wskaźnik dobić; obecnie nie da się tego rozstrzygnąć z danych.
  propozycja: Sprawdzić, która ścieżka kodu zapisuje powód zgubienie w pościgu, a która w epizodzie celu, i czy oba liczniki liczą to samo zdarzenie.
- do zmierzenia: Czy stan WALKA rzeczywiście wstrzymuje krok pościgu: zalogować decyzję ruchu z flagą stanu przy każdym brak_ruchu i porównać z pościgami bez WALKA.
- do zmierzenia: Czy Jointoramix (indeks 0 w danych, znaczenie nieznane) zajmuje pole na ścieżce: zalogować zajętość pola przed pierwszym krokiem w utknięciach.
- do zmierzenia: Czy zgubienie jest niedoliczone: zestawić identyfikatory pościgów z epizodami zakończonymi zniknął z widoku żywy w tym samym oknie czasowym.
- do zmierzenia: Porównanie trzymaj vs stuk jest niemożliwe, bo w danych nie ma żadnego pościgu w trybie stuk; sprawdzić, czy tryb stuk jest w ogóle wybierany w tej konfiguracji.
- do zmierzenia: Czy skupisko z 18:29 (Troll hp 14) to jednorazowy incydent czy powtarzalny wzorzec przy tej samej lokalizacji: zebrać dane z kolejnych sesji w tym samym miejscu.

## 2026-10-14 18:34 | uwaga | pościgów 5 min: 33, 30 min: 308
- Większość utraconych dobić to jeden klaster 6 pościgów 'brak_ruchu' w ciągu ok. 14 s (18:29:41–18:29:55), w trybie trzymaj, przy osiągalnej ścieżce; postać nie przesuwa się mimo trzymanego klawisza. (pewność 0.6)
  dowód: okno_krotkie: brak_ruchu=6 (wszystkie 6 w klastrze), dobicie_proc 82; okno_dlugie: brak_ruchu=6, dobicie_proc 98 (301/308). Najgorsze pościgi: 5 wpisów Troll, hp_celu 14, kroki 0–7, zmiany_kier 0–2, osiagalny=true, droga 3–8, pozycje [32504,32270] i [32498,322
  skutek: Około 2% pościgów (6/308) kończy się bez dobicia, a w oknie krótkim spadek dobić do 82% wynika wyłącznie z tego klastra; cel nie ginie, ale czas pościgu rośnie bez postępu.
  propozycja: Sprawdzić w kodzie, jak wykrywany jest 'brak_ruchu' (stała progu czasu bez zmiany pozycji) oraz czy funkcja wyznaczania drogi nie zwraca ścieżki prowadzącej przez pole, którego gracz nie może zająć; do rozważenia: stała progu brak_ruchu i funkcja drogi.
- Utknięcia (5 unikalnych zdarzeń w oknie długim, to samo zdarzenie 18:29 widoczne w oknie krótkim) powtarzają się w kilku stałych miejscach, a we wszystkich obecny jest stwór Jointoramix. (pewność 0.4)
  dowód: Pozycje utknięć: [32508,32278] 18:05, [32482,32293] 18:11, [32484,32293] 18:20, [32484,32297] 18:23, [32498,32269] 18:29; Jointoramix w 6/6 wpisach utkniecia. Łączny czas utknięć 18+22+20+21+21 = 102 s z 1800 s (≈5,7%). Pole v 12–16 i krok_s 0.56–0.75 w każdym
  skutek: Około 5–6% okna długiego gracz stoi w miejscach, gdzie pościg się zatrzymuje; wzorzec wskazuje na przeszkodę na trasie (np. zajęte pole), a nie na losowe opóźnienia.
  propozycja: Przy wyznaczaniu kroku pościgu uwzględnić pola zajęte przez inne stwory (np. funkcja wyboru następnego pola/omijania), zamiast trzymać kierunek na zajęte pole; nazwa funkcji do ustalenia przez człowieka w kodzie cavebota.
- Krótkie okno wygląda gorzej w płynności ruchu (trzymane_proc 53 vs 87, naciski z postoju na pościg 0.55 vs 0.28, kroki/s ogółem 1.17 vs 1.84), ale pogorszenie koncentruje się w tym samym klastrze i w ponawianiu wysyłek. (pewność 0.5)
  dowód: okno_krotkie: naciski_z_postoju=18, ponow_brak=7 przy wyslane=28 (25%); okno_dlugie: ponow_brak=14 przy wyslane=145 (10%). Klaster 6 pościgów z kroki 0–7 odpowiada za większość 'naciski_z_postoju'.
  skutek: Wskaźniki płynności w oknie krótkim nie opisują typowego pościgu; ich ocena jako trendu jest myląca, bo próba to 33 pościgi z jednym incydentem.
  propozycja: Przed wnioskiem o trendzie porównać kilka kolejnych okien krótkich; ewentualnie sprawdzić funkcję ponawiania (ponow_brak) pod kątem zachowania przy zablokowanym polu.
- Liczenie zgubień jest niespójne między blokami danych: epizody celu raportują 1 zgubienie w oknie długim, a koniec pościgów podaje 0. (pewność 0.7)
  dowód: okno_dlugie: epizody_celu.zgubione=1 (powod_top 'zniknął z widoku żywy'), koniec.zgubienie=0, zgubienie_proc=0, powody_wyjsc bez 'zgubienie'. Natomiast przerwane_inne=1 odpowiada powodowi 'gryzacy'=1 i jest spójne.
  skutek: Nie da się jednoznacznie określić wskaźnika zgubień (0 czy 1 z 45 epizodów); zmienia to ocenę 'bez zgubień' w raporcie.
  propozycja: Ujednolicić definicję 'zgubienia' między liczeniem pościgów a liczeniem epizodów celu (jedna funkcja/stała klasyfikująca wyjście), do decyzji człowieka.
- do zmierzenia: Czy pole następnego kroku w klastrze 18:29 jest zajęte przez Jointoramix lub Trolla: zapisać pozycję stworów i pole kroku przy każdym kroku pościgu, który kończy się brak_ruchu.
- do zmierzenia: Znaczenie drugiego elementu w stwory [nazwa, liczba] (0 przy Jointoramix): odległość, stan czy status? Bez tego nie wiadomo, czy Jointoramix stoi na trasie.
- do zmierzenia: Czy pole v=12–16 jest typowe także dla udanych pościgów: zebrać rozkład pole.v i krok_s dla dobić, żeby sprawdzić, czy to cecha terenu czy przyczyna utknięć.
- do zmierzenia: Dlaczego hp Trolla pozostaje 14 przez cały klaster (brak ataku mimo WALKA): sprawdzić, czy bot w ogóle wykonuje atak w stanie WALKA, gdy cel jest poza zasięgiem.
- do zmierzenia: Porównanie trzymaj vs stuk jest niemożliwe, bo w danych występuje tylko tryb trzymaj: zebrać dane z trybu stuk w tych samych warunkach, aby ocenić, czy klaster zanika przy pojedynczych naciśnięciach.

## 2026-10-14 18:42 | uwaga | pościgów 5 min: 10, 30 min: 251
- Najgorsze pościgi kończą się brakiem ruchu postaci mimo osiągalnej drogi, a 4 z 5 dzieją się na tej samej pozycji. (pewność 0.5)
  dowód: 5/5 najgorszych: powod=brak_ruchu, kroki 0 lub 7, zmiany_kier 0-2, czas 1.6-5.8 s, droga 3-8, osiagalny=true, hp_gracza 100; poz [32504,32270,8] w 4 z 5 przypadków; oknie długim brak_ruchu=6 (2.4% pościgów).
  skutek: Pościg stoi w miejscu przez kilka sekund przy celu w odległości 4-5, co wydłuża dobicie i zwiększa ryzyko zgubienia celu (w oknie długim 8 pościgów bez dojścia, 3.2%).
  propozycja: Funkcja obsługi stanu pościgu, która wykrywa brak_ruchu (nazwa stałej progu czasu bez ruchu, np. PURSUIT_STALL_S): sprawdzić, czy przy stanie stania wysyłane są naciski trzymaj bez przeliczenia trasy; kierunek: wykrycie blokady i przeliczenie ścieżki wcześniej.
- Trzy utknięcia w oknie długim mają wspólny kontekst: wolne pole (v=12-14) i obecność stwora Jointoramix z hp=0. (pewność 0.35)
  dowód: utkniecia.liczba=3; poz [32484,32293], [32484,32297], [32498,32269]; pole v 12/14, krok_s 0.56-0.66; Jointoramix obecny 3/3 zdarzeń, Troll hp 1-4.
  skutek: Pole ogranicza tempo do ok. 0.6 kroku/s, a martwy lub zablokowany stwór może zajmować kratkę na trasie; przy n=3 to hipoteza, nie stwierdzenie.
  propozycja: Funkcja wyznaczania trasy pościgu: uwzględnić kafelki zajęte przez martwe ciała/stwory z hp=0 jako przeszkody (nazwa stałej lub flagi, np. TREAT_ZERO_HP_AS_BLOCKED); do zweryfikowania na większej próbie.
- Latencja reakcji wzrosła ponad dwukrotnie między oknem krótkim a długim, bez wyraźnego spadku kroków na sekundę. (pewność 0.3)
  dowód: lat_med_s: 0.194 (krótkie, n=10) vs 0.483 (długie, n=251); kroki_na_s med: 1.7 vs 1.77; dobicie_proc 70 vs 96.
  skutek: Większe opóźnienie może powodować nadmiarowe naciski i opóźnione korekty kierunku; w danych nie widać jeszcze spadku skuteczności, więc wpływ jest niepotwierdzony.
  propozycja: Funkcja pomiaru latencji i pętli wysyłania klawiszy: sprawdzić, czy opóźnienie nie jest liczone razem z czasem oczekiwania na stan gry; bez zmiany stałych na razie.
- Jedno zgubienie celu w oknie długim jest liczone w epizodach, ale nie w zakończeniach pościgów ani w powodach wyjść. (pewność 0.6)
  dowód: epizody_celu.zgubione=1 (powod_top='zniknął z widoku żywy', wskaźnik 98); koniec.zgubienie=0; powody_wyjsc nie zawiera 'cel_znikl'; suma powodów 251 = 251 pościgów.
  skutek: Wskaźnik zgubień wynosi 0% w jednym zestawieniu i 0.4% w drugim; zaniżenie utraty dobić może ukryć rzeczywisty problem z celami znikającymi z widoku.
  propozycja: Funkcja klasyfikacji zakończenia pościgu (np. mapowanie cel_znikl do jednego powodu): ujednolicić, żeby zgubienie z epizodu trafiało do koniec.zgubienie.
- Krótkie okno pokazuje więcej naciśnięć z postoju na pościg niż długie, ale to próbka zbyt mała, by wyciągać wniosek o przyczynie. (pewność 0.2)
  dowód: naciski_z_postoju_na_poscig: 1.2 (n=10) vs 0.33 (n=251); trzymane_proc: 99 vs 87; zmiany_kierunku_na_krok: 0.38 vs 0.34.
  skutek: Możliwe marnowanie wciśnięć przy zatrzymaniu, ale nie wiadomo, czy wpływa to na dobicia (oba okna mają wysoki wskaźnik dobicia).
  propozycja: Funkcja decyzji trzymania klawisza (stała progu odległości przy której puszczasz klawisz): tylko do obserwacji, bez zmiany wartości.
- do zmierzenia: Czy kafelki na trasie przy brak_ruchu zawierają martwe ciało lub stwora z hp=0 (zapis stanu kafelków w momencie stania postaci).
- do zmierzenia: Czy latencja 0.48 s przy brak_ruchu jest wyższa niż przy udanych pościgach (rozbicie lat_med_s po powodzie wyjścia).
- do zmierzenia: Porównanie trzymaj vs stuk: w danych brak trybu stuk, więc potrzebna próbka z obydwoma trybami w tym samym oknie.
- do zmierzenia: Jaki powód wyjścia dostaje pościg, w którym cel zniknął z widoku, i czy to jedyny wypadek zgubienia w epizodach (zapis powod przy każdym zgubieniu).
- do zmierzenia: Czy 2 przerwane_inne mają wspólną przyczynę z klastrem brak_ruchu (ta sama pozycja, ten sam stwór).

## 2026-10-14 18:44 | uwaga | pościgów 5 min: 5, 30 min: 238
- Większość nieudanych dojść to jedno miejsce: pościgi kończą się brak_ruchu przy tej samej pozycji (32504,32270) lub blisko niej, w ciągu ok. 14 s (18:29:41–18:29:55). (pewność 0.5)
  dowód: W najgorszych_poscigach 5 z 6 wpisów ma powod=brak_ruchu, kroki=0, czas ~1.6 s, odl 4–5, osiagalny=true, cel Troll hp 14, hp_gracza 100, pole v12 krok_s 0.56. Wszystkie 5 zaczyna się w przedziale 18:29:42–18:29:55, a w utkniecia długiego okna jest wpis 18:29:4
  skutek: brak_ruchu to 6 z 238 pościgów w oknie długim, a razem z okno (2) daje 8 bez dojścia (3,4%). Każdy taki przypadek to niedobicie celu, które było osiągalne według osiagalny=true.
  propozycja: Sprawdzić w kodzie logikę wykrywania brak_ruchu (próg czasu bez zmiany pozycji oraz warunek przejścia do ponownego wyznaczania drogi) oraz funkcję wyznaczania ścieżki, gdy droga jest krótka (3–8) i cel jest osiągalny, ale postać nie wykonuje kroku. Rozważyć, czy stała progu brak_ruchu nie jest zbyt krótka dla tego miej
- Utknięcia w walce występują przy niskiej prędkości pola (v 12–16, krok_s 0.56–0.75) i obecności Trolli w zasięgu, co wskazuje na blokadę ścieżki przez stwory, a nie na błąd kierunku. (pewność 0.35)
  dowód: Wszystkie 4 utkniecia w oknie długim są w stanie WALKA, z Jointoramix hp 0 i 1–4 Trollami; pole v12–16 krok_s 0.56–0.75, podczas gdy średnie kroki_na_s dla trzymaj to 1.8. W najgorszych pościgach zmiany_kier=0 i kroki=0.
  skutek: Gdy ścieżka jest zablokowana przez stwory, pościg stoi zamiast dobijać, a w oknie długim zdarzyło się to 4 razy.
  propozycja: Funkcja wyznaczania ścieżki pościgu: dodać uwzględnianie zajętych pól (stworów) jako przeszkód przy planowaniu drogi, a nie tylko przy kroku. Do rozważenia przez człowieka.
- Latencja reakcji nie wzrosła między oknami: lat_med_s wynosi 0.5 w obu oknach, co nie potwierdza wcześniejszego wniosku o podwojeniu opóźnienia. (pewność 0.7)
  dowód: okno_krotkie trzymaj lat_med_s 0.5 (n=5); okno_dlugie trzymaj lat_med_s 0.5 (n=238); dec_med_s 0.001 vs 0.0.
  skutek: Brak dowodu na pogorszenie reakcji; wcześniejszy wniosek nie ma poparcia w tych danych.
  propozycja: Brak zmiany w kodzie. Odrzucić wniosek o wzroście latencji, dopóki nie pojawi się nowa próba z danymi.
- Naciśnięcia klawisza z postoju pojawiają się przy pościgach, które stoją w miejscu, a nie przy zmianach kierunku, więc przyczyną może być trzymanie klawisza mimo braku ruchu. (pewność 0.3)
  dowód: naciski_z_postoju 79 w oknie długim (0,33 na pościg), trzymane_proc_czasu 87%; w najgorszych pościgach zmiany_kier=0 przy kroki=0, a naciski z postoju nie są rozbite na pościgi.
  skutek: Klawisz trzymany przy zablokowanej postaci może marnować czas i utrudniać wykrycie utknięcia; skala jest mała (79 z 238 pościgów).
  propozycja: Funkcja obsługi trzymania klawisza w pościgu: sprawdzić, czy trzymanie jest przerywane lub ponawiane, gdy kroki=0 przez więcej niż jeden tick. Do rozważenia przez człowieka.
- Liczba zgubień nie zgadza się między statystykami: epizody_celu liczą 1 zgubienie w oknie długim, a zakończenia pościgów i powody wyjść liczą 0. (pewność 0.6)
  dowód: okno_dlugie epizody_celu.zgubione=1 (wskaznik 98), koniec.zgubienie=0, powody_wyjsc bez 'zgubienie'; powod_top='zniknął z widoku żywy'. W okno_krotkie zgubione=0 w obu miejscach.
  skutek: Jedno zgubienie może być zaliczone do innej kategorii (np. brak_ruchu lub okno) i zaniżać liczbę realnych zgubień lub zawyżać dobicia.
  propozycja: Funkcja klasyfikacji zakończenia pościgu: sprawdzić, jak epizod z powodem 'zniknął z widoku żywy' jest mapowany na kategorię końca pościgu i czy trafia do brak_ruchu/okno zamiast zgubienie.
- do zmierzenia: Zapis pozycji gracza i stworów co tick w przedziale 18:29:40–18:30:00 (pozycja 32504,32270): czy pole jest zajęte przez stwór i czy klawisz był trzymany, gdy kroki=0.
- do zmierzenia: Liczba pościgów i brak_ruchu rozbita na konkretne współrzędne, żeby sprawdzić, czy problem jest przypisany do tego jednego miejsca.
- do zmierzenia: Identyfikator epizodu z powodem 'zniknął z widoku żywy' i jego zapis przy zakończeniu pościgu, żeby potwierdzić mapowanie.
- do zmierzenia: Latencja w większej próbie krótkiego okna (n>=30), żeby ocenić, czy lat_med_s 0.5 jest stabilne.
- do zmierzenia: Rozbicie naciśnięć z postoju na pościgi z brak_ruchu i bez niego, żeby sprawdzić związek z wnioskiem o trzymaniu klawisza.

## 2026-10-14 18:46 | uwaga | pościgów 5 min: 9, 30 min: 202
- Pościgi kończą się dobiciem w większości przypadków, ale część zatrzymuje się na brak_ruchu przy trzymanym klawiszu, bez kroków. (pewność 0.5)
  dowód: okno_dlugie: dobicie 190/202 (94%), zgubienie 0 wg koniec; bez_dojscia 9, brak_ruchu 7; naciski_z_postoju 81 (0.4 na pościg); trzymane_proc_czasu 87. W 3 z 5 najgorszych pościgów kroki=0 przy trzymaj, czas 1.6 s, cel Troll hp 14, odl 3–5.
  skutek: Około 4,5% pościgów (9/202) nie dochodzi do celu, a naciski z postoju wskazują, że klawisz bywa trzymany mimo braku przesunięcia postaci.
  propozycja: Funkcja obsługi braku ruchu w pętli pościgu: rozważyć, czy po krótkim progu czasu bez zmiany pozycji klawisz powinien być puszczony i pościg przełączony na ścieżkę alternatywną, zamiast trzymania. Nazwa stałej progu do ustalenia w kodzie.
- Wszystkie 4 utknięcia zdarzyły się w stanie WALKA na polach o niskiej wartości v (12–16) przy obecności Jointoramix z wartością 0 i Trollów w pobliżu. (pewność 0.3)
  dowód: okno_dlugie.utkniecia: 4 zdarzenia, pole v 12, 14, 12, 16; krok_s 0.56–0.75; stwory zawierają Trolla w odległości 1–4 i Jointoramix z drugą wartością 0 (znaczenie pola do potwierdzenia).
  skutek: Potwory mogą blokować ścieżkę, a pościg wtedy stoi, zamiast obejść przeszkodę.
  propozycja: Funkcja wyznaczania ścieżki w pościgu: sprawdzić, czy zajęte pola (potwory innych graczy/stworów) są uwzględniane przy wyborze kroku, a także stałą progu v używaną do wykrywania utknięcia.
- Wynik w oknie krótkim (78% dobicia) jest wyraźnie niższy niż w długim (94%), ale to tylko 9 pościgów. (pewność 0.2)
  dowód: okno_krotkie: dobicie 7/9 (78%), bez_dojscia 1, przerwane_inne 1; okno_dlugie: dobicie 190/202 (94%).
  skutek: Nie da się stwierdzić, czy to trend, czy przypadek; n=9 jest za małe.
  propozycja: Brak zmiany w kodzie na tej podstawie; poczekać na większą próbę.
- do zmierzenia: Czy naciski z postoju (81 w oknie długim) pokrywają się z przypadkami kroki=0 przy trzymaj i z brak_ruchu? Zmierzyć liczbę naciśnięć z postoju osobno dla pościgów z brak_ruchu i z dobiciem.
- do zmierzenia: Czy zgubienia są liczone inaczej w epizody_celu (2 w długim, 1 w krótkim) niż w koniec.zgubienie (0)? Sprawdzić, czy powód cel_martwy (14) jest wliczany do dobicia (190), czy osobno.
- do zmierzenia: Jak wygląda wynik w trybie stuk? Brak danych dla stuk w tej próbce, więc porównanie trzymaj vs stuk nie jest możliwe.
- do zmierzenia: Czy utknięcia w polu v 12–16 powtarzają się na tych samych współrzędnych (np. 32484–32500, 32269–32297)? Zebrać pozycje przeszkód dla tych miejsc.

## 2026-10-14 18:48 | problem | pościgów 5 min: 25, 30 min: 195
- W ostatnich 5 min pościg często kończy się bez dojścia: postać trzyma klawisz, ale nie wykonuje kroków, zwłaszcza gdy cel jest 4–5 pól dalej. (pewność 0.6)
  dowód: okno_krotkie: 13/25 pościgów (52%) zakończonych brak_ruchu; trzymane_proc_czasu 97; naciski_z_postoju 41 (1,64 na pościg); kroki 37 w 43,9 s (0,84 kr/s ogółem wobec med 1,6). najgorsze_poscigi: 5/5 to Troll z kroki 0–2 mimo droga 6–7 i osiagalny=true.
  skutek: Dobicie spada do 44% w oknie krótkim wobec 88% w długim (195 pościgów). Każdy taki pościg to niedobity, uciekający cel.
  propozycja: Funkcja pętli trzymania klawisza (obsługa brak_ruchu): po wysłaniu kroku sprawdzać zmianę pozycji i przy braku zmiany zwalniać klawisz, zamiast go dalej trzymać i ponawiać naciśnięcia. Kierunek: mniej naciśnięć z postoju na pościg.
- Utknięcia i najgorsze pościgi występują wyłącznie w stanie WALKA, a obecny jest Troll (często też Jointoramix), co sugeruje blokadę przez inne potwory na drodze. (pewność 0.4)
  dowód: utkniecia (okno krótkie 2/2, długie 5/5): stan WALKA, stwory zawierają Troll; najgorsze_poscigi 5/5 stan WALKA z Trollem w odl 2–5. Nie ma mianownika (ile pościgów WALKA w ogóle było), więc to tylko korelacja.
  skutek: Pościg zatrzymuje się, gdy kolejny krok jest zajęty przez potwór, a postać nie wykrywa tego przed naciśnięciem.
  propozycja: Funkcja wyznaczania kroku w pościgu: przed wysłaniem klawisza w stanie WALKA sprawdzać, czy kafelek na ścieżce jest zajęty przez inny stwór, i wtedy wybierać alternatywną ścieżkę lub czekać, zamiast trzymać klawisz.
- W oknie krótkim jest dużo zmian kierunku na krok, co przy braku oscylacji A-B wskazuje na przeliczanie ścieżki z opóźnieniem, a nie na pętlę. (pewność 0.35)
  dowód: zmiany_kierunku 18 na 37 kroków (0,49/krok) wobec 0,38 w długim oknie; oscylacje liczba 0; lat_med 0,406 s (krótkie) i 0,5 s (długie), dec_med ≈0,002 s.
  skutek: Kroki marnowane na korekty kierunku; przy opóźnieniu 0,4–0,5 s korekta idzie za późno i postać zawraca.
  propozycja: Funkcja wyboru kierunku w pościgu: dodać histerezę lub nie przeliczać kierunku, dopóki nie zmieni się pozycja celu o co najmniej 1 pole. Kierunek: mniej przeliczeń na krok.
- Wskaźnik skuteczności liczy epizody celu, a nie pościgi, więc zawyża wynik i ukrywa nieudane pościgi. (pewność 0.7)
  dowód: okno_krotkie: epizody_celu 12, zabite 11, wskaznik 92, podczas gdy koniec.dobicie_proc = 44 (11/25 pościgów). okno_dlugie: wskaznik 96 (44/46 epizodów) wobec dobicie_proc 88 (171/195).
  skutek: Raport pokazuje wysoką skuteczność nawet wtedy, gdy większość pościgów kończy się bez dojścia.
  propozycja: Funkcja liczenia wskaźnika w raporcie: liczyć dobicie jako koniec=dobicie / wszystkie pościgi, a epizody pokazywać osobno jako informację pomocniczą.
- Ostatnie wnioski w danych są niezgodne z bieżącymi liczbami (stare wartości), więc nie są wiarygodnym punktem odniesienia. (pewność 0.85)
  dowód: ostatnie_wnioski podają 78% (krótkie) i 94% (długie) oraz 4 utknięcia; dane podają 44% i 88% oraz 2 i 5 utknięć. niespojnosci: [] mimo tej rozbieżności.
  skutek: Ryzyko, że decyzje zostaną oparte na przestarzałym obrazie skuteczności.
  propozycja: Funkcja generowania raportu: budować wnioski z tych samych statystyk co sekcja danych (jedno źródło), a nie z osobnego, zapamiętanego bufora.

## 2026-10-14 18:50 | problem | pościgów 5 min: 33, 30 min: 172
- Pościg zatrzymuje się przy osiągalnej drodze: postać nie wykonuje kroków mimo trzymanego klawisza, więc kończy się jako brak_ruchu. (pewność 0.6)
  dowód: okno_krotkie: brak_ruchu 13 z 33 pościgów (39%), trzymane_proc_czasu 97, naciski_z_postoju 44 (1,33 na pościg). najgorsze_poscigi: 18:47:35, 18:47:40, 18:47:42 z kroki=0, droga 6-7, osiagalny=true. okno_dlugie: brak_ruchu 19 z 172 (11%).
  skutek: W oknie krótkim dobicie spadło do 58% (19/33), a 13 pościgów zakończyło się bez dojścia mimo istniejącej ścieżki. Przy 86% w długim oknie 21 pościgów kończy się bez dojścia.
  propozycja: Zbadać funkcję wysyłania kroku w pętli pościgu (warunek blokady ruchu i sposób obsługi trzymanego klawisza, gdy kolejny krok jest wysyłany, ale postać nie zmienia pozycji). Rozważyć stałą progu 'brak ruchu' i to, czy przy osiągalnej drodze pętla powinna ponowić krok, a nie czekać.
- Utknięcia i najgorsze pościgi są skupione w jednym miejscu i przy jednym stworze w pobliżu, co wskazuje na lokalną przeszkodę, a nie na losowy błąd. (pewność 0.4)
  dowód: Pozycje [32485,32298,9] i [32482,32296,9]: 5 z 6 najgorszych pościgów w oknie 18:45-18:49 (Troll hp 8, 3 pościgi w ~7 s). Wszystkie utknięcia (2 krótkie, 6 długie) mają wpis ["Jointoramix",0] i pole v 12-16 (krok_s 0.56-0.75). Nie wiadomo, czy 0 oznacza odległ
  skutek: Pościgi za trollami w tym rejonie kończą się bez dojścia, mimo że cel ma hp 8, czyli byłby łatwy do dobicia.
  propozycja: Dodać do logu dla utknięć listę zajętych płytek na ścieżce i identyfikatory stworów na nich (nie tylko najbliższego). Po zebraniu danych rozważyć w kodzie filtr, który przy blokadzie ścieżki przez stwór wybiera alternatywną trasę zamiast stać.
- Zmiany kierunku przy braku oscylacji wskazują na przeliczanie ścieżki z opóźnieniem, a nie na pętlę A-B. (pewność 0.5)
  dowód: zmiany_kierunku_na_krok: 0,40 (krótkie) i 0,39 (długie). oscylacje: 0 w obu oknach. lat_med 0,40-0,50 s, dec_med 0,001 s. kroki_na_s med 1,77-1,88.
  skutek: Część kroków idzie na korekty kierunku, a nie na dojście do celu, co wydłuża pościg. Dane nie pokazują jeszcze, czy wpływa to na wynik dobicia.
  propozycja: Sprawdzić częstotliwość przeliczania ścieżki w pętli pościgu oraz stałą okna na odpowiedź serwera (lat). Rozważyć, czy przeliczanie powinno być ograniczone przy stałym kierunku celu, zamiast po każdym kroku.
- Wskaźnik skuteczności liczy epizody celu, a nie pościgi, i zawyża wynik względem rzeczywistego dobicia. (pewność 0.9)
  dowód: epizody_celu.wskaznik 98 (długie) i 90 (krótkie), ale koniec.dobicie_proc 86 (długie) i 58 (krótkie). Epizody: 46 długie, 10 krótkie; pościgi: 172 i 33.
  skutek: Raport pokazuje prawie pełną skuteczność, mimo że 14% pościgów w długim i 42% w krótkim oknie nie kończy się dobiciem. Problem jest więc ukryty.
  propozycja: Zmienić wskaźnik raportu, aby używał koniec.dobicie_proc (pościgi), a epizody zostawić jako osobną metrykę. Zmiana dotyczy funkcji liczącej raport, nie logiki pościgu.
- Spadek skuteczności w oknie krótkim jest istotny, ale oparty na małej próbie i prawdopodobnie skupiony w jednym epizodzie. (pewność 0.5)
  dowód: dobicie_proc: 58 (33 pościgi) vs 86 (172 pościgi). Przybliżony 95% przedział Wilsona: około 0,42-0,72 dla krótkiego i 0,80-0,91 dla długiego, czyli są na granicy rozłączności. Utknięcia z tego samego rejonu: 18:47-18:49.
  skutek: Trudno ocenić, czy problem jest stały, czy była to chwilowa sytuacja w jednym rejonie. Bez dłuższego pomiaru nie da się tego rozstrzygnąć.
  propozycja: Zebrać kolejne okno dłuższe (np. 1800 s) po ewentualnej zmianie, aby porównać dobicie_proc i liczbę brak_ruchu. Nie zmieniać nic na podstawie jednego okna.
- do zmierzenia: Czy ["Jointoramix",0] to stwór na płytce na ścieżce (blokada) czy tylko odległość/hp; zapisać listę zajętych płytek na ścieżce w chwili brak_ruchu.
- do zmierzenia: Czy brak_ruchu poprzedza skok lat_med (np. >0,5 s) lub zmiana pozycji celu; porównać lat_med przy brak_ruchu i przy dobiciu.
- do zmierzenia: Czy wolne płytki (pole v 12-16, krok_s 0,56-0,75) korelują z utknięciami; zebrać statystyki utknięć według pola na większej próbie.
- do zmierzenia: Ile pościgów w rejonie 32485,32298 zakończyło się bez dojścia w całym dłuższym oknie (nie tylko w 5 najgorszych).
- do zmierzenia: Czy przy brak_ruchu naciski_z_postoju rosną (klawisz wciśnięty, pozycja stała), co potwierdzi przytrzymanie bez ruchu.

## 2026-10-14 18:52 | problem | pościgów 5 min: 30, 30 min: 161
- Brak dojścia (brak_ruchu) jest skupiony w ostatnich 5 minutach okna długiego, a nie rozłożony równomiernie. (pewność 0.6)
  dowód: okno_krotkie: brak_ruchu 13 z 30 pościgów (43%); okno_dlugie: brak_ruchu 20 z 161 (12%). Krótkie okno jest podzbiorem długiego, więc 13 z 20 brak_ruchu wystąpiło w 300 s, czyli w 17% czasu okna. Dobicie: 57% w krótkim vs 84% w długim.
  skutek: Około 13 niezrealizowanych dobić w ciągu 5 minut; skuteczność pościgów spadła wyraźnie względem reszty okna.
  propozycja: Ustalić, co zmieniło się w kodzie lub w sytuacji około 18:45 (typ celu, wersja zachowania pościgu). Konkretnie: sprawdzić funkcję warunkującą wysłanie ruchu w pętli pościgu oraz jej stałe progów; kierunek zmiany wymaga diffu, którego nie ma w danych.
- Wszystkie 5 najgorszych pościgów i wszystkie 5 utknięć wystąpiły w stanie WALKA, co może oznaczać, że stan walki blokuje wysyłanie ruchu w pętli pościgu. (pewność 0.45)
  dowód: najgorsze_poscigi: 5/5 stan WALKA, hp_gracza 100 we wszystkich (to nie jest ucieczka z powodu HP); utkniecia: 5/5 WALKA; najgorsze pościgi: brak_ruchu przy kroki 0-7 i odl 2-5.
  skutek: Pościg zatrzymuje się, a cel (Troll, hp 8-24) zostaje poza zasięgiem dobicia.
  propozycja: Sprawdzić, czy stan WALKA ma pierwszeństwo nad krokiem pościgu. Kierunek: funkcja wysyłania kroku pościgu powinna działać także w stanie WALKA (nazwa funkcji do ustalenia w kodzie).
- Część naciśnięć klawisza trzymaj nie przesuwa postaci (naciski z postoju). (pewność 0.5)
  dowód: okno_krotkie: 38 naciśnięć z postoju przy 29 krokach (~57% naciśnięć bez przesunięcia); okno_dlugie: 101 przy 153 krokach (~40%). Trzymane_proc_czasu: 93% i 88%. ponow_brak: 14 i 29.
  skutek: Czas tracony bez postępu, co dokłada się do brak_ruchu.
  propozycja: Sprawdzić funkcję wysyłania klawisza trzymaj: czy po naciśnięciu jest weryfikowana zmiana pozycji. Kierunek: po braku przesunięcia zwalniać i ponawiać wysyłanie zamiast trzymać klawisz.
- W dwóch najgorszych pościgach trasa istniała (droga 6-7), a postać nie wykonała żadnego kroku; w jednym przypadku droga=0 przy osiagalny=true. (pewność 0.4)
  dowód: Pozycja [32485,32298,9] powtarza się w pościgach 18:47:40 (droga 7, kroki 0, 2.13 s) i 18:47:42 (droga 6, kroki 0, 3.51 s). Pościg 18:51:37: droga 0, osiagalny true, kroki 0. Zmiany_kier 0 we wszystkich trzech.
  skutek: Brak ruchu przy dostępnej drodze wskazuje na błąd wykonania, nie na przeszkodę geometryczną.
  propozycja: Sprawdzić funkcję liczenia drogi i pole osiagalny: droga=0 powinna oznaczać brak wyliczenia, a osiagalny powinien wynikać z drogi. Kierunek: ujednolicić oba pola i logować brak kroku przy istniejącej drodze.
- Zmiany kierunku (~0.35-0.37 na krok) nie różnicują okna krótkiego od długiego i nie są oscylacją, więc nie wyjaśniają spadku skuteczności. (pewność 0.6)
  dowód: zmiany_kierunku_na_krok: 0.34 (krótkie) vs 0.37 (długie); oscylacje: 0 w obu oknach; lat_med: 0.40 s vs 0.46 s (krótkie ma niższą latencję).
  skutek: Brak wpływu na skuteczność; dalsze szukanie przyczyny w zmianach kierunku nie jest uzasadnione danymi.
  propozycja: Brak zmiany do wprowadzenia; obserwować tylko przy zmianach w ścieżce.
- do zmierzenia: Przy każdym wyjściu z pościgu zapisać stan (WALKA/inny), aby potwierdzić lub odrzucić związek brak_ruchu z WALKA na większej próbie (więcej niż 5 przypadków).
- do zmierzenia: Dla każdego naciśnięcia zapisać, czy pozycja zmieniła się w ciągu np. 0.5 s; odróżni to blokadę fizyczną (kafelek/stwór) od niewysłanego klawisza.
- do zmierzenia: Zapisać stwory na kolejnym kafelku trasy przy brak_ruchu, żeby sprawdzić, czy blokuje je inny potwór lub gracz.
- do zmierzenia: Porównać skuteczność per cel (Troll vs inne) i per hp_celu, aby sprawdzić, czy cel z niskim HP zmienia zachowanie ucieczki.
- do zmierzenia: Zmierzyć brak_ruchu w zależności od pole.krok_s (poniżej ~1 krok/s vs powyżej), bo utknięcia były tylko w polach 0.56-0.75 kroku/s.

## 2026-10-14 18:54 | uwaga | pościgów 5 min: 13, 30 min: 112
- Klawisz trzymaj często jest wciśnięty, a postać nie idzie: większość pościgów kończy się bez ruchu, a nie brakiem trzymania. (pewność 0.6)
  dowód: Okno długie: 112 pościgów, naciski_z_postoju=106 (0.95 na pościg), trzymane 86% czasu (106 s), a tylko 167 kroków. kroki_na_s_ogolem=1.36 przy medianie w trybie 1.73, czyli różnica wynika z czasu w postoju.
  skutek: Czas trzymania przechodzi w postój. 22 z 112 pościgów (20%) kończy się brak_ruchu/bez_dojścia zamiast dobiciem, co obniża dobicie_proc do 78%.
  propozycja: Sprawdzić funkcję wysyłania ruchu w stanie WALKA (obsługa trzymania klawisza, gdy postać nie zmienia pozycji). Do rozważenia: stała określająca czas, po którym brak zmiany pozycji przy trzymanym klawiszu ma przerwać/przeliczyć ruch.
- Najgorsze przypadki to pościgi z istniejącą drogą, w których postać nie wykonuje żadnego kroku, i prawie wszystkie utknięcia są w stanie WALKA. (pewność 0.45)
  dowód: Najgorsze: 5 pościgów Troll z droga 6–7 (jeden z droga=0), osiagalny=true, kroki 0, odl 2–5, stan WALKA. Wszystkie 5 utknięć w oknie długim ma stan WALKA z Jointoramix o odl 0 w danych stwory; pole v 12–16, krok_s 0.56–0.75.
  skutek: Postać stoi mimo dostępnej trasy, cel ucieka lub zostaje poza zasięgiem; pościg kończy się bez dobicia.
  propozycja: Sprawdzić funkcję decyzji walka-vs-pościg w stanie WALKA: czy obecność innego potwora (Jointoramix przy odl 0) blokuje ruch. Do rozważenia: warunek, przy którym ruch do celu ma pierwszeństwo nad atakiem na sąsiada.
- Skuteczność dobić spadła z 92% (okno krótkie) do 78% (długie) głównie przez wzrost brak_ruchu. (pewność 0.5)
  dowód: Okno krótkie: dobicie 12/13 (92%), brak_ruchu 1. Okno długie: dobicie 87/112 (78%), brak_ruchu 20, bez_dojscia 22, zgubienie 0 w obu oknach.
  skutek: Spadek nie wynika ze zgubień celu, lecz z pościgów, które nie docierają do celu. Różnica przy n=13 jest niepewna.
  propozycja: Brak zmiany kodu na tym etapie; najpierw dłuższa próba w oknie krótkim, żeby potwierdzić, czy spadek jest stały.
- Zmiany kierunku na krok są dwukrotnie częstsze w oknie długim niż krótkim, ale to nie oscylacja (A-B-A-B = 0). (pewność 0.3)
  dowód: zmiany_kierunku_na_krok: 0.34 (długie, 57 zmian na 167 kroków) vs 0.17 (krótkie, 5 na 29). oscylacje.liczba=0.
  skutek: Część kroków idzie w niewłaściwym kierunku, co wydłuża dojście, ale nie tworzy pętli. Przy n=13 w oknie krótkim to niska pewność.
  propozycja: Sprawdzić funkcję wyboru kierunku ścieżki (ponowne przeliczanie drogi co krok). Do rozważenia: rzadsze przeliczanie lub utrzymanie kierunku do zmiany pola.
- do zmierzenia: Czy naciski z postoju pokrywają się z ustawieniem stanu WALKA: zalogować stan i zmianę pozycji dla każdego wysłanego kroku w pościgu.
- do zmierzenia: Czy Jointoramix w odl 0 to rzeczywiście cel ataku (autoatak blokuje ruch): zmierzyć, ile kroków przypada na pościgi z potworem sąsiadującym i bez niego.
- do zmierzenia: Czy ponow_brak=30 (okno długie) odpowiada wysłanym, a nieprzyjętym ruchom: zalogować odpowiedź klienta na każde wysłanie klawisza.
- do zmierzenia: Czy lat_med ~0.5 s (stałe w obu oknach) opóźnia pierwszą zmianę pozycji po wciśnięciu trzymaj: zmierzyć czas od wysłania do pierwszej zmiany pozycji.
- do zmierzenia: Czy spadek dobić w oknie krótkim utrzymuje się przy większej próbie (n>=30 pościgów).

## 2026-10-14 18:56 | uwaga | pościgów 5 min: 28, 30 min: 128
- Główną przyczyną nieudanych pościgów jest brak_ruchu: postać naciska klawisz, ale nie przemieszcza się, a cel zostaje żywy. (pewność 0.6)
  dowód: Okno długie: brak_ruchu 20 z 128 pościgów (16%), a bez_dojscia 22 (17%). Okno krótkie: brak_ruchu 1 z 28 (3,6%). Naciski_z_postoju 113 (0,88 na pościg). Wszystkie 5 najgorszych pościgów to brak_ruchu.
  skutek: Około 1 na 6 pościgów kończy się bez dobicia (dobicie 80% w oknie długim), mimo że cel nie został zgubiony.
  propozycja: Sprawdzić w kodzie funkcję wykrywania braku ruchu (próg liczby naciśnięć z postoju i czasu, zanim pościg uzna blokadę) oraz to, co cavebot robi po jej wykryciu. Rozważyć zmianę stałej progu lub dodanie reakcji na blokadę (np. przeliczenie drogi), do decyzji człowieka.
- Pościgi z wyliczoną drogą i celem w odległości 2–5 kratek potrafią nie wykonać żadnego kroku, co wskazuje na blokadę, a nie na brak ścieżki. (pewność 0.4)
  dowód: Pościg 18:47:40: droga 7, odl 4–5, kroki 0, zmiany_kier 0, czas 2,13 s. Pościg 18:47:50: droga 7, kroki 2. Dwa z pięciu najgorszych mają droga=0 przy osiagalny=true (18:45:55, 18:51:37), co jest niespójne i może oznaczać, że ścieżka nie została policzona.
  skutek: Postać stoi przy trzymanym klawiszu, aż minie okno, a cel pozostaje żywy.
  propozycja: Sprawdzić funkcję wyliczającą 'droga' i 'osiagalny': kiedy zwraca 0 przy osiagalny=true i co zwraca przy zablokowanym kroku. Rozważyć stałą określającą, po ilu nieudanych krokach przeliczać drogę.
- Utknięcia skupiają się w niewielkim obszarze mapy i zawsze w stanie WALKA, obok Jointoramix (dystans 0). (pewność 0.35)
  dowód: Okno długie: 5 utknięć, współrzędne x 32482–32500, y 32269–32296. Powtórzenia: (32482,32293) o 18:53:50 i (32482,32296) o 18:47:25. Pola v12 lub v16 (krok_s 0,56 lub 0,75). Wszystkie w WALKA.
  skutek: Lokalny tłok potworów lub przeszkoda na drodze blokuje ruch postaci w tym rejonie.
  propozycja: Sprawdzić, czy logika walki (wybór celu lub ustawienie postaci) w czasie pościgu może stać na drodze do celu, gdy obok jest Jointoramix. Ocenić, czy stała priorytetu walki w pościgu jest tu właściwa.
- Ogon prędkości pościgu jest wolniejszy w oknie długim, a pola o niskiej prędkości (v12) ograniczają krok_s do 0,56. (pewność 0.3)
  dowód: Kroki_na_s p10: 1,44 (krótkie) vs 1,21 (długie); mediana 1,8 w obu oknach. Utknięcia na polach v12 mają krok_s 0,56, na v16 0,75.
  skutek: Dłuższy czas dojścia na wolnych polach, a więc większa szansa na przekroczenie okna pościgu.
  propozycja: Sprawdzić, czy stała okna czasowego pościgu uwzględnia prędkość pola. Rozważyć skalowanie okna przez krok_s, do decyzji człowieka.
- Pościg nie gubi celu: problem leży w ruchu postaci, a nie w śledzeniu celu. (pewność 0.7)
  dowód: Zgubienie 0 w obu oknach (0%). Epizody celu: 48 z 49 zabite (98%) w oknie długim. Oscylacje A-B-A-B: 0. Latencja mediana 0,4–0,5 s, dec_med 0,001.
  skutek: Brak utraty celu z powodu śledzenia; straty dotyczą wyłącznie braku dojścia.
  propozycja: Brak zmiany wymagającej działania w kodzie śledzenia celu.
- do zmierzenia: Zapisać, co stoi na kolejnym polu drogi przy każdym naciśnięciu z postoju (potwór, ściana, pole), aby rozstrzygnąć, czy blokuje stwór czy teren.
- do zmierzenia: Zapisać wynik funkcji ścieżki (droga, osiagalny, kod zwrotu) przy każdym pościgu z odl 2–5, aby wyjaśnić droga=0 przy osiagalny=true.
- do zmierzenia: Porównać brak_ruchu w krótkim i długim oknie na większej próbie (ok. 128 pościgów w oknie krótkim), bo 1/28 vs 20/128 może być przypadkiem.
- do zmierzenia: Uruchomić tryb stuk na tym samym odcinku i porównać brak_ruchu, bo w tych danych tryb stuk nie był używany i nie ma porównania.
- do zmierzenia: Sprawdzić, czy 5 utknięć to pełna lista, czy próbka: 20 brak_ruchu przy 5 utknięciach wymaga wyjaśnienia rozbieżności między tymi liczbami.

## 2026-10-14 18:58 | uwaga | pościgów 5 min: 35, 30 min: 126
- Pościgi kończą się bez dojścia głównie przez brak_ruchu: postać trzyma klawisz, a mimo to nie robi kroków, mimo że ścieżka istnieje. (pewność 0.6)
  dowód: okno_dlugie: brak_ruchu 23 z 126 pościgów (18%), bez_dojscia 25 (20%); najgorsze_poscigi: 0 kroków przy czas 1,59–3,51 s, droga 6–7, osiagalny=true, odl 2–5; trzymane_proc_czasu 83%, naciski_z_postoju 118 (0,94 na pościg).
  skutek: Około 1 na 5 pościgów nie kończy się dobiciem, mimo braku zgubienia celu (zgubienie 0). Dobicia spadają do 78% w oknie długim wobec 89% w krótkim.
  propozycja: Funkcja wykrywania braku postępu (licznik czasu bez zmiany pozycji) – rozważyć, czy po N krokach bez postępu nie powinna sprawdzać zajętości następnego pola na ścieżce i przeliczać drogę, zamiast czekać na limit czasu. Do oceny przez człowieka.
- Wszystkie 5 utknięć w oknie długim wystąpiło w stanie WALKA, zawsze z Jointoramix w dystansie 0 od postaci, co wskazuje na stwora blokującego ścieżkę. (pewność 0.5)
  dowód: utkniecia.liczba=5; ostatnie: 5/5 z stwory [Jointoramix,0]; stan WALKA we wszystkich; krok_s 0,56–0,75.
  skutek: Utknięcia koncentrują się w jednym obszarze mapy, więc powtarzają się przy tym samym typie walki i wydłużają pościgi.
  propozycja: Funkcja wyznaczania ścieżki pościgu – uwzględnić zajęte pola (inne stwory, w tym Jointoramix) jako przeszkody przy obliczaniu drogi do celu. Kierunek: pathing omija zajęte płytki.
- Wzrosła liczba zmian kierunku na krok w oknie długim, co może oznaczać częstsze objazdy wokół przeszkód. (pewność 0.35)
  dowód: zmiany_kierunku_na_krok: 0,18 (krótkie, n=35) vs 0,31 (długie, n=126); zmiany_kierunku 52 w długim przy 166 krokach; najgorsze brak_ruchu mają 0 zmian kierunku, co nie potwierdza objazdów w tych przypadkach.
  skutek: Więcej zmian kierunku oznacza więcej kroków nieefektywnych względem celu, co obniża efektywny kroki_na_s.
  propozycja: Funkcja obliczania kierunku ruchu w pętli pościgu – sprawdzić, czy zmiany kierunku wynikają z ponownego przeliczania drogi przy każdej aktualizacji celu; kierunek: ograniczyć przeliczanie, gdy cel stoi w miejscu.
- Prędkość pola (v) wydaje się ograniczać krok_s na polach o niskiej wartości v, co przy utknięciach i najgorszych pościgach było widoczne. (pewność 0.3)
  dowód: utkniecia i najgorsze: v12 → krok_s 0,56; v16 → 0,75; v20 → 0,94; próba n=5 i n=5, bez pełnego zestawienia po wszystkich pościgach.
  skutek: Na wolnych polach pościg trwa dłużej, co zwiększa szansę na brak_ruchu i zgubienie przeciwnika.
  propozycja: Funkcja szacowania czasu dojścia (pola v) – rozważyć uwzględnienie v przy wyborze trybu trzymaj/stuk lub przy progu braku postępu. Najpierw zweryfikować na pełnym zbiorze pościgów.
- do zmierzenia: Czy brak_ruchu zbiega się z obecnością innego stwora na następnym polu ścieżki? Zapisać stwory na drodze w chwili 0 kroków.
- do zmierzenia: Czy brak_ruchu następuje tylko przy trzymanym klawiszu, a nie przy stuku? Zmierzyć stan klawisza w momencie każdego 0-krokowego okna.
- do zmierzenia: Czy lat_med (0,346 s w długim vs 0,2 s w krótkim) rośnie tuż przed brak_ruchu? Zapisać latencję w ostatnich 3 s przed wyjściem.
- do zmierzenia: Porównanie trzymaj vs stuk: stuk ma n=1 (wynik 1,23 kroków/s, 25% odrzuceń), więc różnica 1,59 vs 1,23 nie jest wnioskiem. Potrzeba co najmniej 5 pościgów w trybie stuk w tych samych warunkach.
- do zmierzenia: Co oznacza dystans 0 do Jointoramix: ten sam kafelek, przylegający stwór, czy wartość domyślna? Zapisać pozycję Jointoramix w chwili utknięcia.

## 2026-10-14 19:00 | uwaga | pościgów 5 min: 54, 30 min: 151
- Większość nieudanych pościgów kończy się brakiem ruchu mimo trzymanego klawisza, a nie zgubieniem celu. (pewność 0.6)
  dowód: okno długie: brak_ruchu 17 + bez_dojscia 19 z 151 pościgów (12,6%); zgubienie 1; naciski_z_postoju 119 (0,79 na pościg); ponow_brak 25; trzymane_proc_czasu 91
  skutek: Około 19 pościgów na 30 min nie doszło do dobicia, mimo że cel był osiągalny i w zasięgu; dobicie spadło do 85% (w oknie krótkim 93%).
  propozycja: Funkcja obsługi ruchu w pościgu (logika 'kroki=0 przy trzymanym klawiszu'): po N naciskach bez zmiany pozycji wykryj blokadę i uruchom obejście lub atak na blokera zamiast ponawiania klawisza. Stała progu N do rozważenia przez człowieka, kierunek: mniej ślepych ponowień.
- Najprawdopodobniej przyczyną blokady jest stwór stojący na ścieżce (Jointoramix), a nie sama prędkość postaci. (pewność 0.45)
  dowód: utkniecia 4/4 w stanie WALKA z Jointoramix w dystansie 0; najgorsze pościgi 18:47:40 i 18:47:42 w tej samej pozycji [32485,32298] z kroki=0, cel Troll w dystansie 4-5; utkniecie 18:47:25 w pobliskiej pozycji [32482,32296]
  skutek: Pościg stoi w miejscu, cel się oddala lub regeneruje; w próbce 4 utknięć taki wzorzec powtarza się w każdym przypadku.
  propozycja: Funkcja planowania ścieżki pościgu: pola zajęte przez inny żywy stwór powinny być traktowane jako przeszkody (lub najpierw atakowane). Do rozważenia przez człowieka: sprawdzenie zajętości następnego pola przed wysłaniem kroku.
- Niska prędkość pola może obniżać tempo kroków, ale dane są zbyt małe, by to rozstrzygnąć. (pewność 0.25)
  dowód: utkniecia i najgorsze pościgi na polach v=12 lub v=16 mają krok_s 0.56-0.75; pościg na v=20 ma krok_s 0.94, ale też zakończył się brak_ruchu; kroki_na_s med trzymaj 1,59 (p10 0,96, p90 2,51)
  skutek: Na wolnych polach dojście do celu trwa dłużej, co zwiększa szansę ucieczki celu.
  propozycja: Funkcja szacowania oczekiwanego czasu dojścia lub timeoutu pościgu: zależność od v pola. Kierunek do rozważenia po zebraniu większej próbki.
- do zmierzenia: Czy w każdym przypadku brak_ruchu następne pole na ścieżce było zajęte przez stwór? (logować zajętość kroku przy kroki=0)
- do zmierzenia: Czy naciski_z_postoju występują podczas stanu WALKA (bot atakuje zamiast iść) i czy to wyjaśnia ich liczbę 119?
- do zmierzenia: Czy odsetek brak_ruchu rośnie wraz z v pola? (zbierać v i krok_s dla wszystkich pościgów, nie tylko najgorszych)
- do zmierzenia: Porównanie trzymaj vs stuk wymaga co najmniej 5 pościgów w trybie stuk; obecne n=1 nie pozwala na wnioski.
- do zmierzenia: Czy jedyne zgubienie (zniknął z widoku żywy) wynika z wyjścia celu poza zasięg widzenia, czy z błędnego wyboru celu?

## 2026-10-14 19:02 | uwaga | pościgów 5 min: 70, 30 min: 175
- Większość nieudanych pościgów kończy się brakiem ruchu przy trzymanym klawiszu, a nie zgubieniem celu. (pewność 0.6)
  dowód: Okno długie: 175 pościgów, dobicie 153 (87%), bez_dojscia 19 (brak_ruchu 17, okno 2), zgubienie 0. Trzymane 91% czasu, naciski_z_postoju 122 (0,7 na pościg), ponow_brak 26. Trzy z pięciu najgorszych pościgów to brak_ruchu z kroki=0 lub 3 przy trzymaj.
  skutek: Około 11% pościgów (19/175) nie dochodzi do celu w 30 minut, mimo że postać trzyma klawisz; to bezpośrednia utrata dobić.
  propozycja: Sprawdzić w kodzie logikę trzymania klawisza i wykrywania blokady (warunek ponowienia i zwolnienia przy niezmiennej pozycji); rozważyć stałą progu 'brak ruchu' i czas po którym pętla przestaje ponawiać trzymanie. Zmiana do rozważenia przez człowieka.
- Tempo kroków w długim oknie spada w porównaniu z krótkim, a utknięcia występują przy niższej prędkości pola. (pewność 0.3)
  dowód: kroki_na_s ogółem: 2,13 (krótkie, 70 pościgów) vs 1,46 (długie, 175); med trzymaj 1,6, p10 0,96. Utknięcia przy krok_s 0,75 (3x) i 0,56 (1x) vs 0,94 w jednym udanym pościgu z najgorszej listy.
  skutek: Wolniejszy krok wydłuża pościg i zwiększa szansę, że cel zniknie lub zablokuje ścieżkę.
  propozycja: Zmierzyć krok_s pola dla udanych pościgów (nie tylko dla utknięć), zanim zmienimy jakąkolwiek stałą związaną z prędkością.
- Tryb stuk ma zbyt mało danych, żeby go oceniać względem trzymaj, a wyniki sugerują gorszą jakość (odrzucenia, wyższe opóźnienie). (pewność 0.2)
  dowód: stuk n=1 w oknie długim (kroki 3, odrzucone 1 z 4, lat_med 0,349 vs 0,2 dla trzymaj, zmiany_kierunku 0). Krótkie okno: brak pościgów stuk.
  skutek: Nie wiadomo, czy tryb stuk pogarsza wynik, czy jest po prostu rzadko używany; decyzja o nim może być błędna.
  propozycja: Brak wniosku o zmianie; potrzebna większa próba stuk przed oceną.

## 2026-10-14 19:04 | uwaga | pościgów 5 min: 63, 30 min: 164
- Utrata dobić koncentruje się w pościgach zakończonych brak_ruchu (zablokowana postać), głównie przy Trollach, i pojawia się tylko w długim oknie. (pewność 0.6)
  dowód: okno_dlugie: bez_dojscia 19/164 (11,6%), w tym brak_ruchu 17; dobicie_proc 86 vs 98 w oknie krótkim, gdzie bez_dojscia=0. Z 6 najgorszych pościgów 4 to brak_ruchu, wszystkie Troll, odl 2-5, kroki 0-7.
  skutek: Około 1 na 9 pościgów nie kończy się dobiciem; cel przeżywa i wymaga ponownego pościgu.
  propozycja: Funkcja wykrywania i obsługi braku ruchu w pętli pościgu: przy kroku, który nie zmienia pozycji, powinna następować ponowna kalkulacja ścieżki (zamiast czekać na stałą czasu brak_ruchu). Do rozważenia: stała progu czasu brak_ruchu, kierunek zmiany zwiększenie liczby prób przeliczenia przed poddaniem, bez skracania same
- Najprawdopodobniej blokadę na ścieżce tworzy inny stwór (Jointoramix lub Troll), a nie prędkość postaci. (pewność 0.5)
  dowód: utkniecia long: 5 zdarzeń, każde ze stworem Jointoramix w liście stwory; pole v 12-16, krok_s 0.56-0.75, czyli przy wyższym v z krótkiego okna (brak utknięć tam). Znaczenie drugiego pola (0, 1, 8, 2) w danych nie jest opisane.
  skutek: Pościg staje w miejscu przy bliskim celu zamiast dojść do 1 kratki.
  propozycja: Funkcja wyznaczania kroku/ścieżki: traktować pozycje innych żywych potworów jako przeszkody przy wyborze kolejnego kroku. Kierunek: uwzględnić blokujące stwory w obliczeniu trasy.
- Trzymany klawisz kierunku jest często wysyłany przy stojącej postaci, a zmiany kierunku rosną w długim oknie. (pewność 0.4)
  dowód: naciski_z_postoju: 125 w długim oknie (0.77 na pościg) vs 24 w krótkim (0.38 na pościg); zmiany_kierunku_na_krok 0.30 vs 0.23; trzymane_proc_czasu 91%.
  skutek: Część czasu idzie na powtarzane wysyłanie kierunku bez postępu, co może pogarszać przypadki brak_ruchu.
  propozycja: Funkcja obsługi trybu trzymaj: wykrywać brak zmiany pozycji między kolejnymi wysłaniami i wtedy zmieniać kierunek lub przerywać trzymanie, zamiast ponawiać ten sam kierunek. Do oceny przez człowieka.
- Wcześniejszy wniosek o spadku tempa kroków nie wynika z wolniejszego biegu, tylko z czasu bez ruchu. (pewność 0.6)
  dowód: Mediana kroki_na_s per pościg: trzymaj 1.5 (krótkie) vs 1.6 (długie). Spadek kroki_na_s_ogolem 2.1 -> 1.49 odpowiada p10=0.96 i brak_ruchu, a nie niższej medianie.
  skutek: Brak nowej przesłanki, by zmieniać tempo biegu; problem to postoje.
  propozycja: Brak zmiany w kodzie biegu; skupić się na obsłudze blokad (wniosek 1).
- Pola droga i osiagalny w najgorszych pościgach są wewnętrznie sprzeczne, więc ocena dostępności celu może być błędna. (pewność 0.3)
  dowód: Pościg 18:56:24: droga 2, osiagalny true; pościg 18:45:55: droga 0, osiagalny true przy odl [3,4]. Ten sam wynik osiagalny=true przy droga 0 wskazuje na niezgodne liczenie.
  skutek: Pościgi uznawane za osiągalne mogą być bez realnej trasy, co wydłuża bezczynność.
  propozycja: Funkcja obliczająca 'droga' i 'osiagalny' w logowaniu/ocenie pościgu: sprawdzić, czy droga=0 oznacza brak trasy, i zgodnie z tym ustawić osiagalny.
- do zmierzenia: Czy brak_ruchu zawsze występuje, gdy na następnym kroku stoi inny żywy stwór: zapisać ID i pozycję blokującego stwora przy każdym kroku bez zmiany pozycji.
- do zmierzenia: Co oznacza drugie pole w 'stwory' (0,1,2,8) — dystans, stan, czy liczba — żeby potwierdzić wniosek o blokadzie.
- do zmierzenia: Czy utknięcia i bez_dojscia skupiają się w czasie 18:43–19:03 (poza krótkim oknem), czyli czy problem ustąpił; porównać trend w kolejnych oknach.
- do zmierzenia: Czy naciski z postoju korelują z brak_ruchu na poziomie pojedynczego pościgu (korelacja, nie tylko średnie).
- do zmierzenia: Tryb stuk: n=1 pościg, więc ocena względem trzymaj jest niemożliwa; zebrać kilkadziesiąt pościgów w tym trybie, zanim cokolwiek z niego wywnioskujemy.

## 2026-10-14 19:06 | uwaga | pościgów 5 min: 40, 30 min: 192
- Ok. 9% pościgów kończy się bez dojścia przez brak ruchu: postać stoi, a cel jest 2-5 pól dalej. (pewność 0.6)
  dowód: okno_dlugie: brak_ruchu=17 z 192 pościgów, bez_dojscia=19 (17 brak_ruchu + 2 okno). W najgorszych pościgach 4 z 6 to brak_ruchu z kroki 0-7, trzymane_proc_czasu=92, naciski_z_postoju=130 (0,68 na pościg).
  skutek: Około 1 na 11 pościgów nie kończy się dobiciem i trwa do końca czasu pętli, zamiast zakończyć się zgubieniem lub dobiciem.
  propozycja: Funkcja pętli pościgu, która trzyma klawisz kierunku: dodać warunek przerwania trzymania, gdy pozycja nie zmienia się przez stałą czasową braku ruchu (nazwa stałej do ustalenia w kodzie). Kierunek: wykrywać zablokowany ruch wcześniej, zamiast powtarzać wysyłanie klawisza.
- Utknięcia pojawiają się tylko w stanie WALKA, a w czterech z pięciu obok celu stoją inne potwory (Troll, Orc). (pewność 0.4)
  dowód: okno_dlugie: utkniecia=5, wszystkie stan=WALKA; 4 z 5 mają w stwory także Troll lub Orc. Pole krok_s 0,56-0,75, a ogólnie kroki_na_s_ogolem=1,52.
  skutek: Pościg zwalnia właśnie wtedy, gdy trzeba dogonić cel w grupie, co wydłuża dojście i zwiększa ryzyko bez_dojscia.
  propozycja: Funkcja wyboru kroku/ścieżki w pętli pościgu: sprawdzić, czy pola zajęte przez inne potwory są traktowane jako przeszkody. Jeśli nie, dodać ich uwzględnienie w planowaniu ścieżki.
- Przy trzymanym klawiszu kierunku zmiany kierunku są częste, co może oznaczać zbaczanie z trasy. (pewność 0.3)
  dowód: okno_dlugie trzymaj: zmiany_kierunku=60, zmiany_kierunku_na_krok=0,3, trzymane_proc_czasu=92. Stuk ma tylko 1 pościg, więc nie daje porównania.
  skutek: Część kroków może nie zbliżać do celu. Dane nie pozwalają oszacować, ile kroków jest zmarnowanych.
  propozycja: Funkcja przeliczająca kierunek trzymanego klawisza: sprawdzić, czy kierunek jest odświeżany przy każdej zmianie pozycji celu, czy tylko przy starcie pościgu.
- Porównanie trzymaj vs stuk jest bezwartościowe, bo stuk ma n=1 pościg. (pewność 0.9)
  dowód: roznice_trybow: n trzymaj=191, stuk=1; różnice lat_med 0,349 vs 0,2 i dec_med 0,109 vs 0,001 pochodzą z jednego pościgu.
  skutek: Brak podstaw, by oceniać wpływ trybu stuk na skuteczność.
  propozycja: Nie zmieniać nic na podstawie tego porównania. Zebrać kolejne pościgi w trybie stuk, zanim wyciągnie się wnioski.
- Skuteczność dobić różni się między oknami: 98% w krótkim, 88% w długim. (pewność 0.3)
  dowód: okno_krotkie: dobicie_proc=98 (39/40), utkniecia=1. okno_dlugie: dobicie_proc=88 (169/192), utkniecia=5, z czego 4 z trollami lub orkami w pobliżu.
  skutek: Różnica może być szumem przy n=40, ale może też wynikać ze zmiany składu celów na trollowe pola.
  propozycja: Brak zmiany w kodzie na tym etapie. Rozstrzygnąć, czy to szum, czy skład celów.
- do zmierzenia: Czy brak_ruchu zachodzi głównie, gdy na drodze do celu stoi inny potwór? Zmierzyć, dla każdego brak_ruchu, zajętość pól między postacią a celem w chwili zatrzymania.
- do zmierzenia: Czy zmiana celu na świeższego (powod_top, 54 epizody) zdarza się w trakcie pościgu i czy po niej rośnie liczba kroków bez postępu?
- do zmierzenia: Dane w najgorszych_poscigach są sprzeczne: droga=0 przy osiagalny=true oraz droga=7 przy osiagalny=true. Zweryfikować, jak liczone są droga i osiagalny, zanim ocena dostępności celu zostanie uznana.
- do zmierzenia: Czy zmiany kierunku przy trzymanym klawiszu występują bezpośrednio po wysłaniu klawisza bez zmiany pozycji? Zmierzyć liczbę takich par zdarzeń.
- do zmierzenia: Dla trybu stuk potrzebne są co najmniej 5 pościgów, zanim porównanie z trzymaj będzie miało sens.

## 2026-10-14 19:08 | uwaga | pościgów 5 min: 69, 30 min: 224
- W długim oknie pościgi kończą się bez dojścia prawie wyłącznie przez brak ruchu postaci przy trzymanym klawiszu, głównie przy Trollu w stanie WALKA. (pewność 0.5)
  dowód: okno_dlugie: brak_ruchu 17 z 224 pościgów, bez_dojscia 18 (8%); trzymaj 223 pościgi; najgorsze pościgi: 5 z 6 to Troll z powodem brak_ruchu, kroki 0-7, odl 2-5, osiagalny=true, hp_gracza 100; dobicie 201/224 (90%).
  skutek: Około 8% pościgów nie dochodzi do celu, mimo że cel jest osiągalny i postać nie traci HP; cel zostaje żywy i pościg kończy się bez dobicia.
  propozycja: Rozważ w kodzie funkcję wykrywania brak_ruchu (próg czasu lub liczby kroków bez zmiany pozycji) oraz funkcję ponawiania ruchu (ponow_brak=25 w trzymaj): sprawdź, czy próg nie zrywa pościgu zbyt wcześnie albo czy ponowienie nie jest wysyłane w zablokowane pole. Kierunek do oceny przez człowieka: próg i logika ponowienia
- Przy trzymanym klawiszu postać często naciska klawisz, stojąc w miejscu, co może oznaczać wysyłanie ruchu w blokadę. (pewność 0.4)
  dowód: okno_dlugie trzymaj: naciski_z_postoju 133 na 223 pościgów (0.6 na pościg), trzymane_proc_czasu 90%; okno_krotkie: naciski_z_postoju 18 przy 69 pościgach.
  skutek: Część czasu pościgu idzie na naciski bez postępu, co wydłuża dojście do celu i zwiększa ryzyko brak_ruchu.
  propozycja: Funkcja wysyłania trzymanego klawisza kierunku: przed kolejnym naciśnięciem sprawdzić, czy następne pole jest wolne (ściana, inny potwór); kierunek do rozważenia: blokada wysyłania w zajęte pole zamiast ponawiania.
- Utknięcia w WALKA pojawiają się przy stałym obecności Jointoramix (stwór o nazwie z wartością 0), zwykle przy niskiej prędkości pola. (pewność 0.3)
  dowód: okno_dlugie utkniecia 6 (wszystkie z Jointoramix,0; pole v 12-16, krok_s 0.56-0.75); okno_krotkie 1 (v 20, krok_s 0.94); w 4 z 6 utknięć obok Troll 1-8 w pobliżu.
  skutek: Utknięcia wydłużają pościg, a niska prędkość pola obniża kroki_na_s (p10 0.96 wobec p90 2.51), co zwiększa szansę na przekroczenie czasu pętli.
  propozycja: Funkcja wyboru celu lub ścieżki: wykluczać cel, gdy inny potwór zajmuje pierwsze pole ścieżki (Jointoramix jako blokada); do oceny przez człowieka, czy filtr ma działać w funkcji celu czy w funkcji ścieżki.
- Porównanie trzymaj vs stuk nie daje wniosku, bo stuk ma tylko jeden pościg. (pewność 0.9)
  dowód: okno_dlugie: stuk n=1 (odrzucone_proc 25%, kroki_na_s 1.23), trzymaj n=223; roznice_trybow uwaga: ostrożnie.
  skutek: Brak podstaw, by ocenić, który tryb jest lepszy; jakiekolwiek wnioski z tej różnicy byłyby przypadkowe.
  propozycja: Brak zmiany kodu na tej podstawie; dopiero po zebraniu wystarczającej liczby pościgów w stuk.
- do zmierzenia: Czy brak_ruchu przy Trollu wynika z blokady ścieżki przez inny potwór: zapisywać, co stoi na pierwszym polu drogi w momencie zerwania pościgu.
- do zmierzenia: Czy naciski z postoju trafiają w zajęte pole: logować wynik każdego naciśnięcia (ruch / brak ruchu) i pole docelowe.
- do zmierzenia: Dla stuk: zebrać co najmniej 5 pościgów, aby ocenić różnicę z trzymaj.
- do zmierzenia: Skąd bierze się 98% w ostatnich_wnioskach, skoro dane pokazują 97% (krótkie) i 90% (długie): sprawdzić źródło liczenia.
- do zmierzenia: Co oznacza liczba 0 przy nazwie Jointoramix i wartość droga w najgorszych pościgach: potwierdzić definicje w kodzie statystyk.

## 2026-10-14 19:10 | uwaga | pościgów 5 min: 87, 30 min: 268
- Pościgi kończą się bez dojścia, gdy postać stoi przy trzymanym klawiszu, mimo że cel jest osiągalny. (pewność 0.6)
  dowód: Długie okno: brak_ruchu 17 z 268 pościgów (6,3%), 0 w oknie krótkim. Wśród 5 najgorszych pościgów wszystkie to trzymaj/brak_ruchu, kroki 0, 3, 7, 0, 0, z osiagalny=true i droga 0–7.
  skutek: Około 6–8% pościgów nie dociera do dobicia (17 brak_ruchu + 4 przerwane_inne z 268), a cel przy tym żyje.
  propozycja: Funkcja pętli ruchu pościgu, obsługa trzymanego klawisza: dodać licznik czasu bez zmiany pozycji przy trzymanym klawiszu (nowa stała np. CZAS_BEZ_RUCHU_TRZYMAJ) i po jej przekroczeniu zwolnienie klawisza oraz ponowne wyznaczenie kierunku. Kierunek do rozważenia przez człowieka.
- Przy trzymanym klawiszu postać wysyła wiele naciśnięć, stojąc w miejscu. (pewność 0.45)
  dowód: Długie okno: naciski_z_postoju 133 (0,5 na pościg), trzymane_proc_czasu 91%; krótkie okno: 17 naciśnięć z postoju na 87 pościgów (0,2 na pościg).
  skutek: Część ruchów nie przekłada się na kroki, więc czas pościgu rośnie bez postępu; w długim oknie kroki_na_s spada do 1,55 wobec 2,0 w krótkim.
  propozycja: Funkcja wysyłania ruchu (obsługa trzymania klawisza): sprawdzić, czy wysyłane kierunki wpadają w przeszkodę; stała określająca, po ilu nieudanych naciśnięciach zmieniać kierunek, do ustalenia po pomiarze. Kierunek: zmniejszyć liczbę powtórnych wysyłek w miejscu.
- Utknięcia w stanie WALKA pojawiają się przy obecności stwora Jointoramix na liście celów i przy niskiej prędkości pola. (pewność 0.4)
  dowód: Długie okno: 8 utknięć, w tym 6 podanych, wszystkie z Jointoramix (wartość 0); pole v=12–20, krok_s 0,56–0,94. Te same pozycje (32482,32293) i (32492,32289) powtarzają się w 3 przypadkach.
  skutek: Utknięcia wydłużają pościg, a w skrajnych przypadkach kończą go bez dojścia.
  propozycja: Logika wyboru ścieżki wokół stworów: rozważyć traktowanie pola zajętego przez inny stwór jako przeszkody (stała lub flaga w funkcji wyznaczania drogi). Kierunek do rozważenia przez człowieka.
- Dobicie spada z 99% w oknie krótkim do 92% w długim, a różnica wynika głównie z brak_ruchu. (pewność 0.5)
  dowód: Krótkie okno: dobicie 86/87 (99%), brak_ruchu 0; długie okno: dobicie 246/268 (92%), brak_ruchu 17, przerwane_inne 4.
  skutek: Długi horyzont pokazuje około 8% niedobicia, którego krótki nie wykrywa.
  propozycja: Brak zmiany kodu; monitorować wskaźnik dobicie_proc w dłuższych oknach, aby odróżnić szum od trendu.
- Zmiany kierunku na krok są częstsze w długim oknie, co może oznaczać przepinanie drogi przy przeszkodach. (pewność 0.25)
  dowód: zmiany_kierunku_na_krok: 0,26 w długim oknie wobec 0,11 w krótkim; w długim 58 zmian na 220 kroków.
  skutek: Każda zmiana kierunku może kosztować krok, co obniża kroki_na_s.
  propozycja: Funkcja przeliczania kierunku: sprawdzić, czy przeliczenie następuje tylko po zablokowaniu, a nie przy każdym kroku. Kierunek do rozważenia przez człowieka.

## 2026-10-14 19:12 | uwaga | pościgów 5 min: 91, 30 min: 285
- Brak_ruchu to główny powód nie-dobić: w oknie długim 19 z 24 nie-dobić, a różnica dobić między oknami (96% vs 92%) wynika z tego powodu. (pewność 0.55)
  dowód: okno_dlugie: brak_ruchu 19/285 (6.7%), okno_krotkie: 2/91 (2.2%); dobicie 261/285 (92%) vs 87/91 (96%). W 3 z 5 najgorszych pościgów kroki=0 lub 3 przy odl 2-5 (np. kroki 0, odl [4,5], droga 7; kroki 0, odl [2,4]).
  skutek: Około 6.7% pościgów kończy się bez dobicia po czasie stania (ok. 1.6-5.6 s na przypadek), a wszystkie najgorsze przypadki to Troll.
  propozycja: Funkcja pętli ruchu przy trzymanym klawiszu: dodać wykrycie kroki=0 przy trwającym trzymaniu i wymuszenie ponownego wyboru kroku/ścieżki zamiast czekania (opis do rozważenia przez człowieka, bez zmiany wartości stałych).
- Trzymany klawisz generuje wiele nacisków podczas postoju, zwłaszcza w długim oknie. (pewność 0.4)
  dowód: naciski_z_postoju: 143 w oknie długim (0.5 na pościg, 143/284 trzymaj), 22 w oknie krótkim (0.24 na pościg); trzymane_proc_czasu 91-92%.
  skutek: Nacisk trzymanego klawisza przy blokadzie może być zmarnowanym czasem; dane nie dowodzą, że to przyczyna brak_ruchu.
  propozycja: Funkcja obsługi trzymania klawisza: zwolnić klawisz po określonej liczbie kroków bez zmiany pozycji (nazwa stałej: licznik kroków bez postępu), do rozważenia.
- Utknięcia w stanie WALKA pojawiają się przy stworze Jointoramix na liście celów. (pewność 0.45)
  dowód: utkniecia: 9 w oknie długim, 3 w krótkim; wszystkie 6 unikalnych pokazanych wpisów zawiera Jointoramix (pole v 12-20, krok_s 0.56-0.94).
  skutek: Pościg stoi w miejscu i może być częścią brak_ruchu; wpływ ilościowy na 24 nie-dobicia nieznany.
  propozycja: Funkcja wyboru celu/wyznaczania ścieżki: traktować stwory niebędące celem na trasie jako przeszkody albo filtrować je przy wyborze celu pościgu.
- Zmiany kierunku są częste, ale bez oscylacji A-B-A-B, więc przyczyna nie jest jasna. (pewność 0.25)
  dowód: zmiany_kierunku_na_krok 0.30 (długie) i 0.33 (krótkie); oscylacje 0; odleglosc wzrosla w 9/285 pościgów (3%); kroki_na_s med 1.6 (długie) vs 2.0 (krótkie).
  skutek: Możliwe spowolnienie dojścia do celu, ale dowód jest słaby.
  propozycja: Dodać logowanie przyczyny zmiany kierunku w funkcji wyznaczania ścieżki, zanim zmieni się cokolwiek w kodzie.

## 2026-10-14 19:14 | uwaga | pościgów 5 min: 28, 30 min: 287
- Pościgi kończą się bez dobicia głównie przez brak ruchu postaci przy celu w odległości 3-5 pól, a nie przez zgubienie celu. (pewność 0.5)
  dowód: okno_dlugie: brak_ruchu=19 z 287 (6,6%), zgubienie=1; najgorsze_poscigi: 5 z 5 to brak_ruchu z kroki 0-7, odl [2..5], droga 0-7 (droga 7 > odl 5 przy 18:47:40); dwa kolejne pościgi z tej samej pozycji [32485,32298,9] o 18:47:40 i 18:47:42 (różnica 2 s)
  skutek: Ok. 19 pościgów z długiego okna (6,6%) nie dochodzi do dobicia, a przy stale zajętym miejscu część czasu cyklu idzie w próżnię.
  propozycja: Sprawdzić funkcję wyznaczania kroku/ścieżki w pościgu: gdy droga > odległość i ruch nie zmienia pozycji, czy przelicza trasę i czy kierunek trzymanego klawisza prowadzi przez przeszkodę. Do rozważenia: przeliczenie trasy po N próbkach bez zmiany pozycji (kierunek: wcześniej, nie później).
- Trzymany klawisz generuje naciski podczas postoju, co może być objawem blokady ruchu lub opóźnionego wyjścia z klawisza. (pewność 0.4)
  dowód: naciski_z_postoju: 144 w oknie długim (0,5 na pościg) i 21 w krótkim (0,75 na pościg); trzymane_proc_czasu 91% (długie) i 96% (krótkie); zmiany_kierunku_na_krok 0,29
  skutek: Możliwe marnowanie czasu i ruchów, które nie przekładają się na przemieszczenie; związku z brak_ruchu nie da się jeszcze potwierdzić, bo dane nie rozdzielają naciśków w brak_ruchu od reszty.
  propozycja: Dodać rozbicie naciśków z postoju według powodu wyjścia. W funkcji obsługi trzymania klawisza rozważyć zwolnienie klawisza po N próbkach bez zmiany pozycji (kierunek: krócej trzymać przy zablokowanym kroku).
- Utknięcia w stanie WALKA mogą zależeć od prędkości pola, ale próba jest za mała, żeby to ustalić. (pewność 0.25)
  dowód: utkniecia długie: 8, z tego 4 z 6 ostatnich przy pole.v=12 (krok_s 0,56), pozostałe v=16 i v=20; wszystkie z Jointoramix w liście celów
  skutek: Wolniejsze dojście do celu na niektórych polach; obecne dane nie wystarczają do oceny skali.
  propozycja: Rozważyć, czy stała progu oczekiwania na krok powinna zależeć od krok_s pola (do sprawdzenia, nie jako zmiana gotowa do wdrożenia).
- Porównanie trzymaj vs stuk nie jest rozstrzygające, bo stuk wystąpił tylko raz. (pewność 0.2)
  dowód: roznice_trybow: stuk n=1, kroki_na_s_med trzymaj 1,79 vs stuk 1,23, odrzucone_proc stuk 25% (1 próba); okno krótkie: trzymaj n=28, stuk brak
  skutek: Brak podstaw do wyboru trybu; obecna przewaga trzymaj wynika z jednego pościgu w stuk.
  propozycja: Zebrać co najmniej 5 pościgów w trybie stuk przed jakimkolwiek wnioskiem o wyborze trybu.
- Częste zmiany kierunku przy pościgu nie prowadzą do oscylacji A-B-A-B, więc nie są główną przyczyną nieskuteczności. (pewność 0.3)
  dowód: zmiany_kierunku_na_krok: trzymaj 0,29 (długie), 0,35 (krótkie); oscylacje liczba 0 w obu oknach; bez_postepu 2 pościgi, 10 kroków
  skutek: Korekty kierunku kosztują część kroków, ale nie zapętlają ruchu; dobicie 92% (długie) i 89% (krótkie).
  propozycja: Brak zmiany do czasu zebrania danych o tym, czy zmiany kierunku pojawiają się przy przeszkodach (droga > odl).
- do zmierzenia: Czy brak_ruchu skupia się na konkretnych polach mapy: zebrać pozycje gracza i celu przy każdym brak_ruchu i policzyć powtórki (np. [32485,32298,9]).
- do zmierzenia: Czy naciski z postoju występują wyłącznie w stanie brak_ruchu: rozbić je według powodu wyjścia.
- do zmierzenia: Czy komenda ruchu dochodzi do serwera: porównać liczbę wysłanych kroków z faktycznie zmienioną pozycją w przypadkach brak_ruchu przy osiagalny=true.
- do zmierzenia: Czy utknięcia przy v=12 są częstsze niż przy v=16/20: policzyć proporcję utknięć do wszystkich pościgów dla każdej wartości pola, nie tylko do ostatnich 6.
- do zmierzenia: Co oznacza ponow_brak (27 w długim oknie): ile ponowień prowadzi do faktycznego ruchu.

## 2026-10-14 19:16 | uwaga | pościgów 5 min: 31, 30 min: 287
- Najczęstsza nieudana pętla to brak_ruchu: postać stoi, a cel (Troll) pozostaje w odl 2-5, mimo że osiągalny=true. (pewność 0.5)
  dowód: okno_dlugie: brak_ruchu 18/287 (6,3%), bez_dojscia 18; wszystkie 5 najgorszych pościgów to Troll z brak_ruchu, kroki 0-3, czas 1,6-3,5 s, hp_gracza 100, stan WALKA; naciski_z_postoju 139 (0,49 na pościg).
  skutek: Około 6% pościgów kończy się bez dobicia, a cel zostaje z 8-24 HP; w oknie krótkim ta sama przyczyna dała 2 z 31 pościgów.
  propozycja: Funkcja decydująca o wyjściu z pościgu z powodem brak_ruchu: rozważyć wydłużenie progu czasu bez zmiany pozycji oraz sprawdzenie, czy przed wyjściem uwzględniane jest zajęte pole na drodze (inny stwór). Kierunek: dłuższe okno bez ruchu lub warunek blokady zamiast natychmiastowego wyjścia.
- Utknięcia w stanie WALKA koncentrują się przy jednym obszarze, gdzie martwy według odczytu Jointoramix (hp 0) stoi obok Trolla. (pewność 0.4)
  dowód: utkniecia.liczba 8; wszystkie wpisy: stan WALKA, Jointoramix hp 0, Troll w odl 1-6; pozycje powtarzają się (32482,32293 x2; 32492,32289/32290); pole v 12-20, krok_s 0,56-0,94; czas utknięcia 16-26 s.
  skutek: Każde utknięcie to ok. 16-26 s bez postępu; w 8 przypadkach stracono czas na celu, który według odczytu już nie żyje.
  propozycja: Funkcja wyboru celu w pościgu/walce: sprawdzić, czy cel z hp 0 jest porzucany lub przełączany, gdy inny stwór blokuje drogę. Kierunek: pominąć cel z hp 0 przy wyborze następnego celu.
- Klawisz trzymany w pościgu bywa wciśnięty przy stojącej postaci, co może współtworzyć brak_ruchu, ale dane nie łączą tych zdarzeń na poziomie pojedynczego pościgu. (pewność 0.3)
  dowód: naciski_z_postoju 139 w oknie długim (0,49 na pościg) i 22 w krótkim (0,71 na pościg); trzymane_proc_czasu 90%; zmiany_kierunku_na_krok 0,28.
  skutek: Jeśli klawisz jest trzymany przy blokadzie, postać nie rusza, a pościg kończy się brak_ruchu; wpływ nie jest jeszcze potwierdzony.
  propozycja: Funkcja obsługi trzymania klawisza: sprawdzić, czy trzymanie jest zwalniane po wykryciu braku zmiany pozycji. Kierunek: zwolnić klawisz po zatrzymaniu, a następnie wznowić.
- do zmierzenia: Dla każdego pościgu brak_ruchu zapisać liczbę naciśnięć z postoju oraz to, czy na drodze stoi inny stwór, aby sprawdzić korelację z 18 przypadkami.
- do zmierzenia: Wyjaśnić, dlaczego w najgorszych pościgach droga=0 lub 2 przy osiagalny=true i odl 2-4 (czy pole droga oznacza długość ścieżki, czy odległość do blokady).
- do zmierzenia: Sprawdzić, czy hp 0 dla Jointoramix to nieaktualny odczyt, mierząc znacznik czasu odczytu hp względem ruchu postaci.
- do zmierzenia: Zebrać bazę porównawczą prędkości pola (v) dla pościgów zakończonych dobiciem i brak_ruchu, bo obecne dane mają v tylko dla przypadków problemowych.
- do zmierzenia: Zebrać więcej pościgów w trybie stuk (obecnie n=1, z 1 odrzuceniem), zanim porówna się trzymaj i stuk.

## 2026-10-14 19:19 | uwaga | pościgów 5 min: 21, 30 min: 278
- Pościgi kończą się brak_ruchu, gdy postać stoi, a cel (Troll) jest w odl 2-5 i osiągalny, mimo że klawisz trzymany był wciśnięty. (pewność 0.5)
  dowód: okno_dlugie: brak_ruchu 6 z 278 pościgów (2,2%); najgorsze pościgi: Troll odl [3,4], kroki 3 w 3,13 s, droga 2, osiagalny=true; Troll odl [2,4], kroki 0, droga 0; trzymane_proc_czasu 89, naciski_z_postoju 117 (0,42 na pościg).
  skutek: Około 2% pościgów kończy się bez dobicia, a cel pozostaje żywy; przy 6 zdarzeniach w 30 min to niewielki, ale powtarzalny koszt.
  propozycja: Funkcja detekcji brak_ruchu (próg czasu bez zmiany pozycji przy wciśniętym klawiszu trzymaj): rozważyć dłuższy próg lub wykrycie blokady drogi przed uznaniem braku ruchu; sprawdzić, czy przy droga=0 pathing nie zwraca pustej ścieżki.
- Utknięcia w stanie WALKA dotyczą martwego potwora (Jointoramix hp 0) stojącego obok Trolla, a nie pościgu za celem. (pewność 0.45)
  dowód: utkniecia: 8 w oknie długim, 1 w krótkim; we wszystkich wpisach w stwory występuje Jointoramix z hp 0; pole v 12-20, krok_s 0,56-0,94.
  skutek: Postać traci czas w walce z trupem zamiast gonić żywy cel; zajmuje to kilkanaście sekund na zdarzenie (s 16-26).
  propozycja: Filtr celów w stanie WALKA: pomijać potwory z odczytem hp 0 przy wyborze następnego celu lub przy wykrywaniu utknięcia (funkcja wyboru celu/odczytu HP).
- Porównanie trzymaj vs stuk nie daje wiarygodnego wniosku, bo tryb stuk wystąpił tylko raz. (pewność 0.2)
  dowód: roznice_trybow: n trzymaj 277, stuk 1; kroki_na_s_med 1,7 vs 1,23; odrzucone_proc stuk 25 (1 z 4 wysłanych); uwaga pliku: mało pościgów na tryb.
  skutek: Nie da się ocenić, czy stuk jest gorszy lub lepszy; odrzucenia 25% w stuk to jedna próbka.
  propozycja: Brak zmiany w kodzie na podstawie tych danych; zebrać więcej pościgów w trybie stuk, zanim rozważy się zmianę trybu.
- Pościgi są skuteczne: dobicie wysokie, zgubienia rzadkie, a odległość końcowa spada. (pewność 0.7)
  dowód: okno_dlugie: dobicie 266/278 (96%), zgubienie 2 (1%), delta_med odległości -1,0 (start 2,0, koniec 1,0), bez_postepu 1 pościg; okno krótkie: dobicie 90%, zgubienie 5%.
  skutek: Około 4% pościgów nie kończy się dobiciem (brak_ruchu, zgubienie, przerwanie), co jest akceptowalnym kosztem przy tym poziomie skuteczności.
  propozycja: Brak zmiany; monitorować, czy udział brak_ruchu i utknięć nie rośnie.

## 2026-10-14 19:21 | uwaga | pościgów 5 min: 57, 30 min: 315
- Pościgi kończą się bez dojścia głównie przy celach Troll w odległości 2-6 pól, gdzie postać stoi lub robi 0-3 kroki, mimo że ścieżka jest osiągalna. (pewność 0.5)
  dowód: okno_dlugie: brak_ruchu=8 z 315 pościgów (2,5%), a 'bez_dojscia' łącznie 8; w najgorszych_poscigach 4 z 5 to brak_ruchu przy Trollu (kroki 0-3, droga 0-5, osiagalny=true, hp_gracza 100); wzrosla_pościgow=6, czyli koniec dalej niż start.
  skutek: Około 2,5% pościgów nie kończy się dobiciem; cel przy tym zostaje przy życiu, a postać traci czas w WALKA/POGON.
  propozycja: Sprawdzić stałą progu czasu, po którym pościg uznaje 'brak_ruchu' (np. nazwa typu PROG_BRAK_RUCHU_S), i funkcję wysyłania kroku przy znanej ścieżce; rozważyć wydłużenie progu lub ponowne wyznaczenie ścieżki przed ogłoszeniem brak_ruchu. Nie skracać pościgu.
- Klawisz trzymany bywa przytrzymany przy stojącej postaci: część naciśnięć nie daje ruchu. (pewność 0.45)
  dowód: okno_dlugie trzymaj: naciski_z_postoju=118 w 314 pościgach (0,38 na pościg), trzymane_proc_czasu=89%; okno_krotkie: 16 naciśnięć z postoju przy 0,28 na pościg; kroki_na_s med 1.64 przy p10 1.02.
  skutek: Trzymany klawisz przy zablokowanej postaci nie przesuwa jej, więc część czasu pościgu idzie w pusty ruch i dokłada się do brak_ruchu.
  propozycja: W funkcji obsługi trzymania klawisza (pętla pościgu) dodać warunek zwolnienia klawisza, gdy pozycja nie zmieniła się przez określony czas lub liczbę ticków; nazwać i opisać stałą progu zwolnienia do rozważenia przez człowieka.
- Utknięcia w stanie WALKA występują przy martwym potworze stojącym obok celu, a nie przy samym ściganym celu. (pewność 0.4)
  dowód: okno_dlugie utkniecia: liczba=7 z 315 pościgów (2,2%); we wszystkich wpisach stwór Jointoramix z drugim polem 0 (wnioskowane hp=0), obok Trolla lub Orca; pole v 12-20, krok_s 0,56-0,94.
  skutek: Postać traci kroki na walkę z martwym celem lub omijanie go, zamiast gonić żywy cel; wpływa to na czas dobicia.
  propozycja: Sprawdzić funkcję wyboru celu pościgu: dodać filtr odrzucający cele z hp=0 (lub martwe) przed wyborem kolejnego celu; w kodzie wskazać miejsce, gdzie cel jest wybierany spośród stworów w pobliżu.
- Trasa zmienia kierunek średnio co około 3 kroki, co może zjadać kroki bez postępu w stronę celu. (pewność 0.3)
  dowód: okno_dlugie trzymaj: zmiany_kierunku=68, zmiany_kierunku_na_krok=0,29; okno_krotkie: 0,42; kroki_na_s p10=1,02 przy med=1,64; oscylacje A-B-A-B: 0.
  skutek: Część kroków idzie w bok lub w tył, co wydłuża dojście do celu w pościgach z dłuższym czasem; brak dowodu na zgubienia z tego powodu (zgubienia 2 z 315).
  propozycja: Sprawdzić funkcję wyliczania kierunku/ścieżki w pościgu i rozważyć dodanie histerezy (np. stałą minimalnej zmiany kierunku przed przeliczeniem); do potwierdzenia przez pomiar, czy zmiany kierunku koreluje z dłuższym czasem dobicia.
- do zmierzenia: Logować na każdym ticku: czy klawisz jest trzymany, czy pozycja się zmieniła, i czas od ostatniej zmiany pozycji; to rozstrzygnie, czy brak_ruchu to zablokowany klawisz, czy błędna ścieżka.
- do zmierzenia: Dla przypadków brak_ruchu przy Trollu zapisać, czy na ścieżce (droga) stoi przeszkoda lub inny stwór, bo droga 2-5 przy kroki 0-3 wygląda na niedrożność trasy.
- do zmierzenia: Zapisać hp wybranego celu w chwili wyboru, aby potwierdzić, czy pościg zaczyna się od martwego stwora (Jointoramix hp=0).
- do zmierzenia: Zdefiniować i zalogować, co oznacza pole 'v' i 'krok_s' (prędkość pola czy postaci), żeby sprawdzić, czy utknięcia korelują z wolnym polem.
- do zmierzenia: Zebrać więcej pościgów trzymaj vs stuk (obecnie stuk n=1), zanim wyciągnie się wniosek o różnicach trybów.

## 2026-10-14 19:23 | uwaga | pościgów 5 min: 53, 30 min: 314
- Pościg zwykle kończy się dobiciem, ale w 116 z 313 pościgów (trzymaj) klawisz był wciskany, gdy postać stała w miejscu. (pewność 0.5)
  dowód: okno_dlugie: naciski_z_postoju=116 przy trzymane_proc_czasu=92, czyli 0.37 naciśnięcia z postoju na pościg; okno_krotkie: naciski_z_postoju=16 na 53 pościgi (0.3).
  skutek: Część czasu trzymania nie daje ruchu, więc każdy pościg traci kilka kroków i czas, zanim cel zostanie dobity.
  propozycja: Funkcja obsługi trzymania klawisza (wysyłanie kroku w pętli pościgu): dodać sprawdzenie zmiany pozycji przed ponownym naciśnięciem tego samego kierunku; kierunek: mniej powtórnych naciśnięć, gdy pozycja nie zmieniła się od poprzedniego naciśnięcia.
- Najgorsze pościgi zakończone brakiem ruchu mają ścieżkę osiągalną, a postać mimo to nie zrobiła kroku. (pewność 0.45)
  dowód: najgorsze_poscigi: 3 z 5 mają powod=brak_ruchu, osiagalny=true, kroki 0-3, odl 3-4 lub 5-6, droga 2 lub 5; okno_dlugie: brak_ruchu=7 z 314 pościgów (2.2%).
  skutek: Cel uciekający w tym czasie może się oddalić, a pętla wychodzi bez dobicia (bez_dojscia 7 w długim oknie).
  propozycja: Funkcja wyznaczania ścieżki do celu: uwzględnić pola zajęte przez martwe potwory lub zwłoki jako blokady i wymusić przeliczenie trasy po braku ruchu; kierunek: przeliczać trasę po pierwszym kroku bez zmiany pozycji.
- Utknięcia w stanie WALKA pojawiają się, gdy obok celu stoi martwy potwór (hp 0). (pewność 0.4)
  dowód: okno_dlugie: utkniecia=8, wszystkie z wpisem Jointoramix hp 0 w stwory; okno_krotkie: 2 z 2 z tym wpisem; pole v 12-20, krok_s 0.56-0.94.
  skutek: Postać stoi przy martwym potworze i traci czas na dojście do celu; w danych 8 utknięć w 1800 s.
  propozycja: Funkcja filtrowania przeszkód przy wyborze kroku w WALCE: traktować pole z martwym potworem jako zajęte; kierunek: nie wybierać pola z martwym potworem jako kroku.
- Trasa zmienia kierunek średnio co 3-4 kroki, a część kroków nie zbliża do celu. (pewność 0.3)
  dowód: okno_dlugie: zmiany_kierunku=67 na 231 kroków (0.29 na krok); okno_krotkie: 0.35 na krok; oscylacje=0, bez_postepu=3 kroki w 1 pościgu.
  skutek: Każda zmiana kierunku może oznaczać krok, który nie skraca dystansu, co obniża efektywną prędkość pościgu (kroki_na_s med 1.7 przy tempie tryb 1.92).
  propozycja: Funkcja obliczania kierunku trasy: dodać wygładzanie ścieżki (preferować kierunek poprzedniego kroku, gdy dystans się nie zmienia); kierunek: mniej zmian kierunku na krok.
- Tryb stuk ma wyraźnie gorsze wskaźniki odrzuceń i opóźnień niż trzymaj, ale próba to jeden pościg. (pewność 0.2)
  dowód: roznice_trybow: stuk n=1, odrzucone_proc 25 vs 0 (trzymaj), dec_med_s 0.109 vs 0.0, kroki_na_s_med 1.23 vs 1.7.
  skutek: Gdyby stuk był używany częściej, mógłby odrzucać kroki i spowalniać pościg; obecnie brak wiarygodnych danych, by to stwierdzić.
  propozycja: Brak zmiany w kodzie na podstawie tej próby; rozważyć dalsze zbieranie danych przed decyzją o trybie stuk.
- do zmierzenia: Czy naciśnięcia z postoju zbiegają się z pozycjami zajętymi przez zwłoki (hp 0) lub inne potwory na ścieżce?
- do zmierzenia: Ile kroków zajmuje odzyskanie ruchu po brak_ruchu i czy trasa przelicza się po pierwszym nieudanym kroku?
- do zmierzenia: Jaki procent kroków w pościgu zmniejsza dystans do celu, a jaki go nie zmienia (przy zmianach kierunku i bez)?
- do zmierzenia: Zebrać więcej pościgów w trybie stuk (obecnie n=1), aby ocenić odrzucenia i opóźnienia.

## 2026-10-14 19:25 | uwaga | pościgów 5 min: 50, 30 min: 302
- Pościgi kończą się dobiciem w 95%, ale około 4,6% (brak_ruchu, przerwane, zgubienie) nie kończy się dobiciem, a większość tych porażek to brak ruchu przy Trollach. (pewność 0.6)
  dowód: Okno długie: dobicie 288/302 (95%), zgubienie 2, bez_dojscia_okno_lub_brak_ruchu 7, przerwane_inne 5. Z 5 najgorszych pościgów 3 to Troll (hp 14 i 28) z powodem brak_ruchu, kroki 0-3, odl 3-6.
  skutek: Około 14 pościgów na 302 kończy się bez dobicia, a cel ucieka lub zostaje zgubiony.
  propozycja: Przejrzeć stałą progu czasu bez zmiany pozycji, po którym pętla zgłasza brak_ruchu, oraz logikę, która decyduje o wyjściu z pościgu w stanie WALKA. Do rozważenia przez człowieka: czy próg nie zrywa pościgu zbyt wcześnie, gdy postać chwilowo stoi przy Trollu.
- Trzymany klawisz w trybie trzymaj często jest naciskany ponownie, gdy postać już stoi. (pewność 0.35)
  dowód: Okno długie, trzymaj: naciski_z_postoju 110 (0,37 na pościg), trzymane_proc_czasu 91%, brak_ruchu w 7 pościgach. Okno krótkie: naciski_z_postoju 12 przy trzymane 100%.
  skutek: Część naciśnięć nie przesuwa postaci, co może wydłużać pościg i przyczyniać się do brak_ruchu.
  propozycja: Funkcja wysyłania klawisza kierunku w pętli pościgu: nie wysyłać ponownego naciśnięcia w ten sam kierunek, dopóki pozycja się nie zmieni (lub zmieniać częstotliwość ponawiania). Do rozważenia przez człowieka, czy to jest faktyczna przyczyna.
- Trasa zmienia kierunek średnio co 3-4 kroki, co nie tworzy oscylacji, ale może zjadać kroki. (pewność 0.3)
  dowód: zmiany_kierunku_na_krok 0,30 w oknie długim (62 zmiany na 207 kroków); oscylacje A-B-A-B: 0 w obu oknach; odległość koniec_med 1,0 vs start_med 2,0.
  skutek: Częste zmiany kierunku mogą wydłużać dojście do celu, choć pościgi są skuteczne.
  propozycja: Funkcja wyznaczania trasy: rzadziej przeliczać trasę (np. trzymać kierunek do zmiany pozycji celu o więcej niż 1 pole). Kierunek zmiany do rozważenia przez człowieka.
- do zmierzenia: Czy utknięcia i brak_ruchu zdarzają się częściej, gdy w promieniu 2 pól od celu stoi inny żywy potwór? Zmierzyć liczbę żywych potworów wokół celu w każdym pościgu.
- do zmierzenia: Czy hp stworów w utknięciach (zwłaszcza Jointoramix, indeks 0) jest 0? Obecne dane tego nie pokazują, więc poprzedni wniosek o martwym potworze nie jest potwierdzony.
- do zmierzenia: Tryb stuk ma tylko 1 pościg (n=1), więc odrzucone 25% i wyższe opóźnienia nie pozwalają na wniosek. Zebrać co najmniej 5 pościgów w tym trybie.
- do zmierzenia: Czy naciski_z_postoju korelują z brak_ruchu? Zmierzyć, ile z 110 naciśnięć poprzedza pościgi zakończone brak_ruchu.

## 2026-10-14 19:27 | uwaga | pościgów 5 min: 31, 30 min: 316
- Pościgi utykają w stanie WALKA, gdy w pobliżu celu stoją inne potwory, a ścieżka do celu jest nadal osiągalna. (pewność 0.5)
  dowód: Okno długie: 8 utknięć, wszystkie w WALKA, każde z innymi potworami obok celu (Jointoramix ×6, Troll ×4, Orc ×1). Najgorsze pościgi: 3 z 5 to Troll z powodem brak_ruchu, odl 3-4 lub 2-4, osiagalny=true, droga 0-5, ocena_zlego 4.2-6.7.
  skutek: Brak ruchu przy celu 2-4 pola dalej kosztuje dobicie i czas; w oknie długim to 6 wyjść bez dojścia (2%) i 6 kroków bez postępu w jednym pościgu.
  propozycja: Funkcja wyznaczania kroku/ścieżki pościgu: traktować pola zajęte przez inne potwory jako blokady (lub dodać stałą kary za sąsiedztwo innych potworów) i zamiast czekać, przeliczać trasę po wykryciu blokady. Kierunek: więcej uwzględnienia innych potworów w planowaniu, mniej ślepego trzymania kierunku.
- Zgubienie celu (cel_znikl) występuje rzadko i wiąże się z wysoką latencją odczytu w danym pościgu. (pewność 0.25)
  dowód: Okno długie: zgubienie 2 z 316 (1%), oba cel_znikl; w najgorszym przypadku cel_znikl (Orc hp 8) lat_med 1.528 s przy kroki_na_s 1.18 i droga 0. Okno krótkie: zgubienie 0 z 31.
  skutek: Każde zgubienie to utracone dobicie; przy 2 przypadkach nie da się wiarygodnie ustalić przyczyny.
  propozycja: Stała czasu ponownego namierzenia celu (timeout po zniknięciu z odczytu): rozważyć zwiększenie, żeby krótkie opóźnienia odczytu nie kończyły pościgu. Kierunek: wydłużyć okno przed uznaniem cel_znikl.
- Pościgi z kierunkiem zmieniającym się często zjadają kroki, ale nie tworzą oscylacji. (pewność 0.3)
  dowód: Okno długie: zmiany_kierunku_na_krok 0.33 (krótkie 0.46), oscylacje 0, bez_postepu 1 pościg (6 kroków), delta_med odległości -1.0, kroki_na_s med 1.79 (p10 1.02, p90 2.51).
  skutek: Część kroków idzie w bok lub w zawracanie, co wydłuża dojście; wpływ na wynik dobicia jest niewielki (96%).
  propozycja: Funkcja wyboru kierunku: preferować ścieżkę z mniejszą liczbą zmian kierunku przy równym koszcie (np. kara za zmianę kierunku w funkcji kosztu trasy). Kierunek: mniej zmian na krok.
- do zmierzenia: Czy utknięcia częściej występują, gdy w promieniu 2 pól od celu stoi inny potwór — policzyć odsetek pościgów z innymi potworami obok, z podziałem na brak_ruchu vs dobicie.
- do zmierzenia: Czy tryb stuk daje mniej utknięć przy innych potworach — dane nie zawierają trybu stuk, więc porównanie trzymaj vs stuk wymaga zebrania pościgów z oboma trybami.
- do zmierzenia: Czy ponowne naciśnięcia z postoju poprzedzają brak_ruchu — zmierzyć, ile pościgów z ponow_brak kończy się brak_ruchu.
- do zmierzenia: Czy cel_znikl koreluje z lat_med > 1 s — zebrać więcej zgubień (obecnie 2) i porównać latencję przed zgubieniem z latencją w udanych pościgach.

## 2026-10-14 19:29 | uwaga | pościgów 5 min: 85, 30 min: 357
- Pościgi utykają, gdy inne stwory (Jointoramix, Troll, Orc) stoją na drodze do celu, zwłaszcza w stanie WALKA. (pewność 0.6)
  dowód: utkniecia.liczba=8 w oknie długim, wszystkie w stanie WALKA z 1-2 stworami w pobliżu; powody brak_ruchu=7 i bez_dojscia=8; najgorszy pościg 19:25:13: brak_ruchu przy odl [3,4], droga 3, osiagalny=true, zmiany_kier=6, 6 kroków w 6.64 s.
  skutek: Około 2,2% pościgów (8 z 357) kończy się bez dojścia do celu, a postać traci czas na kręcenie się przy blokadzie.
  propozycja: Funkcja wyznaczania kroku pościgu: uwzględnić pola zajęte przez inne stwory z listy stwory przy wyborze ścieżki (omijanie zajętych pól zamiast trzymania kierunku). Do rozważenia przez człowieka.
- Klawisz w trybie trzymaj jest często naciskany, gdy postać już stoi, a odczyt pozycji jest opóźniony względem ruchu. (pewność 0.5)
  dowód: naciski_z_postoju=109 w oknie długim (0.31 na pościg), 20 w krótkim; lat_med_s=0.5 przy krok_s=0.56, czyli odczyt jest około 0,9 kroku za rzeczywistością; trzymane_proc_czasu=89.
  skutek: Nadmiarowe naciski mogą powodować przestrzelenie i dodatkowe ruchy, choć dobicie nadal wynosi 96%.
  propozycja: Funkcja pętli pościgu: skrócić dopuszczalny wiek odczytu pozycji przed decyzją o trzymaniu klawisza (stała świeżości odczytu) albo zwalniać klawisz, gdy cel jest w odl<=2, zanim pojawi się nowy odczyt. Do rozważenia przez człowieka.
- Zgubienia celu są rzadkie, a dominujący powód zgubienia różni się między oknami. (pewność 0.3)
  dowód: koniec.zgubienie=2 (1%) w oknie długim i 0 w krótkim; epizody_celu.powod_top: 'odpuszczony za ścianą' (długie) vs 'zniknął z widoku żywy' (krótkie); zgubione=1 w każdym oknie.
  skutek: Obecnie mały koszt; przy większej próbie może być widoczne, że cel za ścianą znika z widoku.
  propozycja: Funkcja wykrywania zniknięcia celu: sprawdzić, czy zgubienia za ścianą wymagają dłuższego okna szukania (stała czasu szukania). Do rozważenia przez człowieka.
- do zmierzenia: Czy przy każdym brak_ruchu na ścieżce jest zajęte pole (sprawdzić zajętość pól na trasie w chwili utknięcia)?
- do zmierzenia: Czy naciski z postoju pojawiają się głównie tuż po zmianie pozycji celu (zrównać znaczniki czasu odczytu pozycji z wysłaniem klawisza)?
- do zmierzenia: Czy zgubienia (cel_znikl) korelują z lat_med_s powyżej 0.5 s w tym samym pościgu?
- do zmierzenia: Ile pościgów w trybie stuk jest potrzebnych, żeby różnica odrzuceń i latencji była rozstrzygalna (przynajmniej n≥5 na tryb)?

## 2026-10-14 19:31 | uwaga | pościgów 5 min: 88, 30 min: 339
- Klawisz trzymaj jest wciśnięty z postoju w około jednej trzeciej pościgów, co wskazuje na opóźnienie odczytu pozycji, a nie na błąd decyzji. (pewność 0.6)
  dowód: okno_dlugie: naciski_z_postoju=111 przy 339 pościgach (0,33 na pościg), trzymane_proc_czasu=90, lat_med_s=0,484 przy dec_med_s=0,0; okno_krotkie: 24 naciski z postoju, 0,28 na pościg.
  skutek: Część kroków to ruch bez postępu (13 kroków bez postępu w 3 pościgach długiego okna) i 0,37 zmiany kierunku na krok, co wydłuża dojście do celu. Dobicie mimo to wynosi 94%, więc koszt jest umiarkowany
  propozycja: Funkcja zwalniania klawisza trzymaj: uwzględnić czas opóźnienia odczytu pozycji (lat_med ~0,5 s), np. przez stałą progu odległości, przy której klawisz jest zwalniany wcześniej (kierunek: większy margines przy odl<=2). Nazwę stałej ustalić w kodzie.
- Pościgi kończące się brak_ruchu i utknięcia występują prawie wyłącznie przy niskiej prędkości pola (v=12), co sugeruje, że ograniczeniem jest teren, a nie logika celu. (pewność 0.4)
  dowód: najgorsze_poscigi: 5 z 5 ma pole.v=12 i krok_s=0,56, wszystkie z powodem brak_ruchu lub zawracanie; okno_dlugie utkniecia: 9, z czego 4 przy v=12 (krok_s 0,56) i pozostałe przy v=14-16; średni kroki_na_s w oknie długim wynosi 1,67.
  skutek: Pościg na wolnym polu trwa dłużej i częściej się zatrzymuje. Liczba przypadków jest mała (n=5 w najgorszych), więc wniosek ma niską pewność.
  propozycja: Timeout/warunek brak_ruchu: skalować okno czasu bez ruchu odwrotnie do pole.krok_s (wolniejsze pole → dłuższe okno przed uznaniem braku ruchu). Nazwa funkcji do ustalenia w kodzie.
- Utknięcia w stanie WALKA koncentrują się w tych samych współrzędnych i zawsze w obecności Jointoramix oraz Trolli, co może oznaczać blokowanie ścieżki przez inne stwory. (pewność 0.4)
  dowód: okno_dlugie utkniecia: 9 (2,7% pościgów), wszystkie stan=WALKA; pozycja [32482,32296,9] występuje dwa razy (19:11:44 i 19:30:12); w każdym wpisie obecny Jointoramix, a Trolle w 5 z 6 ostatnich wpisów; okno_krotkie: 1 utknięcie.
  skutek: Pościg zatrzymuje się na kilkanaście-kilkadziesiąt sekund przy każdym takim utknięciu; przy 9 przypadkach w 30 minutach to kilka minut straconego czasu łącznie.
  propozycja: Funkcja wyznaczania ścieżki w stanie WALKA: traktować pola zajęte przez inne stwory jako nieprzejezdne przy planowaniu kroku (kierunek: dodać omijanie zajętych pól). Pole Jointoramix ma w danych wartość 0, której znaczenia nie da się ustalić z logu.
- Tryb stuk odrzuca prawie połowę wysłanych poleceń, a jego porównanie z trzymaj jest niemożliwe do rozstrzygnięcia z powodu małej próby. (pewność 0.3)
  dowód: stuk: n=2, wyslane=13, odrzucone=6 (46%), ponow_brak=5, lat_med_s=0,128; trzymaj: n=337, odrzucone=0; roznice_trybow.uwaga: 'mało pościgów na tryb'.
  skutek: Jeśli stuk jest używany, traci około połowy wysłanych kroków, a wynik trybu nie pozwala ocenić, czy w ogóle warto go używać.
  propozycja: Logika wyboru trybu (trzymaj/stuk): nie zmieniać, dopóki stuk nie ma co najmniej 30 pościgów; wtedy ocenić próg odrzuceń w funkcji wyboru trybu.
- do zmierzenia: Czas od odl<=1 do zwolnienia klawisza trzymaj w każdym pościgu: czy naciski z postoju mieszczą się w czasie opóźnienia odczytu pozycji (~0,5 s).
- do zmierzenia: Czy pozycja z odczytu odpowiada pozycji po ruchu, czyli czy wpis 'brak_ruchu' pojawia się przy poprawnym dojściu.
- do zmierzenia: Korelacja utknięć i brak_ruchu z pole.v dla wszystkich pościgów (nie tylko najgorszych) w dłuższym oknie.
- do zmierzenia: Znaczenie wartości 0 w polu 'stwory' (np. HP%, dystans, czy stan) — bez tego nie da się ocenić blokowania przez Jointoramix.
- do zmierzenia: Powód odrzucenia poleceń w trybie stuk (np. zajęty klawisz, zbyt szybkie wysyłanie) przy co najmniej 30 pościgach stuk.

## 2026-10-14 19:33 | uwaga | pościgów 5 min: 70, 30 min: 333
- Zgubienia pościgu skupiają się w ostatnich 300 s okna; poza nim są rzadkie. (pewność 0.5)
  dowód: Okno krótkie: 15 zgubień z 70 pościgów (21%). Okno długie: 17 zgubień z 333 (5%). Jeśli okno krótkie jest końcówką długiego, poza nim zostały 2 zgubienia na 263 pościgi (<1%). Wszystkie zgubienia to cel_znikl (15/15 i 17/17).
  skutek: W ostatnich 5 minutach traci się 21% dobić zamiast ~5% średnio; dobicie spada do 70% przy 89% w całym oknie.
  propozycja: Zbadać obsługę cel_znikl w funkcji wyboru/śledzenia celu przy wielu stworach w pobliżu (np. stała timeoutu lub progu odległości, po której cel uznawany jest za zniknięty). Kierunek do rozważenia: czy próg nie jest za krótki, gdy cel jest tymczasowo zasłonięty przez inne stwory.
- Najgorsze pościgi to wszystkie pościgi za Trollem, w których postać stała w miejscu lub zawracała, mimo że cel był osiągalny. (pewność 0.4)
  dowód: Wszystkie 6 pościgów z najgorsze_poscigi to Troll (hp_celu 16-28), odl 2-6, kroki 2-6, osiagalny=true, powody: brak_ruchu x2, okno, zawracanie. Wszystkie z przedziału 19:20-19:28, czyli w końcówce okna.
  skutek: Pościgi zajmują czas bez dobicia i kończą się brakiem dojścia lub zgubieniem.
  propozycja: Sprawdzić funkcję wyznaczania kroku/ścieżki w WALKA: czy przy zajętych polach przez inne stwory (Troll, Jointoramix) wybiera drogę, która się blokuje. Kierunek: obsługa zajętych pól na ścieżce.
- Tryb stuk odrzuca większość wysłanych poleceń, a trzymaj nie odrzuca żadnego. (pewność 0.3)
  dowód: Stuk: 2/2 odrzucone w oknie krótkim, 6/13 w długim, łącznie 8/15 (53%). Trzymaj: 0/184 odrzucone w długim. Stuk ma n=2 pościgi w oknie długim, więc wniosek o jakości trybu jest niski.
  skutek: Gdy tryb stuk się uruchamia (np. jako rezerwa), większość poleceń nie dociera i pościg traci kroki.
  propozycja: Sprawdzić warunek przełączenia na stuk (funkcja wyboru trybu ruchu) i czy wybiera go w sytuacjach, gdzie trzymaj byłby poprawny. Kierunek: ograniczyć wybór stuk lub zmienić kolejność trybów.
- Trzymany klawisz często jest naciskany przy stojącej postaci, co może wynikać z opóźnienia reakcji. (pewność 0.3)
  dowód: Okno długie, trzymaj: 105 naciśnięć z postoju (0,32 na pościg, 105/331), trzymane 90% czasu, lat_med 0,5 s. Dla stuk lat_med 0,128 s, ale n=2.
  skutek: Część czasu klawisza trafia w postój (brak_ruchu, nadbieg), a 37% kroków to zmiany kierunku (0,37/krok), co wydłuża dojście.
  propozycja: Zbadać, czy opóźnienie odczytu pozycji (lat_med) powoduje naciski po dojściu do celu. Kierunek: funkcja aktualizacji stanu między krokami (częstotliwość odczytu), nie stała tempa.
- Utknięcia w stanie WALKA występują przy niskiej prędkości pola (v 12-20) i wolniejszych krokach niż typowe tempo trzymaj. (pewność 0.3)
  dowód: 10 utknięć w oknie długim; 6 pokazanych ma pole v 12-20 i krok_s 0.56-0.94. Tempo trzymaj: med 1,8 kroku/s. W każdym z 6 pokazanych obecny Jointoramix (dist 0) i Troll lub Orc. Brak rozkładu v dla wszystkich kroków, więc nie ma porównania.
  skutek: Utknięcia wydłużają pościg i zwiększają ryzyko zgubienia, zwłaszcza w tej samej okolicy (x 32482-32508, y 32273-32297).
  propozycja: Zmierzyć rozkład pole v i krok_s dla wszystkich kroków, by sprawdzić, czy niskie v naprawdę odróżnia utknięcia.
- do zmierzenia: Czy okno krótkie to dokładnie końcówka okna długiego (sprawdzić znaczniki czasu). Od tego zależy, czy skupienie zgubień w 5 minutach jest realne.
- do zmierzenia: Dla każdego cel_znikl: liczba stworów między graczem a celem, czy cel był za ścianą lub za innym stworem, i jego odległość w momencie zniknięcia.
- do zmierzenia: Rozkład pole v i krok_s dla wszystkich kroków, nie tylko dla utknięć, by sprawdzić, czy niskie v jest przyczyną.
- do zmierzenia: Czy naciski z postoju (105) zbiegają się z lat_med ~0,5 s, czyli czy klawisz jest trzymany po dojściu do celu.
- do zmierzenia: Dlaczego stuk jest odrzucany (kod, serwer, czy stan gry). Potrzebna większa próba stuk, żeby ocenić tryb.

## 2026-10-14 19:35 | uwaga | pościgów 5 min: 32, 30 min: 310
- Utrata dobić jest skupiona w ostatnich 300 s: 15 z 17 zgubień z okna długiego to cel_znikl z okna krótkiego. (pewność 0.6)
  dowód: okno_krotkie: dobicie_proc 38, zgubienie_proc 47 (12 dobić, 15 zgubień z 32 pościgów). okno_dlugie: zgubienie 17 (5%), dobicie 275 (89%). Poza ostatnimi 5 min: 2 zgubienia z 278 pościgów (~0,7%), dobicie 263/278 (~95%). Zakładam, że okno krótkie jest podzbiore
  skutek: W ostatnim 5-minutowym odcinku co drugi pościg kończy się bez dobicia, przy wcześniejszym poziomie ~95%.
  propozycja: Funkcja warunku cel_znikl w pętli pościgu: sprawdzić, po ilu iteracjach bez widocznego celu bot uznaje go za zgubionego. Rozważyć dłuższe ponowne szukanie celu przed wyjściem z pościgu, zwłaszcza gdy w pobliżu są inne stwory (Orc, Troll). Kierunek: wydłużenie tego okna.
- Zgubienia liczone na poziomie pojedynczego pościgu nie pokrywają się z wynikiem epizodu celu: 15 zgubień pościgów przy 0 zgubionych epizodach. (pewność 0.6)
  dowód: okno_krotkie.epizody_celu: epizody 5, zabite 5, zgubione 0; koniec.zgubienie 15. okno_dlugie: zgubienie pościgów 17 przy epizodach zgubionych 1, zabite 46 z 48.
  skutek: Wskaźnik zgubienia z pościgów może przeszacowywać stratę, bo część celów jest odzyskiwana w tym samym epizodzie. Ocena problemu opiera się wtedy na zawyżonej liczbie.
  propozycja: Obsługa powodu cel_znikl: dodać licznik odzyskań celu w obrębie epizodu, żeby oddzielić chwilową utratę widoczności od porzucenia epizodu. Kierunek: raportować wskaźnik na poziomie epizodu obok wskaźnika pościgów.
- Klawisz trzymany jest naciskany, gdy postać stoi, w ponad połowie wysłanych poleceń. Opóźnienie wydaje się leżeć między wysłaniem a ruchem postaci, a nie w decyzji bota. (pewność 0.4)
  dowód: okno_dlugie trzymaj: naciski_z_postoju 100 z wyslane 176 (57%), lat_med 0,492 s, dec_med 0,001 s. okno_krotkie: 14 z 23 (61%), lat_med 0,496 s.
  skutek: Klawisz może trwać dłużej niż potrzeba, więc postać rusza lub zmienia kierunek po dojściu do celu (zmiany_kierunku 0,39 na krok). Wpływu na dobicie nie widać w danych.
  propozycja: Funkcja puszczania klawisza w pościgu (warunek zwolnienia przy zbliżeniu się do celu): sprawdzić, czy zwolnienie następuje dopiero przy odl<=1. Rozważyć wcześniejsze zwolnienie, gdy odległość spada do 2. Kierunek: zwolnić klawisz wcześniej.
- Tryb stuk odrzuca część wysłanych poleceń mimo niskiej latencji, a trzymaj nie odrzuca żadnego. (pewność 0.3)
  dowód: stuk: odrzucone 8 z 15 wysłanych (okno krótkie 2/2, długie 6/13), lat_med 0,128 s, dec_med 0,09 s. trzymaj: odrzucone 0 z 199 wysłanych w obu oknach. Pościgów stuk: 3.
  skutek: Odrzucone naciśnięcia wydłużają dojście do celu. Przy 3 pościgach nie da się oszacować wpływu na wynik dobicia.
  propozycja: Funkcja wysyłania pojedynczych naciśnięć w trybie stuk: sprawdzić odstęp między naciśnięciami względem czasu trwania kroku, żeby nie wysyłać w trakcie trwającego ruchu. Kierunek: zwiększyć odstęp.
- Utknięcia i najgorsze pościgi pojawiają się w stanie WALKA, gdy na drodze są inne stwory, a cel jest w odległości 3–5 pól. (pewność 0.35)
  dowód: utkniecia: long 10, short 2. Ostatnie 6 long: WALKA (5 z 6), pole v 12–20, krok_s 0,56–0,94, obok Orc lub Troll. najgorsze_poscigi: 4 z 5 w WALKA, 1 w POGON; brak_ruchu 3 z 5; odl 3–5; hp_celu 16–28. bez_dojscia: 4 w oknie krótkim, 12 w długim.
  skutek: Bez_dojscia i utknięcia wydłużają pościg. Przy pole v 12–20 kroki są wolniejsze niż typowe tempo trzymaj (mediana krok_s ~0,70 wobec ~0,56 z 1/1,8). Próba jest mała (n=6), więc to słabe wsparcie.
  propozycja: Funkcja wyznaczania drogi w stanie WALKA: traktować pola zajęte przez inne stwory jako niedostępne przy wyborze kroku. Kierunek: dodać omijanie zajętych pól.
- do zmierzenia: Czy zgubienie (cel_znikl) częściej zbiega się z obecnością innych stworów w promieniu 3 pól w chwili zgubienia? Zmierzyć liczbę stworów w zasięgu przy każdym cel_znikl.
- do zmierzenia: Czy pościgi z naciskiem trzymanego klawisza przy stojącej postaci (naciski_z_postoju>0) kończą się zgubieniem lub bez_dojscia częściej niż pościgi bez takich naciśnięć? Liczyć to per pościg.
- do zmierzenia: Czy troll (hp_celu 16–28) to typowy cel pościgu? Rozdzielić statystyki wg typu celu, bo ostatnie_wnioski i najgorsze_poscigi dotyczą głównie trolli.
- do zmierzenia: Czy zmiany_kierunku przy 1–2 krokach to szum licznika? Zmierzyć zmiany kierunku tylko przy ruchu celu.
- do zmierzenia: Czy spadek skuteczności w ostatnich 5 min jest chwilowy (ta sama lokalizacja, pora, skład potworów)? Zebrać dłuższy odcinek z etykietą lokalizacji i składu potworów.

## 2026-10-14 19:37 | uwaga | pościgów 5 min: 22, 30 min: 297
- W ostatnim oknie 5-minutowym dobicia prawie zanikły: zgubienia dominują, a w oknie 30-minutowym sumarycznie jest dobrze. (pewność 0.5)
  dowód: okno_krotkie: 22 pościgi, cel_znikl 15, cel_martwy 7, dobicie_proc 32, zgubienie_proc 68. Okno_dlugie: 297 pościgów, dobicie_proc 88, zgubienie 17, z czego 15 mieści się w ostatnich 5 minutach (≈88% wszystkich zgubień).
  skutek: Bieżący spadek skuteczności: większość pościgów kończy się bez dobicia, a potwory uciekają w niedobitym stanie.
  propozycja: Sprawdzić funkcję, która wyznacza stan cel_znikl (warunek utraty celu z pola widzenia). Rozważyć, czy zbyt wczesne uznanie celu za zgubionego nie kończy pościgu, zanim cel się ponownie pojawi. Kierunek: sprawdzić, czy stała czasu/liczby klatek bez widoku celu jest wystarczająca.
- Zgubienia kończą się przy małym dystansie (odl ≈2), a nie po ucieczce na dalszy dystans, co wskazuje na utratę widoczności celu blisko postaci. (pewność 0.4)
  dowód: okno_krotkie: odleglosc start_med 2.0, koniec_med 2.0, delta_med 0.0; cel_znikl 15 z 22. W oknie długim koniec_med 1, a 'odpuszczony za ścianą' to top powód epizodów porzuconych.
  skutek: Cel jest blisko, ale za przeszkodą lub poza zasięgiem widzenia, więc pościg kończy się bez dobicia mimo braku oddalenia.
  propozycja: Rozważyć funkcję reakcji na cel_znikl, gdy ostatnia znana pozycja celu jest w odległości ≤2: zamiast natychmiastowego porzucenia, krótkie ponowne skanowanie wokół ostatniej pozycji. Dla człowieka: opisać stałą promienia skanowania i czasu oczekiwania.
- Utknięcia w ostatnich 5 minutach dotyczą pościgu bez innych stworów na drodze, więc problem nie wynika z tłoku w walce. (pewność 0.3)
  dowód: utkniecia okno_krotkie: 2 przypadki, oba stan IDZ, stwory tylko Jointoramix, pole v 12 i 20, krok_s 0.56 i 0.94. W oknie długim 10 utknięć, z czego większość w stanie WALKA z Trollami/Orcami.
  skutek: Pościg stoi przy celu, zanim zgubi go, co wydłuża czas do zgubienia i zmniejsza szansę na dobicie.
  propozycja: Sprawdzić funkcję wykrywania utknięcia i jej progi prędkości pola (krok_s) oraz okna czasu. Rozważyć, czy próg nie jest zbyt mało czuły na pola o niskiej prędkości przejścia. Kierunek: zweryfikować, czy wykrycie nie opiera się wyłącznie na pozycji, a nie na tym, czy postać realnie się przesuwa.
- Naciski klawisza trzymany przy postoju były głównie w dawniejszej części okna, a ostatnie 5 minut ich prawie nie ma, więc nie tłumaczą ostatniego spadku. (pewność 0.4)
  dowód: naciski_z_postoju: okno_krotkie 1 w 22 pościgach (0.05 na pościg); okno_długie 92 w 295 (0.31 na pościg). trzymane_proc_czasu 100 (krótkie) vs 89 (długie).
  skutek: Problem z klawiszem trzymanym był realny wcześniej, ale obecny spadek ma inną przyczynę.
  propozycja: Nie zmieniać funkcji trzymania klawisza na podstawie tego okna. Dla człowieka: porównać przypadki naciśnięć z postoju z czasem w sesji, aby potwierdzić, czy problem ustąpił sam.
- do zmierzenia: Czy zgubienia przy odl≤2 wiążą się z ustawieniem celu za ścianą: zmierzyć, ile z 15 cel_znikl miało przeszkodę na linii do ostatniej znanej pozycji celu.
- do zmierzenia: Czy zmiana w ostatnich 5 minutach jest trwała: porównać dobicie_proc w kolejnych oknach 5-minutowych (n≥20 w każdym), zanim uzna się problem za stały.
- do zmierzenia: Tryb stuk: 6 z 13 wysłanych poleceń odrzucone (46%) przy n=2 pościgach; zebrać więcej pościgów stuk, aby rozstrzygnąć, czy odrzucenia są cechą trybu, czy przypadkiem.
- do zmierzenia: Najgorsze pościgi to pościgi na Trolle w WALKA z brak_ruchu przy odl 3–4 (3 z 5 wpisów): zmierzyć, czy brak_ruchu w WALKA częściej kończy się zgubieniem niż dobiciem.
- do zmierzenia: Latencja: lat_med 0.5 s (trzymaj) vs 0.128 s (stuk) w długim oknie; sprawdzić, czy różnica latencji wyjaśnia odrzucenia w stuk, czy to osobny mechanizm.

## 2026-10-15 08:52 | ok | pościgów 5 min: 5, 30 min: 5
- Wszystkie 5 pościgów w trybie trzymaj zakończyło się dobiciem, bez zgubień i bez dojść bez skutku. (pewność 0.5)
  dowód: koniec.dobicie=5, dobicie_proc=100, zgubienie=0, bez_dojscia=0; powody_wyjsc: odl<=1=4, cel_martwy=1; epizody_celu 9/9 zabite
  skutek: Brak utraty dobić w próbce. Próba jest mała (n=5), więc to tylko wstępny sygnał.
  propozycja: Brak zmiany w kodzie. Dalej obserwować na większej próbie.
- Jedyne utknięcie wystąpiło w stanie WALKA, obok dwóch Trolli i Jointoramixa, a nie podczas swobodnego pościgu. (pewność 0.3)
  dowód: utkniecia.liczba=1; stan=WALKA, s=15, stwory=[Jointoramix,Troll,Troll], pole v=16, krok_s=0.75, bez_postepu=0 kroków
  skutek: Około 15 s stracone w jednym epizodzie; w danych nie widać wpływu na wynik pościgu (dobicie 100%).
  propozycja: Sprawdzić funkcję decyzji pościgu, która działa, gdy w pobliżu są inne stwory. Kierunek: pościg powinien rozpoznawać zajęte pole i nie blokować się w tłoku (np. stała progu liczby obcych stworów w promieniu wokół celu).
- Ostatnie_wnioski z poprzedniego raportu nie mają pokrycia w bieżących danych i są ze sobą sprzeczne. (pewność 0.7)
  dowód: zgubienie=0 w obu oknach, więc wniosek o zgubieniach przy odl≈2 nie ma podstawy; utkniecie wystąpiło w WALCE z innymi stworami, a wniosek mówi o pościgu bez innych stworów; okno_krotkie i okno_dlugie mają identyczne wartości, więc wniosek o 'dawniejszej części
  skutek: Wnioski przekazywane dalej mogą prowadzić do błędnych kierunków zmian w kodzie.
  propozycja: Sprawdzić, skąd pochodzi pole ostatnie_wnioski (czy jest liczone kodem, czy generowane osobno) i czy okna są poprawnie wycinane z logu.
- Naciski klawisza z postoju występują przy starcie każdego pościgu i nie są powiązane z wynikiem. (pewność 0.3)
  dowód: naciski_z_postoju=5 na 5 pościgów (1.0 na pościg); trzymane_proc_czasu=100; zmiany_kierunku=2 (0.11 na krok); lat_med_s=0.183, dec_med_s=0.0
  skutek: Może to dodawać stały koszt startu (około 0.18 s opóźnienia), ale w tej próbie nie wpłynęło na dobicia.
  propozycja: Sprawdzić funkcję startu pościgu, czy pierwsze naciśnięcie trzymanego klawisza jest wysyłane przed potwierdzeniem ruchu. Kierunek: skrócić lub scalić to pierwsze naciśnięcie, jeśli start jest opóźniony.
- do zmierzenia: Zebrać co najmniej 20 pościgów, żeby sprawdzić, czy wskaźnik dobić utrzymuje się poza małą próbą n=5.
- do zmierzenia: Przy każdym utknięciu logować liczbę obcych stworów w promieniu 2 pól oraz to, czy pole przed botem było zajęte, aby odróżnić tłok od przeszkody terenowej.
- do zmierzenia: Sprawdzić, czy okno krótkie (300 s) i długie (1800 s) rzeczywiście korzystają z różnych zakresów logu; obecnie są identyczne.
- do zmierzenia: Logować dystans i czas w chwili każdego zgubienia, żeby sprawdzić, czy zgubienia z poprzedniego raportu w ogóle występują.
- do zmierzenia: Mierzyć czas od pierwszego naciśnięcia klawisza do pierwszego ruchu postaci w każdym pościgu, żeby sprawdzić, czy naciski z postoju generują realne opóźnienie.

## 2026-10-15 08:54 | ok | pościgów 5 min: 15, 30 min: 16
- Pościgi w oknie krótkim i długim kończą się dobiciem; nie zanotowano zgubienia ani braku dojścia. (pewność 0.8)
  dowód: krótkie: 15/15 dobicie (100%), zgubienie 0, bez_dojscia 0; długie: 16/16 dobicie (100%); odległość start med 2 -> koniec med 1 w obu oknach
  skutek: Brak strat dobić w analizowanym materiale. Wniosek dotyczy tylko tej próby, nie długiej historii.
  propozycja: Brak zmiany w kodzie na podstawie tych danych.
- Dwa utknięcia wystąpiły w stanie WALKA przy dwóch Trollach i Jointoramixie, a prędkość pola spadała do 0.66–0.75 kroku/s, zamiast być przypisana do swobodnego pościgu. (pewność 0.35)
  dowód: utkniecia.liczba 2 (08:52:31: pole v=16, krok_s=0.75; 08:53:24: v=14, krok_s=0.66); stan WALKA; pościgi bez utknięć w tych samych oknach
  skutek: Spowolnienie w walce z wieloma stworami; w danych nie widać straty celu, bo pościgi zakończyły się dobiciem.
  propozycja: Sprawdzić funkcję przełączania między stanem WALKA a POŚCIG (warunek wejścia w pościg przy wielu stworach w pobliżu) i to, czy pościg jest wstrzymywany w WALKA; nie zmieniać progów bez tego sprawdzenia.
- W epizodach celu jedna porzucona gonitwa trwała ponad 40 s bez dogonienia, mimo że żaden pościg nie został oznaczony jako zgubienie. (pewność 0.3)
  dowód: epizody_celu: epizody 10, zabite 9, porzucone 1, wskaznik 90; powod_top 'od 40 s gonię uciekającego bez...' (tekst obcięty); w pościgach zgubienie 0 i bez_dojscia 0
  skutek: Jedno dobicie utracone w 10 epizodach; wskaźnik 90% jest niższy niż 100% pościgów, więc definicje epizodu i pościgu się różnią.
  propozycja: Ustalić w kodzie, czym różni się epizod celu od pościgu (np. licznik epizodu obejmuje czas od wykrycia celu, a nie od startu pościgu) oraz jak liczony jest powód porzucenia po przekroczeniu limitu czasu.
- Przy każdym pościgu występuje około 0.5 naciśnięcia klawisza z postoju, a mediana opóźnienia wynosi około 0.5–0.6 s przed pierwszym krokiem. (pewność 0.25)
  dowód: naciski_z_postoju 7 (krótkie) i 8 (długie), naciski_z_postoju_na_poscig 0.47/0.5; lat_med_s 0.581 (krótkie) i 0.5 (długie); dec_med_s 0.0
  skutek: Niewielki, stały narzut na początku pościgu; wpływ na wynik nie jest widoczny w danych, bo wszystkie pościgi się udały.
  propozycja: Zmierzyć, czy opóźnienie zależy od trybu startu (trzymaj vs stuk) w funkcji inicjującej pościg; decyzja o zmianie należy do człowieka.
- do zmierzenia: Czy porzucony epizod 40-sekundowy wiąże się z konkretnym celem (np. uciekający bez mniejszego HP) lub z przeszkodą na trasie? Trzeba zapisać ID celu, trasę i powód porzucenia.
- do zmierzenia: Czy spadek prędkości w WALKA wynika z kolizji z trollami (blokowanie pola), czy z opóźnień wejścia do pościgu? Trzeba zapisać pozycje stworów i wejścia/wyjścia ze stanu WALKA dla każdego kroku.
- do zmierzenia: Czy naciski z postoju i opóźnienie startu różnią się między trybem trzymaj a stuk przy tym samym typie celu? Trzeba rozdzielić pomiary dla obu trybów w tych samych oknach.
- do zmierzenia: Jaka jest próbka dla utknięć w WALKA? Przy n=2 nie można odróżnić przypadku od prawidłowości; trzeba zebrać więcej okien z wieloma stworami.

## 2026-10-15 08:56 | uwaga | pościgów 5 min: 46, 30 min: 50
- Utknięcia pościgu występują w stanie WALKA przy wielu potworach (Jointoramix + 2 Trolle), a prędkość pola spada do 0.66–0.75 kroku/s wobec mediany 1.6 kroku/s. (pewność 0.35)
  dowód: utkniecia.liczba=2 (oba stan=WALKA, stwory z 3 potworami); pole krok_s 0.75 i 0.66; kroki_na_s med 1.6 (krótkie) i 1.6 (długie); p10 1.25
  skutek: Pościg w tłoku wielu potworów jest ~2x wolniejszy od typowego. Przy n=2 nie da się wykluczyć przypadku.
  propozycja: Funkcja decydująca o przejściu do stanu WALKA lub o ruchu w pościgu, gdy w pobliżu jest więcej niż jeden potwór: opisać warunek wejścia w WALKA i sprawdzić, czy blokuje krok w stronę uciekającego celu.
- Jeden pościg za uciekającym przekroczył 40 s bez dogonienia i skończył się porzuceniem, mimo że zgubienie wynosi 0. (pewność 0.4)
  dowód: epizody_celu.porzucone=1 z 10 (okno krótkie) i 1 z 16 (okno długie); powod_top='od 40 s gonię uciekającego bez...'; koniec.bez_dojscia_okno_lub_brak_ruchu=1 w obu oknach
  skutek: Jeden utracony cel na 16 epizodów (~6%); koszt czasu bezczynnego gonienia to ponad 40 s w jednym przypadku.
  propozycja: Stała limitu czasu epizodu pościgu oraz warunek przejścia w porzucenie: opisać, czy limit zależy od odległości i HP celu, i co dzieje się po przekroczeniu (zakończenie pościgu czy powrót do patrolu).
- Pościg zaczyna się z opóźnieniem około 0.4 s przed pierwszym krokiem, a część pościgów wymaga pierwszego naciśnięcia z postoju. (pewność 0.45)
  dowód: lat_med_s=0.4 (oba okna); dec_med_s=0.001; naciski_z_postoju 11/46 (krótkie, 0.24 na pościg) i 15/50 (długie, 0.30 na pościg); start_med odległości=2
  skutek: Około 0.4 s straty na każdy pościg; przy starcie 2 pola to istotna część czasu do dobicia. Wpływ na wynik jest ograniczony, bo dobicia są wysokie.
  propozycja: Funkcja wysyłająca pierwszy krok/trzymanie klawisza po decyzji o pościgu: sprawdzić, czy opóźnienie leży w klawiszu (wysłanie), czy w oczekiwaniu na aktualizację pozycji.
- Najgorszy pościg (Troll) zatrzymał się po jednym kroku z powodem brak_ruchu, mimo że cel był w odległości 7 i 5, a HP gracza wynosił 100. (pewność 0.2)
  dowód: najgorsze_poscigi[0]: powod=brak_ruchu, kroki=1, czas=2.4 s, kroki_na_s=0.42, odl=[7,5], zmiany_kier=4, lat_med=0.253, stan=IDZ; to jedyny wpis
  skutek: Pojedynczy przypadek bez dojścia; nie da się z niego wyprowadzić wzorca. Możliwe, że trasa była zablokowana.
  propozycja: Funkcja wykrywająca brak ruchu: zapisać powód zatrzymania (brak trasy, blokada, zmiana celu) w logu, żeby odróżnić ten przypadek od postoju.

## 2026-10-15 08:58 | uwaga | pościgów 5 min: 64, 30 min: 71
- Pościg porzucany po ok. 40 s gonienia bez dogonienia, mimo że zgubienia nie było (0), co kosztuje pojedyncze dobicia. (pewność 0.4)
  dowód: Okno krótkie: porzucone 1 z 10 epizodów (wskaźnik 90), powod_top 'od 40 s gonię uciekającego bez'; okno długie: porzucone 1 z 22 (wskaźnik 95). Zgubienie 0 w obu oknach; bez_postepu 0 pościgów. Dobicie 98% i 99%.
  skutek: Około 1 utraconego dobicia na 10–22 epizodów; cel wciąż widoczny, więc dobicie było w zasięgu.
  propozycja: Stała limitu czasu porzucania epizodu (nazwa w kodzie do ustalenia) — rozważyć warunek zamiast stałego progu: przedłużanie, gdy odległość maleje (delta_med ujemna), a porzucenie tylko przy braku zbliżania. Nie skracać pościgu.
- Start pościgu z postoju bywa opóźniony: pierwszy krok nie następuje od razu, a część pościgów wymaga pierwszego naciśnięcia z postoju. (pewność 0.35)
  dowód: naciski_z_postoju: 17 z 64 (0.27 na pościg) w krótkim oknie, 24 z 71 (0.34) w długim; lat_med 0.2 s i 0.191 s; najgorszy pościg: 1 krok w 2.4 s.
  skutek: Każdy taki start traci ok. 0.2–0.4 s dystansu względem celu, co zwiększa ryzyko porzucenia przy dalekim celu.
  propozycja: Funkcja inicjująca ruch pościgu (obsługa pierwszego kroku z postoju) — sprawdzić, czy klawisz trzymany startuje natychmiast po decyzji o pościgu, czy czeka na kolejny cykl decyzji.
- Utknięcia w stanie WALKA podczas pościgu, gdy w pobliżu jest drugi potwór (Troll), zatrzymują tempo pościgu. (pewność 0.3)
  dowód: Okno długie: 3 utknięcia, wszystkie WALKA, z Trollem w stwory (1–4 odl.), pole v 14–16, krok_s 0.66–0.75 vs kroki_na_s med 1.6; okno krótkie: 1 utknięcie tego samego typu.
  skutek: Wolniejsze dogonienie; dobicia mimo to 98–99%, więc koszt jest mały.
  propozycja: Funkcja przejścia z pościgu do walki (wybór celu, gdy w pobliżu jest inny potwór) — sprawdzić, czy bot nie zostaje w walce z drugim celem zamiast dobić uciekającego.
- do zmierzenia: Zmierzyć prędkość uciekającego celu w kroki/s dla epizodów porzuconych vs zabitych — czy cel ucieka szybciej niż postać, co tłumaczyłoby porzucenia po 40 s.
- do zmierzenia: Sprawdzić, czy zmiany_kierunku (0.54 i 0.37 na krok) to korekty trasy na skosach, czy zygzak; porównać z oscylacjami (0 w obu oknach), żeby to odróżnić.
- do zmierzenia: Zmierzyć opóźnienie od decyzji o pościgu do pierwszego ruchu (osobno dla startu z postoju) i porównać z odległością startową.
- do zmierzenia: Zliczyć, ile pościgów zaczynało się przy obecności innego potwora, i porównać z liczbą utknięć WALKA na tę samą liczbę pościgów.
- do zmierzenia: Zebrać więcej porzuceń (obecnie 2 w sumie): tylko przy większej próbie da się ocenić, czy to stały wzorzec, czy przypadek.

## 2026-10-15 09:00 | uwaga | pościgów 5 min: 90, 30 min: 109
- Pościg z postoju zaczyna się z opóźnieniem: część pościgów wymaga naciśnięcia klawisza z pozycji stojącej, zanim postać zacznie iść. (pewność 0.5)
  dowód: naciski_z_postoju 27/90 pościgów w oknie krótkim (0.30 na pościg) i 38/109 w długim (0.35); lat_med_s 0.2 i 0.195; kroki_na_s_ogolem 1.72 i 1.75, czyli szybkość w trakcie biegu jest stabilna.
  skutek: Każdy start z postoju dodaje opóźnienie przed pierwszym krokiem. Dobicia nadal wychodzą w 99%, więc koszt jest czasowy, a nie utrata celów.
  propozycja: Funkcja obsługi startu ruchu w trybie trzymaj (przejście ze stanu STOJ do IDZ): sprawdzić, czy pierwszy krok wysyłany jest od razu po decyzji, czy po dodatkowym cyklu pętli. Kierunek: skrócić to przejście, jeśli opóźnienie istnieje w kodzie.
- Utknięcia w stanie WALKA występują, gdy obok celu stoi drugi potwór (Troll), i wtedy pościg zamiera na 15–19 s. (pewność 0.4)
  dowód: utkniecia: 1 w oknie krótkim i 3 w długim; wszystkie w stanie WALKA z Jointoramix (hp 0) i Troll (odl 0–4); pole krok_s 0.66–0.75 s, a poza tym pościgi biegną ze średnią 1.46–1.6 kroku/s.
  skutek: Każde utknięcie to kilkanaście sekund bez postępu. W długim oknie to 3 z 26 epizodów celu; porzucony epizod też trwał ponad 40 s bez dojścia.
  propozycja: Funkcja decyzji pościgu w stanie WALKA: warunek, przy którym pościg wraca do wyboru celu, gdy w pobliżu jest inny potwór. Kierunek: jasny priorytet walki nad pościgiem albo wyraźne przerwanie pościgu w takiej sytuacji. Decyzja należy do człowieka.
- Porzucony pościg trwał ponad 40 s bez dojścia do celu, co wygląda na pościg za uciekającym, którego nie da się dogonić. (pewność 0.3)
  dowód: okno_dlugie: porzucone 1 z 26 epizodów celu; powod_top 'od 40 s gonię uciekającego bez'; bez_dojscia_okno_lub_brak_ruchu 1; bez_postepu 0 pościgów i 0 kroków.
  skutek: Jeden pościg z 109 zakończył się bez dobicia; to koszt czasu, nie utrata celów (zgubienie 0).
  propozycja: Nie skracać pościgu. Zbadać, czy uciekający porusza się szybciej niż postać w trakcie pościgu (kroki_na_s celu vs postaci). Ewentualna zmiana dotyczy funkcji oceny dalszego pościgu, a nie stałej czasowej.

## 2026-10-15 09:02 | uwaga | pościgów 5 min: 58, 30 min: 129
- Pojedynczy pościg za uciekającym celem trwał ponad 40 s bez dojścia, zanim został porzucony. (pewność 0.3)
  dowód: okno_dlugie.epizody_celu: porzucone 1 z 34 epizodów, wskaznik 97; powod_top 'od 40 s gonię uciekającego bez'; powody_wyjsc: brak_ruchu 1
  skutek: Ok. 40 s czasu na jeden cel bez efektu. Przy jednym przypadku nie da się stwierdzić, czy to typowy wzorzec uciekającego potwora.
  propozycja: Nie zmieniać progów czasu. Najpierw zebrać więcej przypadków porzucenia z zapisem odległości w czasie, żeby sprawdzić, czy cel oddala się z tą samą prędkością.
- Klawisz trzymany jest naciskany, gdy postać stoi w miejscu, w około 40% pościgów. (pewność 0.35)
  dowód: naciski_z_postoju: 25 z 58 pościgów (okno krótkie, 0.5 na krok) i 49 z 129 (okno długie, 0.38 na pościg); zmiany_kierunku_na_krok 0.43–0.5; trzymane_proc_czasu 100
  skutek: Nie widać bezpośredniego kosztu: kroki_na_s 1.5–1.8, a dobicie 99–100%. Możliwe, że część naciśnięć marnuje się przy blokadzie terenem lub innym potworem, ale dane tego nie potwierdzają.
  propozycja: Sprawdzić, czy naciski z postoju zbiegają się czasowo z utknięciami w stanie WALKA. Nie zmieniać na razie logiki klawisza.
- do zmierzenia: Czy naciski z postoju (trzymaj w miejscu) zbiegają się czasowo z utknięciami WALKA, a jeśli tak, czy blokuje je pole lub inny potwór na ścieżce.
- do zmierzenia: Czy Troll obok celu rzeczywiście zajmuje tile na ścieżce (log ścieżki i pozycji obu potworów w chwili utknięcia).
- do zmierzenia: Co dzieje się w pierwszej sekundzie pościgu w stanie IDZ, gdy kończy się na brak_ruchu po 1 kroku (log pozycji, lat i decyzji).
- do zmierzenia: Porównanie trzymaj vs stuk: w danych brak pościgów w trybie stuk, więc nie da się ocenić, który tryb lepiej radzi sobie z utknięciami.
- do zmierzenia: Czy niski krok_s w utknięciach (0.66–0.94) wynika z pola (typ terenu, v=14–20) czy z blokady przez potwory.

## 2026-10-15 09:04 | uwaga | pościgów 5 min: 50, 30 min: 151
- Pościg prawie zawsze kończy się dobiciem. Jedyna utrata to pojedynczy pościg zakończony brak_ruchu po jednym kroku. (pewność 0.3)
  dowód: okno_dlugie: dobicie 150/151 (99%), zgubienie 0, bez_dojscia 1. najgorsze_poscigi 08:56:22: kroki 1, czas 2.4 s, odl 7->5, lat_med 0.253 s vs 0.183 s w oknie, stan IDZ, ocena_zlego 3.2.
  skutek: Strata 1 pościgu na 151 (0,7%). Nie ma zgubienia celu.
  propozycja: Funkcja decydująca o wyjściu z pościgu przy brak_ruchu: rozważyć ponowne wyznaczenie ścieżki przed zakończeniem pościgu, zamiast wyjścia po pierwszym braku ruchu. Kierunek: więcej prób ruchu przed wyjściem (do rozważenia przez człowieka, bez skracania pościgu).
- Jeden pościg trwał ok. 40 s bez dojścia do celu, zanim został porzucony. To długi ogon, a nie typowy przebieg. (pewność 0.3)
  dowód: okno_dlugie epizody_celu: epizody 40, zabite 39, porzucone 1, wskaznik 98, powod_top 'od 40 s gonię uciekającego bez'. Licznik bez_postepu: 0 pościgów, 0 kroków, więc nie zadziałał.
  skutek: Około 40 s czasu cavebota na jeden cel w oknie 1800 s (ok. 2%).
  propozycja: Funkcja licznika bez_postepu: sprawdzić, dlaczego nie zaliczył 40-sekundowego braku dojścia. Kierunek: licznik powinien reagować na brak zmniejszania dystansu w czasie, a nie tylko na brak kroków (do rozważenia przez człowieka).
- Utknięcia w stanie WALKA dotyczą pościgów, w których obok celu są Trolle. Wtedy postać nie przechodzi do pościgu. (pewność 0.35)
  dowód: okno_dlugie utkniecia: 5 zdarzeń, wszystkie stan WALKA, z Trollami (wartości w stwory 1-4), pole.krok_s 0.66-0.94 vs kroki_na_s med 1.6 (trzymaj). Oscylacje 0.
  skutek: 5 utkniec w 1800 s. Nie widać wpływu na dobicia (99%), więc koszt to czas.
  propozycja: Funkcja wyboru stanu przy wielu celach w zasięgu: sprawdzić, czy walka z Trollem ma pierwszeństwo przed pościgiem uciekającego. Kierunek: pościg za uciekającym powinien mieć pierwszeństwo, gdy odległość rośnie (do rozważenia przez człowieka).
- Klawisz trzymany jest wciśnięty przez cały pościg, także gdy postać stoi. Naciski z postoju pojawiają się w ok. 38% pościgów, ale koszt dobić jest mały. (pewność 0.4)
  dowód: okno_dlugie trzymaj: trzymane_proc_czasu 100, naciski_z_postoju 57 (0,38 na pościg), zmiany_kierunku_na_krok 0.39, kroki_na_s med 1.6, dobicie 99%. Tryb stuk w danych nie występuje.
  skutek: Nieefektywny ruch (postoje, zmiany kierunku), ale tylko 1 brak_ruchu w 151 pościgach.
  propozycja: Funkcja obsługi klawisza trzymaj: rozważyć puszczanie klawisza, gdy wykryto postój przy celu w zasięgu. Kierunek: krótsze trzymanie w stanie postoju, bez zmiany wartości progów (do rozważenia przez człowieka).
- do zmierzenia: Co oznaczają pola stwory[1] i pole.v / pole.krok_s? Bez tego nie da się potwierdzić, czy utknięcia wynikają z odległości do Trolli, czy z prędkości pola.
- do zmierzenia: Czy naciski z postoju (57 pościgów) poprzedzają zdarzenia brak_ruchu i długi ogon? Zmierzyć sekwencję zdarzeń 5 s przed każdym takim zdarzeniem.
- do zmierzenia: Porównanie trzymaj vs stuk: w danych brak trybu stuk. Zebrać co najmniej 5 pościgów w trybie stuk, aby ocenić, czy tryb wpływa na zmiany kierunku i postoje.
- do zmierzenia: Czy 40-sekundowy pościg porzucony był w stanie IDZ czy WALKA? Sprawdzić stan i odległość co kilka sekund w tym epizodzie.
- do zmierzenia: Czy lat_med 0.253 s przy brak_ruchu jest regularny? Zebrać kolejne przypadki brak_ruchu, bo obecnie to n=1.

## 2026-10-15 09:07 | uwaga | pościgów 5 min: 26, 30 min: 154
- Pościg niemal zawsze kończy się dobiciem celu, bez zgubienia. (pewność 0.9)
  dowód: Okno długie: dobicie 153/154 (99%), zgubienie 0; odl<=1 w 141 przypadkach. Okno krótkie: dobicie 26/26 (100%). Odległość mediana 2.0 -> 1.0, delta -1.0, wzrost odległości 0 pościgów.
  skutek: Brak utraty dobić w tych danych. Kosztem jest tylko czas trwania pojedynczych pościgów.
  propozycja: Brak zmiany. Zachować obecną logikę dobicia (warunek odl<=1 i cel_martwy) jako punkt odniesienia.
- Najdłuższy ogon: jeden pościg bez dojścia do celu i jeden porzucony epizod, a najgorszy pojedynczy przypadek to Troll z brak_ruchu po 2.4 s. (pewność 0.3)
  dowód: Okno długie: porzucone 1/43 epizodów, powod_top 'od 40 s gonię uciekającego bez' (tekst obcięty), brak_ruchu 1, bez_dojscia 1. Najgorszy pościg: 1 krok, odl [7,5], lat_med 0.253, ocena_zlego 3.2. Próba n=1.
  skutek: Pojedynczy przypadek strat czasu; w tej próbie nie widać systematycznej przyczyny.
  propozycja: Dodać do logu pełny powód porzucenia oraz stan funkcji ruchu (czy postać dostała komendę kroku) w momencie decyzji o porzuceniu, bez zmiany stałych limitu czasu pościgu.
- Utknięcia pojawiają się wyłącznie w stanie WALKA, gdy w pobliżu są Trolle (odległość 1–4) obok celu Jointoramix. (pewność 0.4)
  dowód: Okno długie: utkniecia 5, wszystkie stan WALKA, każde z Trollem w zasięgu 1–4 i Jointoramixem; pole v 14–20, krok_s 0.66–0.94. Okno krótkie: 1 utkniecie, również WALKA z Trollami. Brak danych o liczbie pościgów, w których Trolle były obok, więc nie da się poli
  skutek: 5/154 pościgów (ok. 3%) traci czas w walce zamiast w pościgu; dobicia mimo to nadal prawie 100%.
  propozycja: Sprawdzić funkcję decydującą o wejściu w pościg, gdy w pobliżu jest więcej niż jeden potwór; rozważyć warunek wyboru celu po odległości i liczbie sąsiadów, do oceny przez człowieka.
- Klawisz trzymany jest wciśnięty przez cały czas pościgu, także gdy postać stoi, a dane nie zawierają trybu stuk do porównania. (pewność 0.5)
  dowód: trzymane_proc_czasu 100 w obu oknach; naciski_z_postoju 61 w długim oknie (0.4 na pościg), 13 w krótkim (0.5); zmiany_kierunku_na_krok 0.4 (długie) i 0.26 (krótkie). Tryb stuk nie wystąpił ani razu.
  skutek: Naciski z postoju nie obniżają dobić (99%), ale nie wiadomo, czy zwiększają zmiany kierunku i czas pościgu, bo brak porównania.
  propozycja: Dodać w kodzie przełącznik trybu klawisza (trzymaj/stuk) z zapisem trybu w każdym pościgu, żeby następna próba mogła porównać oba tryby; nie zmieniać obecnego domyślnego trybu bez tych danych.
- Prędkość kroków ma długi dolny ogon, który może mieć związek z prędkością pola. (pewność 0.3)
  dowód: Okno długie: kroki_na_s med 1.67, p10 1.27, p90 1.79. Utknięcia miały pole v 14–20 i krok_s 0.66–0.94, czyli wolniejsze pola. Brak korelacji liczonej z danych.
  skutek: Wolniejsze pościgi wydłużają czas dobicia, ale nie zmieniają jego skuteczności w tej próbie.
  propozycja: Dodać do statystyk korelację kroki_na_s z polem v i krok_s dla każdego pościgu, zanim cokolwiek zmienimy.

## 2026-10-15 09:09 | uwaga | pościgów 5 min: 35, 30 min: 167
- Utknięcia pościgu pojawiają się tylko w stanie WALKA, gdy obok celu Jointoramix (odl 0) stoją Trolle w odległości 1–4. (pewność 0.5)
  dowód: okno_dlugie: utkniecia 6 z 167 pościgów (3,6%), wszystkie WALKA, każde z Trollem odl 1–4; okno_krotkie: 1 utknięcie (09:07:28, Troll odl 2).
  skutek: Postać stoi w miejscu przez 15–20 s na utknięcie (łącznie około 100 s w oknie długim), co wydłuża pościg. W tym oknie zgubienie wyniosło 0, więc koszt to czas, nie utracone dobicia.
  propozycja: Funkcja wyboru celu/ruchu w stanie WALKA: rozważyć uwzględnienie odległości do Trolli przy wyborze ścieżki do Jointoramixa (sprawdzić, czy ścieżka nie przechodzi przez pole zajęte przez Trolle).
- Najwolniejsze pościgi (p10 kroków/s 1,27 vs mediana 1,6) mogą wynikać z prędkości pola, bo wszystkie 6 utknięć miało krok_s pola 0,66–0,94, czyli wolniejsze niż oczekiwane 0,625 s/krok. (pewność 0.35)
  dowód: okno_dlugie: kroki_na_s med 1,6, p10 1,27, p90 1,79; zmiany_kierunku_na_krok 0,39. Pole w utknięciach: v 14–20, krok_s 0,66–0,94 (1/1,6 ≈ 0,625 s).
  skutek: Część czasu pościgu idzie na wolne pola, nie na zachowanie bota. Bez pomiaru pola dla każdego pościgu nie da się tego oddzielić od problemów ruchu.
  propozycja: Funkcja obliczająca czas kroku z prędkości pola (v/krok_s): dodać logowanie pola dla każdego pościgu, nie tylko dla utknięć, i porównać z kroki_na_s.
- Jedyny pościg zakończony bez dojścia (brak_ruchu) wystartował z dystansu 7 i zrobił tylko 1 krok; to pojedynczy przypadek. (pewność 0.2)
  dowód: najgorsze_poscigi: Troll, powód brak_ruchu, kroki 1, czas 2,4 s, odl 7→5, kroki/s 0,42, lat_med 0,253 s (mediana 0,2), stan IDZ, pole v16 krok_s 0,75. Okno długie: bez_dojscia 1 z 167.
  skutek: Pościg zakończył się bez dobicia i bez zgubienia celu, ale tylko w tym jednym przypadku; wniosku o przyczynie nie da się oprzeć na n=1.
  propozycja: Brak zmiany w kodzie na podstawie tego przypadku; zebrać kolejne przypadki brak_ruchu, zanim zaproponuje się zmianę.
- do zmierzenia: Czy ruch w stanie WALKA jest blokowany przez Trolle: zapisać pozycję co krok i odległość do najbliższego Trolla w czasie utknięcia.
- do zmierzenia: Czy krok_s pola koreluje z kroki_na_s w pościgu: logować pole.v i krok_s dla każdego pościgu, nie tylko dla utknięć.
- do zmierzenia: Dlaczego wyslane (123) jest mniejsze niż kroki (144) i pościgi (167): czy 44 pościgi nie wysłały ruchu, czy liczniki liczą różne rzeczy?
- do zmierzenia: Czy tryb stuk działa w ogóle: w danych jest tylko trzymaj, więc porównanie nie jest możliwe bez zebrania próbki stuk.
- do zmierzenia: Co dokładnie oznacza porzucony epizod ("od 40 s gonię uciekającego bez..."; pole obcięte): sprawdzić jego pełny przebieg i czy celem był Troll czy Jointoramix.

## 2026-10-15 09:11 | uwaga | pościgów 5 min: 35, 30 min: 187
- Skuteczność dobicia jest bardzo wysoka; straty to pojedyncze przypadki bez dojścia i porzucenia. (pewność 0.9)
  dowód: Okno długie: 186/187 dobicie (99,5%), zgubienie 0, brak_ruchu 1, porzucone 1. Okno krótkie: 35/35 dobicie, zgubienie 0.
  skutek: Brak istotnej utraty dobić. Pojedyncze przypadki nie pozwalają wyciągnąć wniosku o przyczynie.
  propozycja: Brak zmiany w kodzie.
- Klawisz trzymany jest wciśnięty niemal cały czas, także gdy postać stoi, co może powodować przestrzelenie lub kolizję z celem. (pewność 0.35)
  dowód: trzymane_proc_czasu 99% (okno długie), naciski_z_postoju 81 (0,43 na pościg), zmiany_kierunku 62 na 166 kroków (0,37/krok). Brak trybu stuk, więc nie ma porównania.
  skutek: Możliwy wpływ na 6 utknięć w stanie WALKA (3% pościgów). Związek nie jest dowiedziony.
  propozycja: Funkcja obsługi trzymania klawisza (warunek zwolnienia przy odl<=1 lub przy braku zmiany pozycji); do rozważenia przez człowieka, bez zmiany stałych.
- Utknięcia pojawiają się w walce z Trollem, na polach o wolniejszym kroku niż typowy pościg. (pewność 0.3)
  dowód: 6 utknięć w 1800 s, wszystkie stan WALKA, krok_s pola 0,66–0,94 (typowo ~0,625 przy kroki_na_s med 1,6). Brak danych o krok_s pościgów bez utknięcia, więc porównanie jest niepełne.
  skutek: Około 3% pościgów zawisa, a cel może uciec z zasięgu.
  propozycja: Funkcja wykrywania utknięcia/priorytetu celu w WALKA (warunek przejścia ze stanu WALKA z powrotem do pościgu); do rozważenia przez człowieka.
- Jedyny pościg bez dojścia wystartował z dystansu 7 i wykonał 1 krok; to pojedynczy przypadek, nie wzorzec. (pewność 0.15)
  dowód: najgorsze_poscigi: brak_ruchu, kroki 1, czas 2,4 s, odl start 7 (mediana 2), stan IDZ, lat_med 0,253 s. Próba n=1.
  skutek: Możliwa strata jednego dobicia; nie da się stwierdzić powtarzalności.
  propozycja: Brak zmiany do czasu więcej przypadków; ewentualnie logowanie dystansu startowego przy brak_ruchu.
- Długie pościgi (powyżej 40 s) są jedynym widocznym źródłem porzuceń. (pewność 0.2)
  dowód: powod_top: 'od 40 s gonię uciekającego bez...', porzucone 1 z 49 epizodów celu (wskaźnik 98%). Próba n=1 dla porzucenia.
  skutek: Pojedyncze porzucenie; wpływ na wynik minimalny.
  propozycja: Rozważyć limit czasu pościgu jako stałą; decyzja po zebraniu większej liczby porzuceń.

## 2026-10-15 09:13 | uwaga | pościgów 5 min: 32, 30 min: 191
- Utknięcia w walce pojawiają się głównie na wolnych polach, gdy w pościgu są Trolle obok celu. (pewność 0.5)
  dowód: utkniecia: 7 w oknie długim (6 wypisanych) i 1 w krótkim (ta sama godz. 09:11:03), wszystkie stan WALKA, czas 16–26 s; pole.krok_s 0.66–0.94 przy kroki_na_s med 1.6 (p10 1.26); w 5 z 6 wypisanych obecny Troll (stwory: Troll idx 1–4).
  skutek: Pościg wydłuża się ponad typowe czasy; w tym samym oknie wystąpił 1 bez_dojścia (brak_ruchu) i 1 porzucenie.
  propozycja: Funkcja wykrywania braku postępu: licznik 'kroków bez zmiany odległości' powinien mieć próg czasu skalowany odwrotnie do pole.krok_s (wolne pole = dłuższy próg), zamiast stałej. Kierunek: zwiększyć tolerancję przy niskim krok_s, nie skracać pościgu.
- Trzymany klawisz często działa w postoju, a część naciśnięć nie przekłada się na ruch postaci. (pewność 0.3)
  dowód: okno_dlugie: naciski_z_postoju 85 (0.45 na pościg) przy trzymane_proc 99%; zmiany_kierunku 62 (0.36 na krok); ponow_brak 7; utkniecia 7 w tym samym oknie.
  skutek: Możliwe, że postać stoi, gdy klawisz jest trzymany (blokada przez potwory lub ścianę), co wydłuża pościg bez postępu.
  propozycja: Sprawdzić funkcję wysyłania kroków: czy po wykryciu postoju przy trzymanym klawiszu kod zmienia kierunek/ścieżkę, zamiast ponawiać ten sam klawisz. Kierunek: obsługa postoju, nie zmiana długości pościgu.
- do zmierzenia: Rozkład pole.krok_s dla wszystkich pościgów (nie tylko utkniętych), żeby sprawdzić, czy utknięcia są nadreprezentowane na polach v<=20.
- do zmierzenia: Liczba stworów w promieniu 1 od gracza w chwili każdego naciśnięcia z postoju, żeby potwierdzić blokadę ścieżki przez Trolle.
- do zmierzenia: Dane trybu 'stuk' (brak w tym zestawie, więc porównanie trzymaj vs stuk nie jest możliwe).
- do zmierzenia: Czas od startu do pierwszego naciśnięcia z postoju w pościgach udanych vs utkniętych.
- do zmierzenia: Przypadek bez_dojścia brak_ruchu (Troll, dystans 7, 1 krok, stan IDZ): czy powtarza się przy dystansie >=5 (obecnie n=1, za mało).

## 2026-10-15 09:17 | uwaga | pościgów 5 min: 9, 30 min: 200
- Pościgi bardzo skutecznie kończą się dobiciem celu, bez zgubień. (pewność 0.9)
  dowód: okno_dlugie: 199/200 dobicie (99.5%), zgubienie 0, bez_dojscia 1; okno_krotkie: 9/9 dobicie; epizody_celu 53/54 zabite, 1 porzucone
  skutek: Brak istotnej utraty dobić w danych; jedyne odchylenie to pojedynczy przypadek braku ruchu i jedno porzucenie.
  propozycja: Brak zmiany wymaganej.
- Trzymany klawisz często jest naciśnięty, gdy postać stoi, a część naciśnięć nie przekłada się na ruch. (pewność 0.5)
  dowód: okno_dlugie: naciski_z_postoju 94 w 200 pościgach (0.47 na pościg), trzymane_proc_czasu 99%, lat_med 0.183 s; okno_krotkie: naciski_z_postoju 9 przy trzymane 100%
  skutek: Część czasu klawisz jest trzymany bez postępu, co może opóźniać dojście do celu; nie widać jednak wpływu na wskaźnik dobić.
  propozycja: Funkcja obsługi trzymania klawisza w pościgu (warunek zwalniania klawisza): sprawdzić, czy zwalnia po braku zmiany pozycji w oknie opóźnienia; kierunek: skrócić czas trzymania po zatrzymaniu się postaci. Brak trybu stuk w danych, więc porównania z nim nie da się wykonać.
- Utknięcia pojawiają się w stanie WALKA, głównie przy Trollach obok celu, na polach o małej prędkości. (pewność 0.35)
  dowód: okno_dlugie: utkniecia 8; w 6 ostatnich: Troll obok celu w 5 z 6, pole v14-v20 (v14 x3, v16 x2, v20 x1), krok_s 0.66-0.94; okno_krotkie: 1 utknięcie v14
  skutek: Dłuższy czas przy celu w walce, bez wpływu na dobicia w tych danych.
  propozycja: Funkcja wykrywania utknięcia (stan WALKA): rozdzielić progi dla pościgu i walki oraz uwzględnić prędkość pola; kierunek: wydłużyć próg czasu w WALKA na wolnych polach. Do rozważenia przez człowieka.
- Zmiany kierunku są znacznie częstsze w długim oknie niż w krótkim. (pewność 0.3)
  dowód: okno_dlugie: zmiany_kierunku_na_krok 0.33 (63 zmiany na 189 kroków); okno_krotkie: 0.06 (1 na 17)
  skutek: Więcej zmian kierunku może oznaczać zygzakowanie lub przeskoki przy wielu potworach, ale bez postępu i oscylacji (0 w obu oknach) nie widać straty.
  propozycja: Brak jednoznacznej zmiany; najpierw zmierzyć, czy zmiany kierunku korelują z liczbą Trolli w pobliżu.
- Pojedynczy przypadek braku ruchu na początku pościgu na Trollu. (pewność 0.15)
  dowód: najgorsze_poscigi: Troll, kroki 1, czas 2.4 s, odl 7->5, lat_med 0.253 s, pole v16; okno_dlugie: brak_ruchu 1 z 200
  skutek: Pojedynczy przypadek, brak wpływu na wynik; n=1, niska pewność.
  propozycja: Brak zmiany na podstawie jednego przypadku.
- do zmierzenia: Czy naciski_z_postoju rosną wraz z lat_med przy pościgu (porównanie per pościg).
- do zmierzenia: Porównanie trybu stuk z trzymaj na tych samych polach (w danych brak trybu stuk, więc nie można jeszcze rozstrzygnąć).
- do zmierzenia: Czy zmiany_kierunku korelują z liczbą Trolli w odległości <=2 od celu.
- do zmierzenia: Jak długo trwa pościg, który zakończył się porzuceniem (powod_top 'od 40 s gonię' nie ma tu szczegółowego przypadku), i czy po 40 s częstość porzuceń rośnie.

## 2026-10-15 09:19 | uwaga | pościgów 5 min: 16, 30 min: 206
- Pościg prawie zawsze kończy się dobiciem celu; zgubień nie ma. (pewność 0.9)
  dowód: okno_dlugie: 205 dobić z 206 pościgów (100% z 'dobicie' w koniec, 1 'brak_ruchu'), zgubienie 0; okno_krotkie: 16/16 dobić.
  skutek: Brak zauważalnej utraty dobić w danych; jedyny odstępstwo to pojedynczy przypadek braku ruchu.
  propozycja: Brak zmiany wymaganej przez te dane; zachować obecną logikę pościgu jako punkt odniesienia.
- Utknięcia (stan WALKA, cel obok Trolla) występują na polach o niskiej prędkości, gdzie kroki/s spadają poniżej mediany pościgu. (pewność 0.4)
  dowód: utkniecia.liczba=9 (okno długie), 6 widocznych w przykładach, pole v 14–20, krok_s 0.66–0.94, mediana kroki_na_s pościgów 1.6; 2 utknięcia w oknie krótkim (v 14 i 16).
  skutek: Czas stracony w stanie WALKA zamiast dojścia do celu; przy 9 utknięciach na 1800 s koszt jest ograniczony, ale występuje też przy celu sąsiadującym z Trollem.
  propozycja: Funkcja wykrywania utknięcia w pościgu: uzależnić próg czasu bez postępu od prędkości pola (wolniejsze pola = dłuższy próg), zamiast stałej wartości.
- Jeden epizod porzucony trwał ok. 40 s pogoni bez przejścia w pościg, co nie odpowiada żadnemu zarejestrowanemu pościgowi. (pewność 0.35)
  dowód: epizody_celu.porzucone=1 z 57, powod_top='od 40 s gonię uciekającego bez'; bez_postepu: 0 pościgów, najdłuższy zapisany pościg to 2.4 s (brak_ruchu).
  skutek: Pościg może być niewidoczny w statystykach; utrata celu lub dobicia może nie być zliczona w kategoriach pościgu.
  propozycja: Funkcja zliczania pościgu: sprawdzić, czy licznik czasu gonienia resetuje się przy przejściu między stanami (WALKA/IDZ) i czy epizod nie łączy kilku pościgów.
- Pojedynczy brak ruchu na początku pościgu na Trollu (1 krok w 2.4 s, dystans 7→5). (pewność 0.2)
  dowód: najgorsze_poscigi: powod 'brak_ruchu', kroki 1, czas 2.4 s, lat_med 0.253 s, ocena_zlego 3.2, stan IDZ, hp_gracza 100.
  skutek: Krótki zatrzymany start; pojedynczy przypadek, bez wpływu na wynik pościgu.
  propozycja: Funkcja startu pościgu: sprawdzić, czy pierwsze naciśnięcie z postoju jest wysyłane przed aktualizacją pozycji celu; bez dalszej zmiany, dopóki nie pojawi się więcej przypadków.

## 2026-10-15 09:21 | uwaga | pościgów 5 min: 12, 30 min: 206
- Jeden epizod celu (porzucony po ok. 40 s gonienia) nie ma odpowiadającego mu rekordu pościgu; najdłuższy zapisany pościg trwa 2.4 s. (pewność 0.5)
  dowód: okno_dlugie: epizody porzucone=1, pościgi koniec=206 (dobicie 205, bez_dojscia 1, zgubienie 0); powod_top: 'od 40 s gonię uciekającego bez...'; najgorsze_poscigi: czas 2.4 s; niespojnosci: []
  skutek: Jedna nieudana pogoń nie trafia do statystyk pościgu, więc ich wskaźnik dobić (100%) może być zawyżony o ten przypadek.
  propozycja: Sprawdzić funkcję zamykającą epizod celu: gdy epizod kończy się jako porzucony, powinna zapisać także rekord pościgu z powodem wyjścia (zapis wyniku pościgu w logerze).
- Utknięcia w pościgu pojawiają się głównie w stanie WALKA, przy obecności Trolla, a nie podczas czystego biegu za uciekającym celem. (pewność 0.35)
  dowód: okno_dlugie utkniecia=9, okno_krotkie=2; w ostatnich 6 wpisach 5 ma Trolla w stanie 2; czasy utknięcia 16–26 s; pole v 14–20, krok_s 0.66–0.94
  skutek: Postać stoi przy Trollu zamiast dojść do celu; dobicia nie spadają (98–100%), ale czas pętli rośnie.
  propozycja: Detekcję utknięcia (progi czasu i prędkości pola) rozdzielić dla stanu WALKA i stanu pościgu, żeby wyjścia z walki nie mieszały się z zatrzymaniami przy celu.
- Zmiany kierunku na krok wzrosły między oknami, mimo że tempo kroków pozostało stabilne. (pewność 0.3)
  dowód: zmiany_kierunku_na_krok: 0.11 (krótkie, n=12) → 0.32 (długie, n=206); kroki_na_s med: 1.56 → 1.63; koniec_med odległości 1.0
  skutek: Część kroków idzie na korekty kierunku; nie wpływa to widocznie na skuteczność, ale zwiększa liczbę zbędnych ruchów.
  propozycja: W funkcji wyboru kierunku ruchu w pościgu dodać histerezę (nie zmieniać kierunku, dopóki nowy kierunek nie jest stabilny przez kilka kroków); do rozważenia przez człowieka.
- Klawisz trzymany jest wciskany także w postoju, a w danych nie ma trybu stuk, więc nie da się porównać obu sposobów. (pewność 0.3)
  dowód: naciski_z_postoju: 100 w długim (0.49 na pościg), 12 w krótkim (1.0 na pościg); trzymane_proc_czasu 99–100; w danych brak wartości dla trybu stuk
  skutek: Naciski przy stoju nie dają ruchu i mogą być przyczyną części utknięć; brak danych nie pozwala tego potwierdzić.
  propozycja: Dodać do logu pomiar trybu stuk (kroki, naciski z postoju) tak, by porównanie trzymaj vs stuk było możliwe; w funkcji obsługi klawisza rozważyć zwolnienie klawisza po wykryciu braku ruchu.
- Latencja medianowa w oknie krótkim jest ponad trzykrotnie wyższa niż w długim, ale próba jest mała. (pewność 0.2)
  dowód: lat_med_s: 0.6 (n=12, krótkie) vs 0.191 (n=206, długie); dec_med_s: 0.0 vs 0.001
  skutek: Możliwy krótki skok opóźnienia; przy n=12 nie da się tego odróżnić od przypadku.
  propozycja: Brak zmiany w kodzie na tym etapie; obserwować latencję w kolejnym oknie o większej próbie.
- do zmierzenia: Czy epizod 40 s to pościg zapisany pod innym id, czy pominięty przez logger (porównać znacznik czasu epizodu z listą pościgów).
- do zmierzenia: Czy wyslane=165 przy 206 pościgach oznacza pościgi bez wysłanego rozkazu ruchu i czy właśnie one dają brak_ruchu/ponow_brak=7.
- do zmierzenia: Porównanie trzymaj vs stuk na tym samym typie celu (Troll) z zapisem naciśnięć z postoju w obu trybach.
- do zmierzenia: Czy utknięcia w WALKA przy Trollu zbiegają się z momentami, gdy cel stoi w zasięgu bez ucieczki (odległość 2, brak zmiany pozycji celu).

## 2026-10-15 09:23 | uwaga | pościgów 5 min: 31, 30 min: 227
- Pościg bywa wolniejszy i zatrzymuje się przy obecności innych potworów (Jointoramix, Troll), zwykle w stanie WALKA, a nie przy samym celu. (pewność 0.5)
  dowód: utkniecia.liczba=7 na 227 pościgów (ok. 3%); krok_s w utknięciach 0.66–0.94 wobec kroki_na_s med 1.6 w oknie długim; wszystkie 7 w stanie WALKA; 6 z 7 zawiera Trolla (stan 2) lub Jointoramixa.
  skutek: Każde utknięcie to ok. 16–26 s bez zbliżania się do celu. Przy 227 pościgach daje to około 2 minut stracone w oknie długim, a w tle ryzyko zgubienia celu, choć zgubienie wynosi 0.
  propozycja: Funkcja pętli pościgu: sprawdzić, czy przy wykryciu innego potwora w pobliżu ścieżki przełącza się ona na WALKA i zawiesza ruch. Rozważyć stałą progu wykrywania utknięcia (czas bez postępu) jako zmienną do przeglądu.
- Jedyne dwa nieudane wyjścia w oknie długim to pojedyncze przypadki (porzucone=1, brak_ruchu=1), a najgorszy pościg to Troll, który zatrzymał się po jednym kroku. (pewność 0.3)
  dowód: koniec: dobicie 226, bez_dojscia 1, zgubienie 0; najgorszy pościg: brak_ruchu, kroki=1, czas 2.4 s, stan IDZ, odl 7→5, zmiany_kier 4, lat_med 0.253; epizody porzucone=1 (powod_top truncated: 'od 40 s gonię uciekającego bez…').
  skutek: Praktycznie brak kosztu (dobicie_proc 100 w krótkim i 99.6% w długim). Przy n=1 nie da się ustalić wzorca.
  propozycja: Logować pełny powód porzucenia i wartość progu czasu użytą przy brak_ruchu, żeby sprawdzić, czy próg nie jest zbyt krótki przy starcie z odl 5–7.
- W danych nie ma trybu stuk, więc nie da się ocenić, czy trzymanie klawisza w postoju marnuje czas. (pewność 0.4)
  dowód: trzymane_proc_czasu 99–100 w obu oknach; naciski_z_postoju 14 (krótkie, 0.45 na pościg) i 104 (długie, 0.46 na pościg); w danych brak porównawczego trybu stuk.
  skutek: Nieznany. Dobicie wynosi 100%, więc nie widać strat, ale ewentualny koszt czasu nie jest zmierzony.
  propozycja: Dodać do funkcji wysyłania klawisza zapis trybu (trzymaj/stuk) w każdym kroku, żeby mieć porównanie.
- Zmiany kierunku na krok są stabilne między oknami. Poprzedni wniosek o ich wzroście nie jest potwierdzony danymi. (pewność 0.6)
  dowód: zmiany_kierunku_na_krok 0.34 (krótkie) vs 0.35 (długie), różnica 0.01; kroki_na_s med 1.5 vs 1.6.
  skutek: Brak wykrytego kosztu. Ruch zygzakiem (ok. 1 zmiana na 3 kroki) nie obniża skuteczności.
  propozycja: Brak zmiany w kodzie. Wniosek o wzroście należy uznać za nieuzasadniony przy tej różnicy.
- do zmierzenia: Czy utknięcia w WALKA występują tylko wtedy, gdy na trasie jest drugi potwór? Policzyć liczbę innych potworów w promieniu 2 pól przy każdym utknięciu i przy pościgach bez utknięcia.
- do zmierzenia: Jaki jest czas od startu pościgu do pierwszego ruchu w przypadkach brak_ruchu i czy próg czasu to uzasadnia?
- do zmierzenia: Czy trzymanie klawisza w postoju zmienia tempo kroków? Potrzebny tryb stuk w tych samych warunkach, min. kilkadziesiąt pościgów.
- do zmierzenia: Latencja: lat_med 0.6 s w oknie krótkim (n=31) vs 0.19 s w długim. Czy to szum małej próby? Powtórzyć pomiar w oknie krótkim z n>=30.

## 2026-10-15 09:25 | uwaga | pościgów 5 min: 32, 30 min: 221
- Pościg w trybie trzymaj często utyka w stanie WALKA, gdy obok jest Troll, więc ścieżka do celu jest blokowana przez inne stwory. (pewność 0.5)
  dowód: utkniecia: 7 w oknie 1800 s; 5 z 6 pokazanych zdarzeń ma Trolla w liście stworów (pozostałe 2 pokazane zdarzenia: jedno z dwoma Trollami, jedno bez Trolla, obie w WALKA); pole v 14-20, krok_s 0.66-0.94; kroki_na_s_ogolem w tym czasie 1.94.
  skutek: Każde utknięcie to dodatkowy czas do dobicia i ryzyko zgubienia celu; w tym oknie koszt jest mały (dobicie 220/221), ale utknięcia skupiają się przy jednym typie przeszkody.
  propozycja: Funkcja wyznaczania kroku pościgu (obsługa ścieżki): dodać rozpoznanie blokady przez inny stwór w pobliżu celu i reakcję (obejście lub przerwanie) zamiast ponawiania kroku; kierunek: mniej utknięć przy Trollu w pobliżu.
- Najgorszy pościg zaczął się przy pełnym HP celu i z dystansu 7, a zakończył się po jednym kroku z powodem brak_ruchu, więc cel prawdopodobnie nie był słabym uciekającym potworem. (pewność 0.3)
  dowód: najgorsze_poscigi: cel Troll, hp_celu 100, odl start 7, koniec 5, kroki 1, czas 2.4 s, powod brak_ruchu, stan IDZ; w oknie długim brak_ruchu = 1 z 221.
  skutek: Jeden stracony pościg (0.5% próby); sam wpis to jeden przypadek, więc wniosek ma małą próbę.
  propozycja: Warunek wejścia do pościgu (filtr celu po HP i maksymalnym dystansie startowym): zawęzić kryterium, żeby pełnozdrowe Trolle nie były ścigane; kierunek: zaostrzyć, nie zmieniać wartości w pokrętłach.
- Opóźnienie reakcji (lat_med) w ostatnich 300 s wzrosło blisko trzykrotnie względem 1800 s, bez widocznego spadku skuteczności. (pewność 0.35)
  dowód: lat_med_s: 0.563 (okno krótkie, n=32) vs 0.19 (okno długie, n=221); dobicie 32/32 w krótkim i 220/221 w długim; kroki_na_s med 1.59 vs 1.6.
  skutek: Brak utraty dobić w danych, ale wyższe opóźnienie zwiększa ryzyko, że cel ucieka poza zasięg przy szybkich zmianach kierunku; nie widać jeszcze kosztu.
  propozycja: Pomiar opóźnienia (funkcja mierząca lat): zbadać źródło wzrostu (serwer/system) i zapisać lat dla każdego pościgu, nie tylko medianę; kierunek: bez zmian w kodzie pościgu do czasu potwierdzenia.
- do zmierzenia: Czy utknięcia zachodzą częściej, gdy inny stwór (zwłaszcza Troll) jest w odległości <=2 od gracza lub celu? Zmierzyć dla każdego pościgu odległość do najbliższego obcego stwora i porównać z częstością
- do zmierzenia: Czy krok_s (prędkość pola) koreluje z utknięciami? Zapisać krok_s dla wszystkich pościgów, nie tylko dla utknięć, żeby mieć punkt odniesienia.
- do zmierzenia: Jaki jest koszt naprzemiennych 'naciśnięć z postoju' (107 w 1800 s, ok. 0.48 na pościg)? Potrzebny jest tryb stuk w tym samym oknie, żeby porównać czas do dobicia; obecnie trzymane_proc_czasu wynosi 9
- do zmierzenia: Czy wzrost lat_med w krótkim oknie koreluje z dłuższym czasem do dobicia? Zmierzyć czas od startu do dobicia dla pościgów z lat > 0.4 s i porównać z resztą.
- do zmierzenia: Co to jest 'ponow_brak' (3 w krótkim, 10 w długim oknie) i czy wiąże się z utknięciami? Potrzebna definicja pola i rozbicie po stworach.

## 2026-10-15 09:27 | ok | pościgów 5 min: 48, 30 min: 208
- Pościgi w trybie trzymaj kończą się dobiciem we wszystkich przypadkach, bez zgubień i bez dojść bez celu. (pewność 0.9)
  dowód: okno_krotkie: koniec.dobicie 48/48 (100%), zgubienie 0; okno_dlugie: dobicie 208/208 (100%), zgubienie 0, bez_dojscia 0; odleglosc koniec_med 1.0, delta_med -1.0.
  skutek: Brak utraty dobić w badanym oknie; nie ma podstaw do zmiany pościgu.
  propozycja: Brak zmiany wymaganej.
- Utknięcia w stanie WALKA występują rzadko i towarzyszą im obecne Trolle, a prędkość pola spada wtedy do 0.66-0.94 kroku/s wobec mediany 1.6. (pewność 0.35)
  dowód: okno_dlugie: utkniecia.liczba 7 (w 1800 s, z 208 pościgów = ok. 3%), w listingu 6 wpisów, wszystkie stan WALKA, stwory zawierają Troll (poziom 1-2) w 5 z 6; krok_s 0.66-0.94; kroki_na_s_med 1.6. W oknie 300 s: utkniecia 0.
  skutek: Pościg wydłuża się o czas postoju; w danych nie widać jednak utraty dobić, bo wszystkie 208 zakończyło się dobiciem.
  propozycja: Funkcja obsługi ruchu w stanie WALKA: rozważyć, czy gdy ścieżkę do celu blokuje inny stwór, ruch powinien mieć priorytet nad walką z trollem, czyli zmianę kolejności decyzji w tej funkcji (do oceny przez człowieka).
- Wpis w ostatnich_wnioskach o trzykrotnym wzroście opóźnienia reakcji nie zgadza się z danymi. (pewność 0.85)
  dowód: lat_med_s: okno_krotkie 0.264 s, okno_dlugie 0.2 s; stosunek ok. 1.32, a nie ok. 3. Dec_med 0.0 i 0.001 s.
  skutek: Błędny wniosek mógłby skierować uwagę na nieistniejący problem; skuteczność dobić w tym samym czasie pozostaje 100%.
  propozycja: Usunąć lub skorygować ten wniosek; nie wymaga zmiany kodu.
- Wpis o najgorszym pościgu (dystans 7, pełne HP, jeden krok, brak_ruchu) nie ma pokrycia w danych. (pewność 0.8)
  dowód: najgorsze_poscigi: pusta lista; bez_dojscia_okno_lub_brak_ruchu: 0 w obu oknach; bez_postepu: 0 poscigow; pełny stan celu nie pojawia się w żadnym wpisie.
  skutek: Wniosek opisuje zdarzenie, którego w zebranych danych nie ma, więc nie może służyć do diagnozy.
  propozycja: Sprawdzić źródło wpisu w logu; nie zmieniać kodu na jego podstawie.
- Trzymany klawisz często się przerywa i wznawia, a zmiany kierunku wynoszą 0.32-0.42 na krok; w połowie pościgów pojawiają się naciski z postoju. (pewność 0.3)
  dowód: zmiany_kierunku_na_krok: 0.42 (krótkie), 0.32 (długie); naciski_z_postoju: 20 na 48 pościgów (0.42/pościg) i 104 na 208 (0.5/pościg); trzymane_proc_czasu 100 i 99.
  skutek: Nie wiadomo, czy naciski z postoju kosztują czas; przy 100% dobić wpływ wydaje się mały, ale nie zmierzony.
  propozycja: Brak danych do decyzji; ewentualnie zmierzyć, ile czasu zajmuje każdy naciśnięty postój względem ruchu.
- do zmierzenia: Czy utknięcia w WALKA trwają dłużej niż pojedynczy pościg i czy skracają się, gdy Troll oddali się z drogi celu (zmierzyć czas od wejścia w WALKA do wznowienia ruchu).
- do zmierzenia: Dlaczego utkniecia.liczba=7, a w listingu jest 6 wpisów (czy jeden wpis został pominięty przy logowaniu).
- do zmierzenia: Czy naciski z postoju mają wpływ na czas dobicia (porównać czas pościgów z naciskami i bez nich).
- do zmierzenia: Brak trybu stuk w danych: porównanie trzymaj vs stuk nie jest możliwe, dopóki nie będzie próbek obu trybów.
- do zmierzenia: Skąd pochodzi wpis o najgorszym pościgu z dystansu 7 i jednym kroku z brak_ruchu (czy to inne okno lub błąd logowania).

## 2026-10-15 09:29 | uwaga | pościgów 5 min: 49, 30 min: 188
- Pościg skutecznie dobija cel: prawie wszystkie zakończenia to dobicie, bez zgubień i bez braku dojścia. (pewność 0.9)
  dowód: Okno krótkie: 48/49 dobicie (98%), 0 zgubienie, 0 bez_dojscia; okno długie: 187/188 dobicie (99%), 0 zgubienie, 0 bez_dojscia. Odległość start->koniec: med 2->1 (krótkie) i 2.0->1.0 (długie).
  skutek: Brak zauważalnej utraty dobić w mierzonym oknie; to główny wynik pozytywny.
  propozycja: Brak zmiany w kodzie wynikającej z tego wniosku.
- Utknięcia w fazie WALKA pojawiają się przy niskiej prędkości pola (v 14-20, krok_s 0.66-0.94), a nie przy typowym tempie pościgu. (pewność 0.4)
  dowód: Okno długie: utkniecia 6 z 188 pościgów (3%); wszystkie w WALKA, pole v 14-20, krok_s 0.66-0.94, przy kroki_na_s med 1.6 (p10 1.26) w tym samym oknie. Wszystkie 6 dotyczy Jointoramix z Trollem lub samym Jointoramix.
  skutek: Około 3% pościgów zwalnia do ~0.7-0.9 kroku/s, co wydłuża czas dobicia; w danych nie widać jeszcze utraty celu z tego powodu.
  propozycja: Funkcja obliczająca prędkość pola / krok_s w pętli pościgu: rozważyć, czy próg oczekiwania na krok powinien uwzględniać pole v (mniejsze v -> dłuższy dopuszczalny czas kroku) zamiast stałej wartości.
- Klawisz trzymany jest wciśnięty niemal przez cały pościg, ale w połowie pościgów zdarzają się naciśnięcia, gdy postać stoi. (pewność 0.35)
  dowód: Okno długie: trzymane_proc_czasu 99%, naciski_z_postoju 103 (0.55 na pościg, 34 pościgi dochodzą do tempa). Okno krótkie: 21 naciśnięć z postoju (0.43 na pościg), trzymane 100%.
  skutek: Nieznany: w danych nie ma pomiaru, czy te naciśnięcia kosztują czas lub powodują utknięcia; brak bezpośredniego dowodu szkody.
  propozycja: Funkcja zliczająca naciski_z_postoju (obsługa trzymania klawisza): sprawdzić, czy licznik poprawnie odróżnia 'naciśnięcie bez ruchu' od 'ruch z opóźnieniem' i jaki jest jego sens.
- Zmiany kierunku są częste, ale nie prowadzą do oscylacji ani do braku postępu. (pewność 0.5)
  dowód: Zmiany kierunku na krok: 0.20 (krótkie) i 0.27 (długie); oscylacje A-B-A-B: 0; bez_postepu: 0 pościgów i 0 kroków; odległość końcowa nie wzrosła w żadnym pościgu.
  skutek: Brak mierzalnego kosztu w obecnych danych.
  propozycja: Brak zmiany; zachować monitorowanie oscylacji jako wskaźnika.
- Wpisy w ostatnich_wnioskach nie zgadzają się z bieżącymi danymi i nie należy ich powtarzać bez nowej przesłanki. (pewność 0.8)
  dowód: Ostatnie_wnioski podają zmiany kierunku 0.32-0.42 na krok, a dane pokazują 0.20-0.27. Opisują najgorszy pościg jako dystans 7, pełne HP, jeden krok, brak_ruchu, a najgorszy pościg w danych to Troll, 5 kroków, 4.09 s, odl [5,2], powód gryzacy. Wpis o potrojonym
  skutek: Ryzyko błędnych decyzji opartych na nieprawdziwych liczbach.
  propozycja: Brak zmiany w kodzie; usunąć lub skorygować te wpisy w raportowaniu.

## 2026-10-15 09:33 | ok | pościgów 5 min: 13, 30 min: 165
- Utknięcia dotyczą stanu WALKA z Jointoramix i Trollem, a nie samego pościgu. (pewność 0.4)
  dowód: Okno długie: 5 utknięć w 1800 s (16-26 s każde, pole v 14-16, krok_s 0.66-0.75); wszystkie w stanie WALKA z obecnym Trollem (stwór 2) lub Jointoramix; w tych oknach brak zgubień.
  skutek: Pościg trwa dłużej w czasie walki, co może opóźniać dobicie; nie zaobserwowano porzucenia celu.
  propozycja: Sprawdzić w kodzie, jak stan WALKA przekazuje sterowanie do pościgu i czy blokuje ruch, gdy obok jest drugi stwór; rozważyć rozróżnienie pola zajętego przez potwora od przeszkody terenowej.
- do zmierzenia: Czy naciski_z_postoju są spowodowane blokadą pola przez potwora lub ścianę, czy opóźnieniem odświeżenia pozycji (zmierzyć odległość od kroku poprzedniego naciśnięcia)?
- do zmierzenia: Jaka była przyczyna jedynego przerwane_inne w każdym oknie (zapisać stan i stwory w chwili przerwania)?
- do zmierzenia: Czy utknięcia w WALKA wydłużają czas pościgu i o ile (porównać czas do dobicia dla pościgów z utknięciem i bez)?
- do zmierzenia: Czy latencja 0.5 s w oknie krótkim utrzymuje się w kolejnych pościgach za Trollem (zebrać co najmniej 30 pościgów za tym celem)?
